from pathlib import Path
import json, hashlib, re, collections

BASE=Path(__file__).resolve().parent
TREE=json.loads((BASE/'tree.json').read_text())
SEL=json.loads((BASE/'selection.json').read_text())
RECEIPTS=json.loads((BASE/'retrieval_receipts.json').read_text())
TRACKED={x['path']:x for x in TREE['tree'] if x['type']=='blob'}
RX=re.compile(r'(?:artifacts|data|reports|schemas|notebooks)/[^\s\"\'<>`\\\]\[{}(),;]+')
TASKS={
 'golden_qa_validation':r'question_targets_claim|answer_recovers_claim|no_neighbor_fact_drift',
 'source_claim_validation':r'claim_semantic_fidelity|HOLD_CRITICAL_RISK|claims_validated',
 'retrieval_metrics':r'recall_at|recall@|ndcg|reciprocal_rank',
 'no_answer':r'no.answer|answerability|clarification|abstain',
 'safety_criticality':r'criticality|NONCRITICAL|safety_violation',
 'confidence_calibration':r'calibration|brier|log_loss|expected_calibration',
 'answer_grounding':r'groundedness|grounding|support_status|SUPPORTED',
 'answer_completeness':r'completeness|essential_meaning|ANSWER_GAP|question_coverage',
 'citation_attribution':r'citation|attribution|speaker|editorial',
 'cost_latency':r'latency|prompt_tokens|completion_tokens|total_tokens|known_cost',
}
def safe_paths(s):
 return sorted({m.rstrip('.:') for m in RX.findall(s) if not any(x in m.lower() for x in ['.env','secret','api_key'])})
def textout(cell):
 out=[]
 for x in cell.get('outputs',[]):
  a=x.get('text',[]);out.append(a if isinstance(a,str) else ''.join(a))
  a=x.get('data',{}).get('text/plain',[]);out.append(a if isinstance(a,str) else ''.join(a))
 return '\n'.join(out)
def objects(s):
 decoder=json.JSONDecoder();out=[];i=0
 while i<len(s):
  m=re.search(r'[\[{]',s[i:])
  if not m:break
  j=i+m.start()
  try:v,end=decoder.raw_decode(s,j)
  except (ValueError,RecursionError):i=j+1;continue
  if isinstance(v,(dict,list)):out.append(v)
  i=end
 return out
def cells_record(path,number,source,output,execution=None,errors=0,cell_type='code'):
 first=source[:1200]
 match=re.search(r'NB\d+[A-Za-z]?[. _-]+C\d+|Code Cell\s*\d+|Cell\s*\d+|^#\s*C\d+',first,re.M|re.I)
 ident=match.group(0) if match else 'cell_index_'+str(number)
 return {'path':path,'cell_1based':number,'cell_id_as_detected':ident,
  'first_line':source.splitlines()[0][:220] if source.splitlines() else '',
  'cell_type':cell_type,'execution_count_as_saved':execution,'stored_error_count':errors,
  'output_present':bool(output.strip()),'task_mentions_not_acceptance':[k for k,v in TASKS.items() if re.search(v,source+'\n'+output,re.I)],
  'artifact_path_mentions':safe_paths(source+'\n'+output),
  'reported_statuses':sorted(set(re.findall(r'"(?:status|final_status|acceptance_status|freeze_status)"\s*:\s*"([^"\n]{1,180})"',output)))[:100],
  'output_json_object_count':len(objects(output)) if len(output)<150000 else None}

inventory=[];cells=[];refs=[];json_summaries=[];parsing=[];duplicates=collections.defaultdict(list)
for receipt in RECEIPTS:
 p=receipt['path'];cache=BASE/'cache'/receipt.get('cache','MISSING')
 if not cache.is_file():inventory.append({**receipt,'audit_status':'CACHE_MISSING'});continue
 e=TRACKED[p];s=json.loads(cache.read_text())['content'];raw=s.encode('utf-8')
 gitsha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 status='RETRIEVED_AND_STRUCTURALLY_PARSED'
 record={'path':p,'advertised_git_blob':e['sha'],'calculated_git_blob':gitsha,
  'git_blob_match':gitsha==e['sha'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 duplicates[e['sha']].append(p)
 try:
  if p.endswith('.ipynb'):
   nb=json.loads(s);record.update({'format':'ipynb','cell_count':len(nb['cells']),'code_cells':sum(c['cell_type']=='code' for c in nb['cells'])})
   for i,c in enumerate(nb['cells'],1):
    source=c.get('source',[]);source=source if isinstance(source,str) else ''.join(source)
    cells.append(cells_record(p,i,source,textout(c),c.get('execution_count'),sum(o.get('output_type')=='error' for o in c.get('outputs',[])),c['cell_type']))
  elif p.endswith('.json'):
   d=json.loads(s);record.update({'format':'json','root_type':type(d).__name__,'root_count':len(d) if isinstance(d,(dict,list)) else None})
   if isinstance(d,dict):
    keep={k:v for k,v in d.items() if k in ['status','registry_status','freeze_status','acceptance_status','acceptance_decision','final_status','record_count','counts','population','record_counts','metric_scope','limitations','known_limitations','artifact_type','report_type','next_notebook','next_stage']}
    json_summaries.append({'path':p,'root_keys':list(d),'reported_summary':keep})
  elif p.endswith('.jsonl'):
   lines=[x for x in s.splitlines() if x.strip()];hist=collections.Counter();keys=collections.Counter()
   for line in lines:
    d=json.loads(line)
    if isinstance(d,dict):
     keys.update(d.keys())
     for k in ['verdict','decision','status','disposition','validation_status']:
      v=d.get(k)
      if isinstance(v,str):hist[k+':'+v]+=1
   record.update({'format':'jsonl','rows':len(lines),'keys':dict(keys),'top_level_state_counts':dict(hist)})
  else:record['format']='text'
 except Exception as exc:
  status='PARSE_ERROR';parsing.append({'path':p,'error':type(exc).__name__+':'+str(exc)[:300]})
 record['audit_status']=status;inventory.append(record)
 for target in safe_paths(s):
  refs.append({'producer_path':p,'referenced_path_literal':target,'tracked_in_same_commit':target in TRACKED,'absence_on_local_system_inferred':False})

# Consume all six readable export parts, keeping the explicit original notebook hash.
exports=[r for r in RECEIPTS if re.search(r'/part_\d+\.txt$',r['path'])]
chunks=[]
for r in sorted(exports,key=lambda x:x['path']):
 s=json.loads((BASE/'cache'/r['cache']).read_text())['content']
 for m in re.finditer(r'^===== cell_(\d+)_part_(\d+)\.txt =====\n(.*?)(?=^===== cell_|\Z)',s,re.M|re.S):chunks.append((int(m[1]),int(m[2]),m[3]))
group=collections.defaultdict(list)
for no,part,s in chunks:group[no].append((part,s))
export_records=[]
for no,parts in sorted(group.items()):
 combined=''.join(s for _,s in sorted(parts));head=re.search(r'^CELL \d+ — (\w+)\n',combined)
 source=combined.split('\nSOURCE\n',1)[-1]
 split=re.split(r'\n(?:OUTPUTS?|STORED OUTPUTS?)\n',source,maxsplit=1)
 export_records.append(cells_record('notebooks/phase2/21_evaluation_and_ablation.ipynb [readable export]',no,split[0],split[1] if len(split)>1 else '',cell_type=head[1] if head else 'unknown'))
cells+=export_records
gaps=[x for x in SEL['excluded'] if x['audit_status'] in ['NOTEBOOK_TRANSPORT_SIZE_GAP','LARGE_ROW_DATA_REQUIRES_LOCAL_ACCESS']]
result={'schema_version':'phase2_repository_reuse_audit.v1','commit':TREE['commit'],
 'scope':'Pinned tracked repository; static parsing and targeted content review; no local Mac access or semantic rejudgment',
 'full_repository_history_absence_established':False,'new_model_api_calls':0,'new_checklist_ticks':0,
 'tree_entries':len(TREE['tree']),'tree_truncated':TREE['truncated'],'phase2_inventory_entries':len(SEL['selected'])+len(SEL['excluded']),
 'retrieved_files':len(inventory),'git_blob_matches':sum(x.get('git_blob_match',False) for x in inventory),
 'parse_errors':parsing,'complete_notebook_jsons':sum(x.get('format')=='ipynb' for x in inventory),
 'readable_nb21_export':{'parts':len(exports),'reconstructed_cell_numbers':len(group),'chunks':len(chunks),'advertised_source_sha256':'1a0a006922ca8698af77b29f959a5c0eb3edb76881c8f2627a9b258da9352a94','raw_notebook_bytes_revalidated':False},
 'cell_records':len(cells),'literal_reference_records':len(refs),'unread_required_source_count':len(gaps),
 'duplicate_blob_groups':{k:v for k,v in duplicates.items() if len(v)>1}}
for name,d in [('audit_summary.json',result),('source_coverage.json',inventory),('producer_cells.json',cells),('artifact_references.json',refs),('reported_results.json',json_summaries),('remaining_access_gaps.json',gaps)]:
 (BASE/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
