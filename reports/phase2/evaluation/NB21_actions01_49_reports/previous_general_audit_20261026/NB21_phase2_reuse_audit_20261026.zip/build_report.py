from pathlib import Path
import json,re,collections,zipfile,hashlib
from urllib.parse import quote

P=Path(__file__).resolve().parent
S=json.loads((P/'audit_summary.json').read_text())
C=json.loads((P/'producer_cells.json').read_text())
coverage=json.loads((P/'source_coverage.json').read_text())
tree=json.loads((P/'tree.json').read_text());tracked={x['path']:x for x in tree['tree'] if x['type']=='blob'}
old=(P.parent/'handoff_review/notebooks/data_load_read/RAG_finance_NB21_full_reuse_map_fa_20261023.md').read_text()
section=old.split('## ۹. نگاشت',1)[1].split('## ۱۰.',1)[0]
trans=str.maketrans('۰۱۲۳۴۵۶۷۸۹','0123456789')
actions=[]
for line in section.splitlines():
 fields=[v.strip() for v in line.strip().strip('|').split('|')]
 if len(fields)==4 and fields[0].translate(trans).isdigit():
  actions.append({'action_id':int(fields[0].translate(trans)),'title':fields[1],'historical_source_guide':fields[2],'historical_scope_note':fields[3]})
assert len(actions)==49

spec={
1:[('21_', [57])],2:[('21_',[2,57])],3:[('21_',[57])],4:[('21_',[4,57])],
5:[('21_',[17,303])],6:[('12i_',[]),('12j_',[]),('21_',[17])],7:[('19_',[195,235,239]),('21_',[60,69])],8:[('21_',[17,34,41])],
9:[('21_',[20,40])],10:[('21_',[26,194,329]),('10_',[])],11:[('21_',[27,28,29,30,31,32])],12:[('21_',[34])],
13:[('21_',[35,36,37,38,39,40,41])],14:[('21_',[298,299,300,301])],15:[('21_',[302])],16:[('21_',[303])],17:[('21_',[303])],18:[('21_',[303])],
19:[('16_',[18,21]),('17_',[15]),('21_',[192,304])],20:[('21_',[192,194,304])],21:[('21_',[173,195,196,304])],
22:[('19_',[195])],23:[('12j_',[25,57,58]),('12i_',[16,18])],24:[('19_',[195])],25:[('07_',[]),('10_',[])],
26:[('19_',[195,235,239])],27:[('19_',[235,239])],28:[('21_',[40])],29:[('17_',[15]),('19_',[])],30:[('19_',[])],31:[('16_',[18]),('17_',[15,17]),('18_',[75,76,79])],
32:[('08_',[])],33:[('11_',[])],34:[('16_',[18,19,21]),('21_',[192,304])],35:[('17_',[15,16,17,19,21]),('21_',[192,195,196,304])],36:[('18_',[75,76,77,78,79,92])],37:[('19_',[195])],
38:[('16_',[18]),('17_',[17]),('18_',[79])],39:[('16_',[19]),('17_',[19]),('19_',[235,236,237,238,239])],40:[('17_',[15,16]),('21_',[195])],41:[('17_',[16]),('21_',[196])],42:[('17_',[16]),('21_',[196])],43:[('10_evaluation',[])],44:[('16_',[22]),('17_',[22]),('18_',[93])],45:[('21_',[34,302])],46:[('18_',[92])],47:[('18_',[91]),('21_',[303])],48:[('12j_',[61]),('21_',[303])],49:[('21_',[57,304])]}
current_closed=set(range(1,10))|{11}|set(range(13,26))
readmap={v['path']:v for v in coverage}
def cellno(c):
 a=re.search(r'C(\d+)',c['cell_id_as_detected'],re.I) or re.search(r'Cell\s*(\d+)',c['cell_id_as_detected'],re.I)
 return int(a[1]) if a else None
for a in actions:
 n=a['action_id'];direct=[]
 for prefix,ids in spec[n]:
  for c in C:
   if '/phase1/' in c['path'] and n!=43:continue
   name=Path(c['path'].split(' [',1)[0]).name
   if name.startswith(prefix) and c['cell_type']=='code' and (not ids or cellno(c) in ids):
    direct.append({k:c[k] for k in ['path','cell_1based','cell_id_as_detected','first_line','output_present','reported_statuses','artifact_path_mentions']})
 a.update({'checklist_status':'USER_ACCEPTED_SCOPED_COMPLETION' if 22<=n<=25 else 'CHECKED_IN_CURRENT_CHECKLIST' if n in current_closed else 'OPEN_IN_CURRENT_CHECKLIST_NOT_PROOF_OF_NONEXECUTION',
 'directly_parsed_producer_cells':direct,'source_guide_scope':'Historical 2026-10-23 mapping; supplemented by current pinned producer reads',
 'automatic_new_closure_authorized':False,'fresh_api_work_certified':False,'row_level_current_population_reconciliation_complete':False})
 if n==36:
  a['source_guide_correction']='Use NB18-C075..C079 and finalized configuration for selected source=8/document=5; C062..C065 are exploratory and include 8/6.'
 if n==3:a['historical_scope_note']='Current tree has NB21c too; original historical guide mentioning only NB21/NB21b is superseded.'
 if n==49:a['historical_scope_note']='Current checklist has 23 ticks, not the historical 19.'
(P/'action_evidence_index.json').write_text(json.dumps({'schema_version':'NB21.action_evidence_index.audit.v1','commit':S['commit'],'status':'PARTIAL_EVIDENCE_CONNECTION_NOT_POPULATION_ACCEPTANCE','actions':actions},ensure_ascii=False,indent=2)+'\n')

# Keep a precise distinction between size-related access gaps and irrelevant formats.
gaps=json.loads((P/'remaining_access_gaps.json').read_text())
for g in gaps:
 g['is_evidence_of_missing_history']=False
 g['gap_effect']='Current row-level scope cannot be certified from this source until accessed.'
 if g['path']=='notebooks/phase2/21_evaluation_and_ablation.ipynb':g['content_available_via_readable_export']=True;g['gap_effect']='Cell content available in tracked readable export; original notebook byte-level verification remains separate.'
 if 'semantic_neighbor_candidates' in g['path'] or 'sparse_postings' in g['path']:g['gap_effect']='Large intermediate retrieval/neighbor data; not automatically a blocker for answer-judgment reuse.'
(P/'remaining_access_gaps.json').write_text(json.dumps(gaps,ensure_ascii=False,indent=2)+'\n')
S['size_related_unretrieved_files']=S.pop('unread_required_source_count')
S['main_notebook_content_access_via_export']=True
(P/'audit_summary.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n')

report='''# ممیزی اتصال شواهد فاز دوم به ۴۹ اقدام NB21

تاریخ: ۲۶ اکتبر ۲۰۲۶. مخزن Shahbazi-Amir/RAG_finance، شاخه rag-phase2.

## نتیجهٔ اصلی

بازاستفادهٔ مهم و گسترده‌ای وجود دارد. به‌خصوص مقایسهٔ Dense/Hybrid، مقایسهٔ Reranker، تحلیل خطا، عدم قطعیت و بخشی از latency از قبل خروجی واقعی دارند. این کارها نباید صرفاً به دلیل بازبودن تیک، دوباره اجرا شوند.

با این حال، این ممیزی نبود داوری قبلی برای تمام پرونده‌ها و تمام وظایف را اثبات نمی‌کند. فایل‌های بزرگ NB20/NB21b/NB21c و بخشی از داده‌های ردیفی کامل دریافت نشدند؛ اصل work/outputs مک نیز در دسترس نیست. در نتیجه، صف API جمعیتی جدید از این گزارش تأیید نمی‌شود.

این بررسی استخراج کامل ساختار منابع دریافت‌شده و بازخوانی هدفمند بخش‌های تصمیم‌ساز است؛ داوری معنایی تک‌تک رکوردها یا خواندن انسانی تمام واژه‌های همهٔ منابع ادعا نمی‌شود. هیچ کد تاریخی اجرا نشد، هیچ API مدل ارسال نشد، مخزن تغییر نکرد و تیک تازه ثبت نشد.

## نسخه و پوشش واقعی

'''
report+=f"- Commit: `{S['commit']}`.\n- درخت کامل: {S['tree_entries']} entry، با truncated=false.\n- موجودی مسیرهای فاز دوم و نقشه‌ها: ۲۱۲ فایل؛ این عدد کل فایل‌های مک نیست.\n- دریافت و تحلیل ساختاری: ۱۶۴ فایل، شامل ۳۰ نوت‌بوک فاز دوم و یک نوت‌بوک مقایسهٔ فاز اول، ۹۸ JSON، ده JSONL و ۲۵ متن.\n- هویت Git Blob محاسبه‌شده با نسخهٔ مخزن: ۱۶۴ از ۱۶۴ مطابق.\n- خطای Parse در فایل‌های دریافت‌شده: صفر.\n- NB21 اصلی: شش بخش خروجی خواندنی، با ۶۹۴ شمارهٔ سل بازسازی‌شده. این مسیر، کنترل بایت فایل اصلی ipynb نیست.\n- مجموع رکوردهای سل استخراج‌شده: {S['cell_records']}؛ شامل سل‌های Markdown و Code.\n- ارجاع‌های لفظی مسیر استخراج‌شده: {S['literal_reference_records']}؛ این‌ها اتصال ردیفی موفق یا شمار فایل یکتا نیستند.\n- ۲۲ فایل بزرگ دریافت نشدند؛ متن سل‌های NB21 اصلی از Export در دسترس است. ۲۸ مورد دیگرِ انتخاب‌نشده، قالب‌های باینری/تکراری یا نقشهٔ فازهای دیگر بودند.\n"
report+='''
## یافته‌های تأییدشده و اثر بر عدم دوباره‌کاری

### ۱. اقدام ۳۴: مقایسهٔ Dense و Hybrid قبلاً اجرا شده است

منبع: notebooks/phase2/16_hybrid_retrieval.ipynb، Code Cell 18، سل فیزیکی ۳۶.
پنج سیستم مقایسه شده‌اند. Recall@10 ثبت‌شدهٔ Dense برابر 0.4735470589637256 و Weighted Hybrid برابر 0.621242522284189 است. nDCG@10 به‌ترتیب 0.37395705045915284 و 0.5381727779077033 است. این‌ها نتیجهٔ همان قرارداد تاریخی‌اند، نه اجرای جدید یا تعمیم به کیفیت پاسخ.

کار بعد: مصرف نتیجه و تنظیمات و تطبیق با قرارداد گزارش NB21. اجرای دوبارهٔ Dense/Hybrid پیش‌فرض نیست. عمق رتبه، Gold و tie-break حفظ شوند.

### ۲. اقدام ۳۵ و بخشی از ۲۹/۴۰/۴۱/۴۲: خروجی جمعیتی Reranker موجود است

منبع: notebooks/phase2/17_reranking.ipynb، Code Cell 15، سل فیزیکی ۳۰.
۲۶۶۴ Development، با candidate depth=50. Recall@10 از 0.621242522284189 به 0.6676743707993709 و nDCG@10 از 0.5381727779077033 به 0.5988342300716867 رسیده است.

اختلاف nDCG@10 برابر 0.06066145216398333 و CI ثبت‌شدهٔ ۹۵٪ با ۵۰۰۰ بازنمونه‌گیری حدود [0.051490917807556505, 0.07022573580323598] است. این CI مربوط به همان مقایسه است و به معیار دیگر منتقل نمی‌شود.

۸۹۳ بهبود، ۴۸۴ افت و ۱۲۸۷ بدون تغییر ثبت شده‌اند. Code Cell 16، سل فیزیکی ۳۲، تحلیل شکست و پرونده‌ها را دارد. این شاهد مستقیم برای دفتر خطا و Failure catalogue است؛ تولید دوبارهٔ خطا لازم نیست.

latency محلی ONNX CPU با depth=50 برای ۲۵۱۴ Query موجود است: p50=6.021237732998998s و p95=8.405428699801632s. این زمان کل محصول یا زمان Cache نیست.

### ۳. اقدام ۳۶: مرجع سیاست نهایی، دقیق‌تر از گزارش قبلی شد

NB18-C062..C065 آزمایش‌های مقدماتی‌اند؛ C065 حتی سیاست ۸/۶ را بررسی کرده است. برای سیاست نهایی ۸/۵، به C075..C079 مراجعه شود؛ در فایل فعلی C075 سل فیزیکی ۱۵۲ و C076..C079 به‌ترتیب ۱۵۴،۱۵۶،۱۵۸،۱۶۰ هستند.

C076 سیاست source=8/document=5 با reranker_order را انتخاب و C077 آن را روی ۲۶۶۴ بسته اعتبارسنجی کرده است: ۲۶۶۱۶ آیتم منتخب و ۲۴ حذف. C079 تطابق Configuration و ADR نهایی را ثبت کرده است. Recall کانونی Context در این سیاست 0.6671023702273697 و Hit rate برابر 0.8498498498498499 گزارش شده است.

برای بستن دامنهٔ Context اقدام ۳۶ همین شواهد باید تطبیق و گزارش شوند؛ اثر روی پاسخ نهایی فقط در صورت مطالبهٔ قرارداد و نبود شاهد مرتبط جدا باز می‌ماند. حذف cap غیرفعال NB16 جای آزمون سیاست فعال NB18 نیست.

### ۴. ساخت Golden و داوری منبع قبلاً انجام شده‌اند

NB12i و NB12j کامل دریافت و ساختار سل‌ها/خروجی‌هایشان تحلیل شد. گزارش Golden فریز ۳۸۱۳ QA را ثبت کرده است. JSONL داوری Seed شامل ۳۸۱۷ ردیف، نگاشت Claim شامل ۴۰۳۹ ردیف و متن Canonical Claim شامل ۴۰۰۶ ردیف Parse شد.

این شواهد نباید دوباره تولید شوند. با این حال، داوری Seed، اعتبار Golden و داوری Claim منبع با ارزیابی پاسخ فعلی یا مرجع جامع Answerability یکی نیستند. این تمایز، محدودیتِ کاربرد شاهد است، نه حذف کار قبلی.

### ۵. سه جفت فایل واقعاً یکسان‌اند

Git Blob سه گروه تکراری شناسایی شد: Handoff Sparse، Release Sparse و Acceptance Sparse در ریشه و زیر notebooks/phase2. هر جفت یک محتوا دارد و دو اجرای مستقل شمرده نمی‌شود. مسیرها در audit_summary.json ثبت شده‌اند.

### ۶. وضعیت جاری چک‌لیست حفظ شد

۲۳ تیک از ۴۹؛ اقدامات ۲۲–۲۵ با USER_ACCEPTED_SCOPED_COMPLETION بسته‌اند. این تصمیم باز نشد. درصد پوشش آن‌ها با درصد صحت یکی نیست. اقدامات ۱۰،۱۲ و ۲۶–۴۹ در چک‌لیست بازند؛ اما اجرای NB21c ممکن است از ثبت چک‌لیست جلوتر باشد و هنوز کامل خوانده نشده است.

## نگاشت ۴۹ اقدام به شواهد

ستون ارجاع تاریخی از نقشهٔ قبلی است؛ ستون سل‌های مستقیم به محتوای دریافت‌شدهٔ این ممیزی متصل است. «سل مستقیم» اثبات پذیرش یا اجرای سالم تمام آن سل نیست. خروجی، خطا و دامنه باید در رکورد همان سل دیده شود. برای شمارهٔ سل‌های اصلی از source و شناسهٔ نوشته‌شده استفاده شود؛ شمارهٔ فیزیکی صرفاً Locator کمکی است.

| اقدام | موضوع | وضعیت چک‌لیست | راهنمای منبع | سل مستقیمِ استخراج‌شده | کار باقی‌مانده/حدود |
|---:|---|---|---|---:|---|
'''
for a in actions:
 n=a['action_id'];status='بستهٔ محدود' if 22<=n<=25 else 'تیک‌خورده' if n in current_closed else 'باز؛ اجرای تازه بررسی‌نشده'
 note=a.get('source_guide_correction',a['historical_scope_note'])
 report+=f"| {n} | {a['title']} | {status} | {a['historical_source_guide'].replace('|','/')} | {len(a['directly_parsed_producer_cells'])} | {note.replace('|','/')} |\n"
report+='''
## دفتر قابل‌خواندن برنامه

action_evidence_index.json دارای ۴۹ رکورد است. هر اقدام به Producerهای مستقیمِ یافت‌شده، سل فیزیکی، شناسه، عنوان، وضعیت خروجی و مسیر Artifactهای ذکرشده متصل است. این دفتر هنوز Join ردیفیِ کل جمعیت نیست. کلید fresh_api_work_certified در تمام رکوردها false باقی مانده؛ به معنی نبود نیاز احتمالی نیست، بلکه کار تازه هنوز از این ممیزی قطعی نشده است.

source_coverage.json برای هر فایل دریافتی، Commit/Blob، SHA256، قالب، شمار ردیف یا سل و وضعیت Parse را نگه می‌دارد. producer_cells.json فهرست سل‌هاست. artifact_references.json ارجاع‌های لفظی را نگه می‌دارد؛ tracked=false به معنی فقدان روی مک نیست. همهٔ ارجاع‌ها الزاماً نام فایل کامل یا مسیر Canonical نیستند و رشته‌های برنامه‌ای می‌توانند شامل Placeholder باشند.

reported_results.json خلاصهٔ گزارش‌های JSON را نگه می‌دارد. remaining_access_gaps.json منابع بزرگِ دریافت‌نشده و اثر دقیق دسترسی را نشان می‌دهد. selection.json دلیل انتخاب‌نشدن سایر قالب‌ها را حفظ می‌کند.

## شکاف دسترسی باقی‌مانده

این فهرست ادعای انجام‌نشدن کار نیست. در میان نوت‌بوک‌ها، مهم‌ترین منبع برای وضعیت امروز NB21c است. NB20/NB20b/NB20c نیز برای اثبات هم‌وظیفگی داوری‌های قدیمی باید از خروجی کامل یا Export معتبر قابل بررسی شوند. برای Sparse و NB21b گزارش‌های کوچک مرتبط در دسترس بوده، ولی خود نوت‌بوک‌های بزرگ کامل دریافت نشدند.

| منبع | علت/اثر |
|---|---|
'''
for g in gaps:report+=f"| `{g['path']}` | {g['gap_effect']} |\n"
report+='''
## تصمیم اجرایی

۱. کارهای دارای شاهد مستقیم مانند ۳۴،۳۵، بخش Context در۳۶، latency ریرنکر و تحلیل شکست‌ها، نامزد تجمیع و ثبت هستند؛ اجرای دوبارهٔ تولیدکننده پیش‌فرض نیست.
۲. بسته‌شدن ۲۲–۲۵ محفوظ است. شواهد این دور دوباره داوری نمی‌شوند.
۳. دربارهٔ ۲۶–۲۸، قبل از کار تازه باید نتیجهٔ واقعی NB21c خوانده شود. گزارش فعلی نمی‌گوید این کارها انجام نشده‌اند.
۴. هیچ صف تازهٔ API برای کل Test یا Development از این ممیزی تأیید نشد. Golden، Criticality و پشتیبانی منبع بدون تطبیق، جای وظیفهٔ فعلی نمی‌نشینند.
۵. تکمیل شکاف دسترسی فقط محتوا/Export منابع مشخص را می‌خواهد؛ آپلود ۸ گیگ، Embedding، Index یا همهٔ Rawها لازم نیست. برای local work/outputs، خروجی فشردهٔ دفتر/رسید/قراردادهای مرتبط کافی است تا ابتدا دامنه مشخص شود.

## منابع آنلاین اصلی

'''
for p in ['notebooks/phase2/checklist/NB21_remaining_work_checklist_fa.md','reports/phase2/evaluation/NB21_actions22_25_scoped_closure.md','notebooks/phase2/16_hybrid_retrieval.ipynb','notebooks/phase2/17_reranking.ipynb','notebooks/phase2/18_context_builder.ipynb','notebooks/phase2/21c_evaluation_and_ablation_continued.ipynb','notebooks/data_load_read/RAG_finance_NB21_full_reuse_map_fa_20261023.md']:
 report+=f"- [{Path(p).name}](https://github.com/Shahbazi-Amir/RAG_finance/blob/{S['commit']}/{quote(p,safe='/')})\n"
report+='''
## حدود ادعا

صحت انتقال بایت‌های ۱۶۴ فایل و Parse آن‌ها بررسی شد. محتوای علمی و کیفیت جمعیت از این کنترل فنی نتیجه نمی‌شود. عدد فایل/سل/ارجاع درصد تکمیل علمی نیست. این ممیزی گسترده و قابل‌ردیابی است، اما با وجود شکاف‌های صریح بالا، «بررسی کامل تمام سوابق محلی و آنلاین بدون هیچ مورد جاافتاده» نامیده نمی‌شود.
'''
(P/'NB21_phase2_reuse_audit_fa.md').write_text(report)
package=P.parent/'NB21_phase2_reuse_audit_20261026.zip'
names=['NB21_phase2_reuse_audit_fa.md','audit_summary.json','source_coverage.json','producer_cells.json','artifact_references.json','reported_results.json','remaining_access_gaps.json','action_evidence_index.json','retrieval_receipts.json','selection.json','tree.json','analyze.py','build_report.py']
with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in names:z.write(P/n,n)
assert len(actions)==49 and len({a['action_id'] for a in actions})==49
assert S['git_blob_matches']==164 and not S['parse_errors']
print(json.dumps({'report':str(P/'NB21_phase2_reuse_audit_fa.md'),'package':str(package),'package_bytes':package.stat().st_size,'action_count':len(actions),'direct_cell_links':sum(len(a['directly_parsed_producer_cells']) for a in actions)},ensure_ascii=False))
