# NB22B-C003 — Shared validated mechanics; no historical notebook execution.
class EvidenceGap(Exception):
    """A documented input prerequisite, never an inferred absence of prior work."""


def need(condition, reason):
    if not condition:
        raise EvidenceGap(reason)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def project_path(relative):
    need(ROOT is not None, 'PROJECT_ROOT_REQUIRED')
    rel = Path(relative)
    need(not rel.is_absolute() and '..' not in rel.parts, 'PROJECT_RELATIVE_PATH_REQUIRED')
    path = (ROOT / rel).resolve()
    need(path.is_relative_to(ROOT), 'PATH_OUTSIDE_PROJECT')
    return path


def descriptor(binding):
    need(isinstance(binding, dict) and isinstance(binding.get('path'), str), 'BOUND_DESCRIPTOR_REQUIRED')
    values = {binding[k] for k in ('file_bytes_sha256', 'sha256_file_bytes', 'sha256')
              if isinstance(binding.get(k), str)}
    need(len(values) == 1, 'EXPLICIT_UNAMBIGUOUS_BYTE_HASH_REQUIRED')
    value = next(iter(values))
    need(re.fullmatch('[a-f0-9]{64}', value) is not None, 'INVALID_HASH_DESCRIPTOR')
    return binding['path'], value


def read_bound(binding, jsonl=False):
    relative, expected = descriptor(binding)
    path = project_path(relative)
    need(path.is_file(), 'NOT_AVAILABLE_AT_PINNED_PATH:' + relative)
    st = path.stat()
    previous = S['source_reads'].get(relative)
    if previous and previous['receipt']['file_bytes_sha256'] == expected:
        need(previous['receipt']['stat'] == [st.st_size, st.st_mtime_ns, st.st_ino],
             'PREVIOUSLY_READ_FILE_CHANGED:' + relative)
        return previous['value']
    before = st
    raw = path.read_bytes()
    after = path.stat()
    need((before.st_size, before.st_mtime_ns, before.st_ino) ==
         (after.st_size, after.st_mtime_ns, after.st_ino), 'FILE_CHANGED_DURING_READ:' + relative)
    need(sha(raw) == expected, 'FILE_BYTE_HASH_CONFLICT:' + relative)
    try:
        value = [_boot_decode(line) for line in raw.splitlines() if line.strip()] if jsonl else _boot_decode(raw)
    except (ValueError, UnicodeError) as error:
        raise EvidenceGap('SOURCE_PARSE_ERROR:' + relative) from error
    receipt = {'path': relative, 'file_bytes_sha256': expected, 'bytes': len(raw),
               'stat': [after.st_size, after.st_mtime_ns, after.st_ino], 'validation': 'PASS'}
    S['source_reads'][relative] = {'receipt': receipt, 'value': value}
    return value


def source(role):
    need(role in S['inputs'], 'PINNED_INPUT_NOT_VERIFIED:' + role)
    binding = PINNED_INPUTS[role]
    return read_bound(binding)


def output_of(role, key, jsonl=False):
    report = source(role)
    need(isinstance(report.get('outputs'), dict) and key in report['outputs'],
         'DECLARED_OUTPUT_NOT_BOUND:' + role + ':' + key)
    return read_bound(report['outputs'][key], jsonl=jsonl)


def atomic_bytes(relative_directory, stem, raw, suffix):
    folder = project_path(relative_directory)
    folder.mkdir(parents=True, exist_ok=True)
    digest = sha(raw)
    target = folder / (stem + '.' + digest + '.' + suffix)
    status = 'REUSED_IDENTICAL'
    if target.exists():
        need(target.read_bytes() == raw, 'CONTENT_ADDRESS_COLLISION')
    else:
        fd, temp_name = tempfile.mkstemp(prefix='.nb22b-', dir=str(folder))
        try:
            with os.fdopen(fd, 'wb') as handle:
                handle.write(raw); handle.flush(); os.fsync(handle.fileno())
            try:
                os.link(temp_name, target)
                status = 'CREATED'
            except FileExistsError:
                need(target.read_bytes() == raw, 'CONCURRENT_CONTENT_COLLISION')
        finally:
            Path(temp_name).unlink(missing_ok=True)
    saved = target.read_bytes()
    need(sha(saved) == digest and saved == raw, 'INDEPENDENT_DISK_RELOAD_FAILED')
    receipt = {'path': target.relative_to(ROOT).as_posix(), 'file_bytes_sha256': digest,
               'bytes': len(raw), 'reload_validation': 'PASS'}
    if not any(r['path'] == receipt['path'] for r in S['artifacts']):
        S['artifacts'].append(receipt)
    return receipt


def save_json(stem, value):
    # Round-trip before writing catches tuples, non-string keys and NaN at the producer.
    raw = canonical(value)
    need(_boot_decode(raw) == value, 'NON_JSON_NATIVE_OUTPUT')
    return atomic_bytes('reports/phase2/quality_improvement/NB22B.v1', stem, raw, 'json')


def save_rows(stem, rows):
    return atomic_bytes('reports/phase2/quality_improvement/NB22B.v1', stem,
                        b''.join(canonical(r) + b'\n' for r in rows), 'jsonl')


def unique(rows, key):
    result = {}
    for r in rows:
        need(isinstance(r, dict) and isinstance(r.get(key), str) and r[key] not in result,
             'MISSING_OR_DUPLICATE_ID:' + key)
        result[r[key]] = r
    return result


def metric(order, gold):
    need(bool(gold) and len(order) == len(set(order)), 'INVALID_METRIC_POPULATION')
    flags = [int(cid in gold) for cid in order]
    values = {}
    for k in (5, 10):
        hits = sum(flags[:k])
        ideal = math.fsum(1.0 / math.log2(i + 2) for i in range(min(k, len(gold))))
        values.update({f'hit_at_{k}': float(hits > 0), f'precision_at_{k}': hits / k,
                       f'recall_at_{k}': hits / len(gold),
                       f'ndcg_at_{k}': math.fsum(v / math.log2(i + 2) for i, v in enumerate(flags[:k])) / ideal})
    first = next((i + 1 for i, v in enumerate(flags) if v), None)
    values['reciprocal_rank'] = 1.0 / first if first else 0.0
    return values


def means(rows):
    need(bool(rows), 'EMPTY_METRIC_POPULATION')
    names = set(rows[0])
    need(all(set(r) == names for r in rows), 'INCONSISTENT_METRIC_SCHEMA')
    return {k: math.fsum(r[k] for r in rows) / len(rows) for k in sorted(names)}


def rank_ids(row, depth):
    items = row['candidates']
    need(len(items) == depth, 'UNEXPECTED_CANDIDATE_DEPTH')
    need([r['rank'] for r in items] == list(range(1, depth + 1)), 'RANK_SEQUENCE_CONFLICT')
    ids = [r['chunk_id'] for r in items]
    need(len(set(ids)) == depth, 'DUPLICATE_RANKED_CHUNK')
    return ids


def subtask(number, status, detail, evidence=None):
    need(status in {'COMPLETE', 'COMPLETE_IN_SCOPE', 'BLOCKED', 'DEFERRED', 'FAILED'}, 'UNKNOWN_SUBTASK_STATUS')
    return {'id': number, 'status': status, 'detail': detail, 'evidence': evidence or []}


def run_action(number, worker):
    spec = next(a for a in CHECKLIST if a['number'] == number)
    start = time.monotonic()
    calls_before = S['new_api_calls']
    print(f'NB22B — اقدام {number}: {spec["title"]}؛ {len(spec["subtasks"])} زیرکار', flush=True)
    try:
        value = worker()
    except EvidenceGap as error:
        value = {'status': 'BLOCKED_BY_EXPLICIT_PREREQUISITE', 'reason': str(error),
                 'subtasks': [subtask(x['id'], 'BLOCKED', str(error)) for x in spec['subtasks']],
                 'absence_projectwide_claimed': False}
    need(isinstance(value, dict), 'ACTION_RESULT_SCHEMA')
    need({x['id'] for x in value['subtasks']} == {x['id'] for x in spec['subtasks']}, 'SUBTASK_ACCOUNTING_CONFLICT')
    need(len(value['subtasks']) == len(spec['subtasks']), 'DUPLICATE_SUBTASK_RESULT')
    value.update({'action': number, 'title_fa': spec['title'], 'new_api_calls': S['new_api_calls'] - calls_before,
                  'historical_files_modified': False, 'health_deferral_preserved': True})
    receipt = save_json(f'A{number:02d}.result', value) if ROOT is not None else None
    S['actions'][str(number)] = {'result': value, 'output': receipt}
    print(json.dumps({'action': number, 'status': value['status'],
                      'subtask_statuses': {x['id']: x['status'] for x in value['subtasks']},
                      'output': receipt, 'summary': value.get('run_summary', {}), 'elapsed_seconds': round(time.monotonic() - start, 3),
                      'release_acceptance_granted': value.get('release_acceptance_granted', False),
                      'new_api_calls': S['new_api_calls'] - calls_before}, ensure_ascii=False, indent=2), flush=True)
    return value
