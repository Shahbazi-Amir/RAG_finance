import ast,contextlib,hashlib,io,json,os,pathlib,tempfile,shutil,time,sys
sys.path.insert(0,str(pathlib.Path("notebook_build/validation_deps").resolve()))
NOTEBOOK=pathlib.Path('deliverables/22b_quality_improvement_and_acceptance.ipynb').resolve()
nb=json.loads(NOTEBOOK.read_text());codes=[''.join(c['source']) for c in nb['cells'] if c['cell_type']=='code']
can=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
checks=[]
def record(name,ok,details=None):
 assert ok,(name,details)
 checks.append({'check':name,'status':'PASS','details':details})
record('all_code_cells_parse',all(ast.parse(x) is not None for x in codes),len(codes))
record('all_code_cells_python311_grammar',all(ast.parse(x,feature_version=(3,11)) is not None for x in codes),len(codes))
try:
 import nbformat
 nbformat.validate(nb); record('nbformat_schema',True)
except ImportError:record('notebook_json_structure',nb['nbformat']==4,'nbformat package unavailable; full nbformat schema validation not claimed')
record('all_markdown_rtl',all('dir="rtl"' in ''.join(c['source']) and '</div>' in ''.join(c['source']) for c in nb['cells'] if c['cell_type']=='markdown'))
record('source_fingerprint',hashlib.sha256(can(codes)).hexdigest()==nb['metadata']['nb22b']['code_source_sha256'])

def execute_in(root,notebook):
 saved=os.environ.get('RAG_FINANCE_ROOT');os.environ['RAG_FINANCE_ROOT']=str(root)
 namespace={};buffer=io.StringIO()
 try:
  with contextlib.redirect_stdout(buffer):
   for cell in notebook['cells']:
    if cell['cell_type']=='code':exec(compile(''.join(cell['source']),'<NB22B-validation>','exec'),namespace)
 finally:
  if saved is None:os.environ.pop('RAG_FINANCE_ROOT',None)
  else:os.environ['RAG_FINANCE_ROOT']=saved
 return namespace,buffer.getvalue()

def setup_root(root,notebook):
 (root/'notebooks/phase2').mkdir(parents=True)
 marker=root/'data/Road_Maps/RAG_finance_phase2_modular_notebooks_execution_plan.md';marker.parent.mkdir(parents=True);marker.write_text('Fixture marker only')
 (root/'notebooks/phase2/22b_quality_improvement_and_acceptance.ipynb').write_text(json.dumps(notebook,ensure_ascii=False))

start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='nb22b-missing-') as temp:
 root=pathlib.Path(temp);setup_root(root,nb);ns,log=execute_in(root,nb)
 record('run_all_missing_prerequisites_no_unhandled_exception',len(ns['S']['actions'])==14)
 record('missing_evidence_never_grants_acceptance',ns['A14']['release_acceptance_granted'] is False)
 record('all64_dispositions_present_on_missing_inputs',sum(ns['A14']['subtask_status_counts'].values())==64)
 # Known analytical metrics: two gold items, relevant ranks1/3. This checks denominator/discount behavior.
 m=ns['metric'](['a','x','b'],{'a','b'})
 record('known_metric_denominators',m['recall_at_5']==1 and m['precision_at_5']==.4 and m['reciprocal_rank']==1)
 expected=(1+1/2)/(1+1/__import__('math').log2(3))
 record('known_ndcg_discount',abs(m['ndcg_at_5']-expected)<1e-14)
 try:ns['_boot_decode']('{"a":1,"a":2}');raised=False
 except ValueError:raised=True
 record('duplicate_json_keys_rejected',raised)
 try:ns['save_json']('bad',{'a':(1,2)});raised=False
 except ns['EvidenceGap']:raised=True
 record('tuple_json_roundtrip_rejected_before_write',raised)
 r=ns['save_json']('idempotence',{'a':[1,2],'b':'سلام'});rr=ns['save_json']('idempotence',{'a':[1,2],'b':'سلام'})
 record('identical_atomic_save_reused',r==rr)
 try:ns['project_path']('../outside');raised=False
 except ns['EvidenceGap']:raised=True
 record('path_traversal_rejected',raised)
 # A changed file cannot reuse the current-process validation receipt.
 b={'path':'fixture.change.json','file_bytes_sha256':hashlib.sha256(b'{"x":1}').hexdigest()}
 (root/b['path']).write_bytes(b'{"x":1}');ns['read_bound'](b)
 (root/b['path']).write_bytes(b'{"x":2}')
 try:ns['read_bound'](b);raised=False
 except ns['EvidenceGap']:raised=True
 record('changed_cached_file_rejected',raised)

# Integration fixture uses the actual native field schemas and full population sizes.
# It is intentionally synthetic and makes no claim about production performance.
with tempfile.TemporaryDirectory(prefix='nb22b-fixture-') as temp:
 root=pathlib.Path(temp);pins={}
 def write(role,value,jsonl=False,path=None):
  path=path or f'fixtures/{role}.json'+('l' if jsonl else '')
  p=root/path;p.parent.mkdir(parents=True,exist_ok=True)
  raw=b''.join(can(r)+b'\n' for r in value) if jsonl else can(value)
  p.write_bytes(raw);r={'path':path,'file_bytes_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
  if role: pins[role]=r
  return r
 ctx=json.loads(pathlib.Path('notebook_build/review_context.json').read_text())
 chunks=[{'chunk_id':f'c{i:04d}','source_type':'book','source_id':f'source{i:04d}','content':'متن شاهد',
          'member_locators':[{'locator':{'id':i}}],'member_document_ids':[f'd{i:04d}']} for i in range(3488)]
 golden=[];hybrid=[];reranked=[];mapping=hashlib.sha256()
 for i in range(3813):
  q=f'q{i:04d}';c=i%3488;split='development' if i<2664 else 'test'
  golden.append({'candidate_id':q,'source_types':['book'],'evidence_locators':[{'source_locator':{'id':c}}],
                 'evaluation_content':{'question':'سؤال نمونه'},'document_ids':[f'd{c:04d}']})
  ids=[f'c{(c+j)%3488:04d}' for j in range(100)]
  hybrid.append({'candidate_id':q,'split':split,'candidates':[{'chunk_id':v,'rank':j+1,'hybrid_score':100-j} for j,v in enumerate(ids)]})
  reranked.append({'candidate_id':q,'split':split,'candidates':[{'chunk_id':v,'rank':j+1,'reranker_score':float(100-j),'hybrid_rank':j+1} for j,v in enumerate(ids[:50])]})
  encoded=can({'candidate_id':q,'relevant_chunk_ids':[ids[0]]});mapping.update(len(encoded).to_bytes(8,'big'));mapping.update(encoded)
 data={role:write(None,rows,True,f'fixtures/{role}.jsonl') for role,rows in [('chunks',chunks),('golden',golden),('hybrid',hybrid),('reranker',reranked)]}
 perfect={'hit_at_5':1.0,'hit_at_10':1.0,'recall_at_5':1.0,'recall_at_10':1.0,'precision_at_5':.2,'precision_at_10':.1,'ndcg_at_5':1.0,'ndcg_at_10':1.0,'reciprocal_rank':1.0}
 write('NB22_C056',{'independent_recomputation_complete':True,'all_recorded_metric_comparisons_match':True,
       'input_file_receipts':data,'gold_mapping':{'recomputed_sha256':mapping.hexdigest()},
       'computed_metrics':{'development':perfect,'test':perfect}})
 write('NB22_C057',{'blocked_metric_count':12,'blocked_metric_entries':ctx['blocked_metric_entries'],
       'contract':ctx['contract'],'recorded_gate_status_counts':ctx['recorded_gate_status_counts']})
 write('NB21C_C025',ctx['contract'])
 write('NB22_C054',{'release_acceptance_granted':False,'confirmed_recorded_metrics':[
       {'field':'/abstention_metrics/'+k,'value':v,'source_value_match':True} for k,v in [('precision',.42857142857),('recall',1.0),('f1',.6)]]})
 write('NB22_C054_HANDOFF',{'release_acceptance_granted':False})
 write('NB22_C058',{'status':'FIXTURE_REMAINING_WORK_INVENTORY'})
 parent=write(None,{'files':[]},path='fixtures/parent_checkpoint.json')
 write('NB22_C047',{'release_acceptance_granted':False,'checkpoint_manifest':parent})
 write('NB22_C046',{'checkpoint_manifest':parent})
 packets=[]
 for i in range(1149):
  q=f'test{i:04d}';claim={'claim_text':'متن شاهد','claim_type':'FACTUAL','evidence_ids':['e1']}
  response={'answer_text':'متن شاهد','claims':[claim]};document=can(response).decode()
  support={'candidate_id':q,'response_sha256':hashlib.sha256(document.encode()).hexdigest(),
           'claim_results':[{'claim_index':0,'claim_text':claim['claim_text'],'claim_sha256':hashlib.sha256(can(claim)).hexdigest(),
              'evidence_ids':['e1'],'outcome':'SUPPORTED','supporting_spans':[{'evidence_id':'e1','start':0,'end':8,'quote':'متن شاهد'}]}]}
  packets.append({'candidate_id':q,'question':'سؤال نمونه برای بررسی ساختاری','response_document':document,'response_document_sha256':support['response_sha256'],
                  'decoded_response':response,'historical_support':support,'original_evidence':[{'evidence_id':'e1','text':'متن شاهد'}],
                  'recorded_requirements_from_action26':['نیاز نمونه'],
                  'previous_action26_output':{'candidate_id':q,'expected_behavior':'ANSWER_SUPPORTED','observed_behavior':'SUBSTANTIVE_RESPONSE'}})
 packets_receipt=write(None,packets,True,'fixtures/native_remaining_packets.jsonl')
 native_metric=write(None,[{'metric':'no_answer_precision_recall_f1','value':{'confusion_matrix':{'TP':0,'FP':0,'FN':0,'TN':1149},'evaluated_case_count':1149,'included_candidate_ids':[p['candidate_id'] for p in packets],'precision':None,'recall':None,'f1':None}}],path='fixtures/native_metric_table.json')
 write('NB21C_C068',{'outputs':{'complete_remaining_measurement_packets':packets_receipt,'metric_table':native_metric}})
 effective=write(None,[{'candidate_id':f's{i:04d}'} for i in range(1112)],True,'fixtures/safety1112.jsonl')
 write('NB21C_C040',{'outputs':{'effective1112':effective},'same_four_rule_scope':{'cases':1112},
       'full1149_accounting':{'population_count':1149,'new_scope_valid_judgments':1112,'legacy37_preserved_in_original_scope':37},
       'disputed_risk_review':{'status':'DISPUTED_FIXTURE'}})
 opened=write(None,[{'issue_id':f'i{i}'} for i in range(10)],path='fixtures/open10.json')
 specs=write(None,[{'regression_spec_id':f'spec{i}'} for i in range(322)],path='fixtures/specs322.json')
 write('NB21C_C078',{'outputs':{'open_reviews':opened,'preserved_regression_specs':specs}})
 write('NB21C_C063',{'status':'FIXTURE_FROZEN_PLAN'})
 # Replace only test fixture pin constants; all executable action code remains identical.
 testnb=json.loads(json.dumps(nb));c=testnb['cells'][4] if False else next(c for c in testnb['cells'] if c['cell_type']=='code' and ''.join(c['source']).startswith('# NB22B-C002'))
 s=''.join(c['source']);a=s.index('PINNED_INPUTS = ');b=s.index('\n\nCHECKLIST =',a)
 s=s[:a]+'PINNED_INPUTS = '+repr(pins)+s[b:]
 s=s.replace("'semantic_review': {'enabled': True", "'semantic_review': {'enabled': False")
 c['source']=s.splitlines(keepends=True)
 testcodes=[''.join(c['source']) for c in testnb['cells'] if c['cell_type']=='code'];testnb['metadata']['nb22b']['code_source_sha256']=hashlib.sha256(can(testcodes)).hexdigest()
 setup_root(root,testnb);before={r['path']:hashlib.sha256((root/r['path']).read_bytes()).hexdigest() for r in data.values()}
 ns,log=execute_in(root,testnb)
 record('native_schema_full_population_fixture_run_all',len(ns['S']['actions'])==14)
 record('fixture_all3813_mapped_no_dev_exclusions',len(ns['S']['memory']['dev']['ids'])==2664)
 record('fixture_cached12_variants_executed',ns['A05']['variant_count']==12)
 record('fixture_nonimproving_variants_do_not_force_promotion',ns['A06']['status']=='NO_IMPROVING_VARIANT_BASELINE_RETAINED')
 record('fixture_semantic_strings_decoded_and_claims_reused',ns['A07']['recorded_claim_units']==1149)
 record('fixture_exact_span_and_link_validation',ns['A08']['distinct_link_count']==1149)
 record('fixture_no_acceptance_from_perfect_retrieval_alone',ns['A14']['release_acceptance_granted'] is False)
 record('fixture_64_subtasks_accounted',sum(ns['A14']['subtask_status_counts'].values())==64)
 record('historical_input_files_not_modified',all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in before.items()))
 ns2,log2=execute_in(root,testnb)
 record('fixture_second_run_all_resume',len(ns2['S']['actions'])==14 and ns2['A14']['release_acceptance_granted'] is False)
 record('fixture_second_run_no_model_api_calls',ns2['S']['new_api_calls']==0)
 # Exercise a frozen non-baseline branch, without using Test to select it.
 comparison=ns2['historical_retrieval_evaluation']({'selected_variant':'cached_rrf_k10_w0.25'})
 record('fixture_frozen_rrf_branch_full1149',comparison['population_count']==1149 and comparison['excluded_queries']==0)
 record('fixture_historical_nonregression_uses_source_component_interval',all(x['status']=='PASS' for x in comparison['paired_nonregression_checks'].values()))
 record('fixture_mrr10_separate_from_mrr50',set(['reciprocal_rank_at_10','reciprocal_rank_at_50']).issubset(comparison['selected_metrics']))
 # All three queries connect through source_id, although chunks/documents are distinct.
 graph={'ids':['a','b','c'],'gold':{'a':{'1'},'b':{'2'},'c':{'3'}},
        'chunks':{'1':{'source_id':'shared'},'2':{'source_id':'shared'},'3':{'source_id':'separate'}}}
 components=ns2['source_components'](graph)
 record('producer_source_id_component_graph',components['a']==components['b'] and components['a']!=components['c'])
 ns2['S']['memory']['historical_selected_evaluation']=comparison
 ns2['S']['memory']['gap_measurements']={k:{'lower_bound':1.,'upper_bound':1.,'review_coverage':1.} for k in ['citation_correctness','citation_locator_accuracy']}
 gate=ns2['action14']();by_metric={x['metric']:x for x in gate['metric_gates_for_new_candidate']}
 record('measured_retrieval_family_pass_visible_without_product_acceptance',by_metric['recall_at_k']['status']=='PASS' and by_metric['ndcg_at_k_binary']['status']=='PASS' and gate['release_acceptance_granted'] is False)
 record('model_scope_pass_not_product_semantic_pass',by_metric['citation_correctness']['available_scoped_check']['status']=='PASS' and by_metric['citation_correctness']['status']=='BLOCKED')
 record('local_release_not_blocked_by_unrequested_publication',not any(x['gate']=='whole_product_public_distribution' for x in gate['gate_conditions']))
 ns2['CONFIG']['release_distribution_scope']='PUBLIC';public=ns2['action14']()
 record('public_release_requires_explicit_distribution_clearance',any(x['gate']=='whole_product_public_distribution' and x['status']=='NOT_CLEARED' for x in public['gate_conditions']))
 fixture_destination=os.environ.get('NB22B_KERNEL_FIXTURE_OUTPUT')
 if fixture_destination:
  shutil.copytree(root,pathlib.Path(fixture_destination))


# Real tracked cache data: verify bytes and native identity/rank relationships without claiming semantic Gold.
real_base=pathlib.Path('repository_snapshot')
real_specs={
 'golden':('artifacts/phase2/golden_dataset_v2/golden_dataset_v2.jsonl','b9ca18e710686ddca48a25c637840b716adb306717cafd8ec7c96ce9e182e6f2'),
 'hybrid':('data/phase2/retrieval/hybrid_retrieval_v1/hybrid_candidates_v1.jsonl','f54277680f3d20681b1585915f54bb4485ecb1fcccb15c27df0061ff0725d19a'),
 'reranker':('data/phase2/retrieval/reranker_v1/reranked_candidates_v1.jsonl','d00285bbf3865fbd51041db1612b9fdc17e9778273ea6d136978906a07268b7a')}
real={}
for role,(relative,expected) in real_specs.items():
 raw=(real_base/relative).read_bytes()
 record('real_'+role+'_file_bytes',hashlib.sha256(raw).hexdigest()==expected)
 rows=[json.loads(line) for line in raw.splitlines() if line.strip()]
 ids={r['candidate_id']:r for r in rows};record('real_'+role+'_3813_unique_ids',len(rows)==len(ids)==3813)
 real[role]=ids
record('real_saved_population_parity',set(real['golden'])==set(real['hybrid'])==set(real['reranker']))
counts={};samepool=0
for q,h in real['hybrid'].items():
 r=real['reranker'][q];assert h['split']==r['split']
 counts[h['split']]=counts.get(h['split'],0)+1
 assert [x['rank'] for x in h['candidates']]==list(range(1,101))
 assert [x['rank'] for x in r['candidates']]==list(range(1,51))
 assert {x['chunk_id'] for x in h['candidates'][:50]}=={x['chunk_id'] for x in r['candidates']}
 samepool+=1
record('real_3813_same50_pool_and_rank_sequences',samepool==3813)
record('real_split_counts',counts=={'development':2664,'test':1149},counts)
summary={'schema_version':'NB22B_BUILD_VALIDATION_V1','status':'CHECKS_PASSED','checks':checks,
 'tested_production_code_fingerprint':nb['metadata']['nb22b']['code_source_sha256'],
 'elapsed_seconds':round(time.monotonic()-start,3),'real_mac_full_run_all_verified':False,
 'real_model_inference_branch_executed_here':False,'real_full_product_acceptance_established':False,
 'coverage_limit':'Synthetic native-schema integration and missing-prerequisite tests are not live product evaluation.'}
pathlib.Path('deliverables/NB22B_build_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
