import pathlib,json,os,contextlib,io,copy,tempfile,hashlib,time
base=pathlib.Path('repository_snapshot').resolve();os.environ['RAG_FINANCE_ROOT']=str(base);ns={}
exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns)
ns['PINNED_INPUTS']=json.loads(pathlib.Path('notebook_build/pins.json').read_text());ns['CHECKLIST']=json.loads(pathlib.Path('notebook_build/actions.json').read_text())
with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
ns['CONFIG']['semantic_review']['enabled']=False
exec(pathlib.Path('notebook_build/03_helpers.py').read_text(),ns);exec(pathlib.Path('notebook_build/review_engine.py').read_text(),ns)
policy=json.loads(pathlib.Path('notebook_build/review_context.json').read_text())
ns['frozen_metric']=lambda name:next(r['record'] for r in policy['blocked_metric_entries'] if r['record']['metric']==name)
# Exercise worker bodies against the real uploaded C068; policies use the already inspected C057 saved-output context.
for name in ['10_action07.py','11_action08.py']:
 text=pathlib.Path('notebook_build',name).read_text();text=text[:text.rfind('\nA0')]
 exec(text,ns)
# action07 defines its own source-backed frozen_metric: explicitly use the captured real C057 context for this isolated adapter test.
ns['frozen_metric']=lambda name:next(r['record'] for r in policy['blocked_metric_entries'] if r['record']['metric']==name)
a7=ns['action07']();a8=ns['action08']();checks=[]
def ok(name,test):
 assert test,name;checks.append({'check':name,'status':'PASS'})
ok('real_response_and_claim_hash_binding_1149',a7['response_count']==1149 and a7['recorded_claim_units']==1187)
ok('real_reference_requirement_units_1407',a7['recorded_requirement_units']==1407)
ok('real_distinct_citation_links_1292',a8['distinct_link_count']==1292)
ok('real_exact_source_spans_1686',a8['exact_spans_checked']==1686)
ok('real_gap_review_plan_no_paid_dispatch',a7['semantic_review_dispatch']['dispatch_status']=='DISABLED_BY_RUN_CONFIG')
# Recompute real no-answer counts from the exact producer eligibility rule.
text=pathlib.Path('notebook_build/12_action09.py').read_text();exec(text[:text.rfind('\nA09=')],ns)
a9=ns['action09']();ab=a9['historical_measurement']
ok('real_abstention_confusion_matrix_recomputed',ab['confusion_matrix']=={'TP':12,'FP':16,'FN':0,'TN':1103})
ok('real_abstention_eligible_1131_and_f1_0_6',ab['evaluated_case_count']==1131 and ab['excluded_count']==18 and abs(ab['f1']-.6)<1e-14)
packets=ns['semantic_packets']();data=ns['gap_review_input'](next(iter(packets.values())))
evidence={r['evidence_id']:r['text'] for r in data['evidence']}
result={'candidate_id':data['candidate_id'],'response_document_sha256':data['response_document_sha256'],
 'requirement_coverage':[{'requirement_index':r['requirement_index'],'assessment':'COVERED',
                        'answer_quotes':[data['answer_text']],'reason_fa':'Fixture: mechanical validator only.'} for r in data['reference_requirements']],
 'citation_links':[{'claim_index':r['claim_index'],'evidence_id':r['evidence_id'],'support':'SUPPORTED',
                    'intended_location':'CORRECT','evidence_quotes':[evidence[r['evidence_id']][:20]],
                    'reason_fa':'Fixture: quote identity only, not a semantic truth assertion.'} for r in data['required_citation_links']],
 'additional_factual_units':[],'attribution_assertions':[],
 'factual_extraction_review':'COMPLETE_IN_MODEL_REVIEW_SCOPE',
 'reference_requirement_qualification':'MODEL_PROPOSAL_ONLY','reason_fa':'Synthetic response used only to test mechanical checks.'}
ok('new_gap_schema_positive_fixture_validates',ns['validate_gap_review'](data,result)['status']=='LOCALLY_VALID_MODEL_GAP_REVIEW')
for label,mutate in [
 ('wrong_response_hash',lambda x:x.update(response_document_sha256='0'*64)),
 ('missing_required_link',lambda x:x['citation_links'].pop()),
 ('duplicate_requirement',lambda x:x['requirement_coverage'].append(copy.deepcopy(x['requirement_coverage'][0]))),
 ('invented_source_quote',lambda x:x['citation_links'][0].update(evidence_quotes=['THIS QUOTE DOES NOT OCCUR IN THE DESIGNATED EVIDENCE']))]:
 bad=copy.deepcopy(result);mutate(bad)
 try:ns['validate_gap_review'](data,bad);raised=False
 except ns['EvidenceGap']:raised=True
 ok('reject_'+label,raised)
job=ns['prepare_gap_jobs']({data['candidate_id']:packets[data['candidate_id']]})[0][0]
oldroot=ns['ROOT']
with tempfile.TemporaryDirectory(prefix='nb22b-attempt-test-') as temp:
 root=pathlib.Path(temp);ns['ROOT']=root;d=root/'job';d.mkdir()
 attempt={'job_key':job['key'],'request_sha256':job['request_sha256'],'dispatch_epoch':time.time()}
 ns['immutable_file'](d/'attempt.json',ns['canonical'](attempt))
 ok('unknown_attempt_is_not_ready_for_resend',ns['parse_gap_body'](job,d)['status']=='OUTCOME_UNKNOWN_NO_AUTOMATIC_RESEND')
 body={'model':'DeepSeek-V4-Flash','choices':[{'finish_reason':'stop','message':{'content':json.dumps(result,ensure_ascii=False)}}],
       'usage':{'prompt_tokens':100,'completion_tokens':200}}
 raw=ns['canonical'](body);ns['immutable_file'](d/'response.body',raw)
 ns['immutable_file'](d/'receipt.json',ns['canonical']({'request_sha256':job['request_sha256'],'body_sha256':ns['sha'](raw),
                                                    'http_status':200,'elapsed_seconds':1.25}))
 checked=ns['parse_gap_body'](job,d)
 ok('raw_response_receipt_and_schema_join',checked['status']=='LOCALLY_VALID_MODEL_GAP_REVIEW')
 ok('model_review_not_relabelled_independent_gold',checked['human_gold_claimed'] is False)
 bad=copy.deepcopy(job);bad['request_sha256']='0'*64
 try:ns['parse_gap_body'](bad,d);raised=False
 except ns['EvidenceGap']:raised=True
 ok('cached_response_wrong_request_binding_rejected',raised)
 ns['ROOT']=oldroot
# Conservatism: an undetermined reviewed link must remain in the upper bound.
uncertain=copy.deepcopy(result)
for r in uncertain['citation_links']:r['support']='UNDETERMINED';r['intended_location']='UNDETERMINED';r['evidence_quotes']=[]
states={'x':{'candidate_id':data['candidate_id'],'status':'LOCALLY_VALID_MODEL_GAP_REVIEW','result':uncertain}}
agg=ns['aggregate_gap_measurements']({data['candidate_id']:packets[data['candidate_id']]},states)
ok('unknown_link_upper_bound_preserved',agg['citation_correctness']['lower_bound']==0 and agg['citation_correctness']['upper_bound']==1)
ok('zero_attribution_denominator_not_pass',agg['attribution_correctness']['conditional_micro'] is None)
# Budget gate must stop before endpoint/config/dispatch; even a valid payload is not spending authorization.
oldopts=copy.deepcopy(ns['CONFIG']['semantic_review'])
ns['S']['saved_code_identity_valid']=True
ns['CONFIG']['semantic_review'].update({'enabled':True,'authorized_cap_toman':100,'maximum_new_requests':1149})
jobs,plan=ns['prepare_gap_jobs'](packets)
try:ns['run_gap_jobs'](jobs,plan);raised=False
except ns['EvidenceGap'] as error:raised=str(error)=='WHOLE_LOGICAL_PACKAGE_RESERVE_EXCEEDS_AUTHORIZED_CAP'
ok('whole_logical_package_budget_checked_before_dispatch',raised and ns['S']['new_api_calls']==0)
ns['CONFIG']['semantic_review']=oldopts
report={'schema_version':'NB22B_REAL_C068_ADAPTER_AND_GAP_RUNNER_VALIDATION_V1','checks':checks,
        'status':'PASS','real_packet_count':1149,'new_api_calls':0,
        'actual_provider_dispatch_tested':False,'scope':'Real C068 source adapters plus synthetic validator/receipt cases; not model semantic accuracy or final acceptance.',
        'semantic_gap_review_plan':a7['semantic_review_dispatch']}
pathlib.Path('deliverables/NB22B_received_C068_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
