# NB22B-C015 — Action 12: frozen-candidate historical evaluation; genuine independence remains separate.
def historical_retrieval_evaluation(selection):
    need('data_receipts' in S['memory'] and 'dev' in S['memory'],'BOUND_RETRIEVAL_INPUTS_REQUIRED')
    data=S['memory']['data_receipts'];chunks=S['memory']['dev']['chunks']
    golden=unique(read_bound(data['golden'],jsonl=True),'candidate_id')
    hybrid=unique(read_bound(data['hybrid'],jsonl=True),'candidate_id')
    reranker=unique(read_bound(data['reranker'],jsonl=True),'candidate_id')
    ids=sorted(q for q,r in hybrid.items() if r['split']=='test')
    need(len(ids)==1149 and all(reranker[q]['split']=='test' for q in ids),'HISTORICAL_TEST_POPULATION_CHANGED')
    # Source-locator mapping is the same reviewed producer contract; no test values enter selection.
    locators=collections.defaultdict(set)
    for cid,c in chunks.items():
        for member in c['member_locators']:locators[canonical(member['locator'])].add(cid)
    gold={}
    for q in ids:
        relevant=set()
        for e in golden[q]['evidence_locators']:relevant.update(locators[canonical(e['source_locator'])])
        need(bool(relevant),'HISTORICAL_TEST_GOLD_UNMAPPED:'+q);gold[q]=relevant
    test={'ids':ids,'gold':gold,'golden':{q:golden[q] for q in ids},'chunks':chunks,
          'questions':{q:golden[q]['evaluation_content']['question'].strip() for q in ids},
          'hybrid':{q:hybrid[q] for q in ids},'reranker':{q:reranker[q] for q in ids}}
    baseline={q:metric(rank_ids(reranker[q],50),gold[q]) for q in ids}
    reference=source('NB22_C056')['computed_metrics']['test'];baseline_mean=means(list(baseline.values()))
    need(all(abs(baseline_mean[k]-reference[k])<=1e-12 for k in baseline_mean),'TEST_BASELINE_REPLAY_CONFLICT')
    test['baseline']=baseline;name=selection['selected_variant'];orders={};local=None;local_inventory=None
    if name=='baseline_reranker50':
        orders={q:rank_ids(reranker[q],50) for q in ids}
    elif name.startswith('cached_rrf_k'):
        match=re.fullmatch(r'cached_rrf_k(\d+)_w(\d+\.\d+)',name)
        need(match is not None,'FROZEN_RRF_VARIANT_ID_INVALID')
        k=int(match.group(1));w=float(match.group(2))
        need(k in CONFIG['rrf_constants'] and w in CONFIG['rrf_weights'],'VARIANT_OUTSIDE_FROZEN_GRID')
        for q in ids:
            hr={r['chunk_id']:r['rank'] for r in hybrid[q]['candidates']};rr={r['chunk_id']:r['rank'] for r in reranker[q]['candidates']}
            orders[q]=sorted(rr,key=lambda c:(-(w/(k+rr[c])+(1-w)/(k+hr[c])),c))
    elif name=='local_onnx_depth100':
        remaining=CONFIG['maximum_local_seconds']-S['memory'].get('local_development_elapsed_seconds',0)
        local=local_depth100(test,S['memory']['plan_receipt'],maximum_seconds=remaining)
        local_inventory=register_local_score_assets(local,S['memory']['plan_receipt'],'A12.local_score_cache_inventory')
        need(local['complete'],'SELECTED_TEST_DEPTH100_INCOMPLETE_RESUME_LOCAL_CACHE_NO_PARTIAL_METRIC')
        orders=local['orders']
    else:raise EvidenceGap('SELECTED_RETRIEVAL_VARIANT_NOT_SUPPORTED')
    need(set(orders)==set(ids),'HISTORICAL_TEST_VARIANT_POPULATION_CONFLICT')
    measured={q:metric(orders[q][:50],gold[q]) for q in ids}
    for collection in (baseline,measured):
        for row in collection.values():
            row['reciprocal_rank_at_10']=row['reciprocal_rank'] if row['reciprocal_rank']>=.1 else 0.0
            row['reciprocal_rank_at_50']=row['reciprocal_rank']
    baseline_mean=means(list(baseline.values()));observed=means(list(measured.values()))
    rows=[{'candidate_id':q,'split':'test','baseline':baseline[q],'variant':measured[q],
           'variant_minus_baseline':{k:measured[q][k]-baseline[q][k] for k in observed},
           'ranked_chunk_ids':orders[q]} for q in ids]
    receipt=save_rows('A12.historical_selected_retrieval',rows)
    uncertainty=paired_uncertainty(test,measured,scope='FROZEN_CANDIDATE_HISTORICAL_TEST_COMPARISON_NOT_PRISTINE_HOLDOUT')
    slices=[];slice_groups=collections.defaultdict(list)
    for q in ids:
        types={chunks[cid]['source_type'] for cid in gold[q]}
        slice_groups[next(iter(types)) if len(types)==1 else 'MIXED'].append(q)
    for source_type,selected_ids in sorted(slice_groups.items()):
        subset={**test,'ids':selected_ids}
        slices.append({'slice':source_type,'definition':'EXACT_REFERENCE_CHUNK_SOURCE_TYPE_OR_MIXED',
                       'query_count':len(selected_ids),
                       'baseline':means([baseline[q] for q in selected_ids]),
                       'variant':means([measured[q] for q in selected_ids]),
                       'uncertainty':paired_uncertainty(subset,measured,scope='HISTORICAL_SOURCE_TYPE_SLICE_EXPLORATORY')})
    margin=S['memory']['regression_policy']['allowed_deterioration']
    need(type(margin) in (int,float) and math.isfinite(margin) and margin>=0,'INVALID_FROZEN_NONREGRESSION_MARGIN')
    paired_checks={}
    for key,delta in {k:observed[k]-baseline_mean[k] for k in observed}.items():
        ci=(uncertainty.get('intervals') or {}).get(key)
        status='BLOCKED'
        if ci:
            if ci['lower']>=-margin:status='PASS'
            elif ci['upper']<-margin:status='FAIL'
        paired_checks[key]={'status':status,'variant_minus_baseline':delta,
                            'confidence_interval':ci,'allowed_deterioration':margin,
                            'rule':'LOWER_CONFIDENCE_BOUND_GE_NEGATIVE_ALLOWED_DETERIORATION',
                            'query_count':len(ids),'excluded_count':0}
    checks={name:{'value':observed[name],'threshold':threshold,
                  'absolute_status':'PASS' if observed[name]>=threshold else 'FAIL',
                  'gap_to_threshold':max(0.,threshold-observed[name])}
            for name,threshold in [('recall_at_10',.85),('ndcg_at_10',.75)]}
    return {'status':'FROZEN_CANDIDATE_HISTORICAL_TEST_EVALUATED','selected_variant':name,
            'population_count':len(ids),'excluded_queries':0,'baseline_metrics':baseline_mean,
            'selected_metrics':observed,'delta':{k:observed[k]-baseline_mean[k] for k in observed},
            'absolute_threshold_checks':checks,'paired_nonregression_checks':paired_checks,'source_type_slices':slices,'paired_uncertainty':uncertainty,'per_query_results':receipt,
            'local_score_cache_inventory':local_inventory,
            'reciprocal_rank_scope':'COMMON_STORED_TOP50',
            'unmeasured_reciprocal_rank_scopes':['MRR_AT100','FULL_RANKING'],
            'parameter_selection_used_these_results':False,'historical_test_is_pristine':False,
            'independent_final_product_evaluation_claimed':False,'new_product_answers_evaluated':False}


def action12():
    need('selection' in S['memory'],'DEVELOPMENT_SELECTION_FREEZE_REQUIRED')
    # Verify the persisted freeze before accessing the test-only orders/labels.
    frozen=read_bound(S['memory']['selection_receipt'])
    need(frozen==S['memory']['selection'],'SELECTION_CHANGED_AFTER_FREEZE')
    historical=source('NB22_C056');source('NB21C_C063')
    try:
        comparison=historical_retrieval_evaluation(frozen)
    except EvidenceGap as error:
        comparison={'status':'HISTORICAL_SELECTED_EVALUATION_BLOCKED','reason':str(error),
                    'partial_scores_not_promoted':True,'independent_final_product_evaluation_claimed':False}
    S['memory']['historical_selected_evaluation']=comparison
    decision={'selected_candidate':S['memory']['selection_receipt'],
              'selection_finished_before_new_test_evaluation':True,
              'historical_test':{'population':1149,'already_exposed':True,
                                 'previous_metrics':historical['computed_metrics']['test'],'new_frozen_comparison':comparison},
              'independent_holdout':{'status':'QUALIFIED_UNTOUCHED_POPULATION_NOT_BOUND',
                                     'old_test_relabelled_as_independent':False},
              'previous_frozen_plan':PINNED_INPUTS['NB21C_C063'],
              'final_product_measurement':None,
              'remaining_prerequisites':['Bind a qualified independent evaluation population.',
                                        'Produce and evaluate the selected live product response version under the frozen contract.']}
    product_evaluation=None;product_evaluation_gap=None
    if 'product_bound' in S['memory']:
        try:
            product_evaluation=independent_product_evaluation(S['memory']['product_bound'],S['memory']['product_response_states'])
        except EvidenceGap as error:product_evaluation_gap=str(error)
    else:product_evaluation_gap='VERSION_BOUND_PRODUCT_EXECUTION_CONTRACT_NOT_AVAILABLE'
    try:regression=execute_regression_suite()
    except EvidenceGap as error:regression={'status':'REGRESSION_SUITE_INPUT_GAP','reason':str(error)}
    decision['actual_regression_suite']=regression
    decision['qualified_product_evaluation']=product_evaluation
    decision['qualified_product_evaluation_gap']=product_evaluation_gap
    S['memory']['qualified_product_evaluation']=product_evaluation
    receipt=save_json('A12.final_evaluation_readiness_and_historical_comparison',decision)
    return {'status':'HISTORICAL_COMPARISON_RECORDED_INDEPENDENT_PRODUCT_EVALUATION_OPEN',
            'readiness':decision,'output_readiness':receipt,
            'subtasks':[subtask('12.1','COMPLETE','Persisted Development freeze verified before test-only evaluation.',[S['memory']['selection_receipt']]),
                        subtask('12.2','COMPLETE' if product_evaluation else 'BLOCKED','Qualified independent population consumed when explicitly bound; exposed historical Test is never relabelled.'),
                        subtask('12.3','COMPLETE_IN_SCOPE' if comparison['status']=='FROZEN_CANDIDATE_HISTORICAL_TEST_EVALUATED' else 'BLOCKED',
                                'Frozen selected retrieval evaluated historically, without API or policy retuning; independent final evaluation remains separate.',[receipt]),
                        subtask('12.4','COMPLETE_IN_SCOPE' if comparison['status']=='FROZEN_CANDIDATE_HISTORICAL_TEST_EVALUATED' else 'BLOCKED',
                                'Historical paired metrics and source-component uncertainty reported; no independent-product generalization.'),
                        subtask('12.5','COMPLETE_IN_SCOPE','Absolute retrieval limits and non-regression kept separate; no post-Test parameter changes.')]}
A12=run_action(12,action12)
