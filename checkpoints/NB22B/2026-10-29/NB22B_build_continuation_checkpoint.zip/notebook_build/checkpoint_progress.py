"""Capture only code/reports/approved receipts; exclude source data, keys, URLs, caches and dependencies."""
from pathlib import Path
import json,zipfile,hashlib
nb_path=Path('deliverables/22b_quality_improvement_and_acceptance.ipynb');nb=json.loads(nb_path.read_bytes())
state={'schema_version':'NB22B_BUILD_RESUME_STATE_V1','date':'2026-10-29','task_complete':False,
       'notebook_path':str(nb_path),'current_code_fingerprint':nb['metadata']['nb22b']['code_source_sha256'],
       'current_file_bytes_sha256':hashlib.sha256(nb_path.read_bytes()).hexdigest(),
       'library_checkpoint_id':'libfile_aee096e7664c8191b78defdc032a4594','last_observed_library_version':json.loads(Path('inspection/NB22B_checkpoint_identity.json').read_bytes())['current_version_number'],
       'current_stage':'121_SOFTWARE_CHECKS_PASS_17_FRESH_PROCESS_CELLS_PRODUCT_ACCEPTANCE_PENDING',
       'authorization':{'scope':'NB22B_HISTORICAL_SEMANTIC_GAPS_V1','cap_toman':1650000,'max_requests':1149,
                        'workers':18,'rpm':80,'generator_or_new_holdout_budget_included':False},
       'actual_model_provider_calls_here':0,
       'next_tasks':['Preserve this validated working notebook and its 121-check reports; actual Mac/model execution was not performed here.',
                     'Bind real selected-product inputs using existing project evidence; do not infer missing work from missing new-format contracts.',
                     'Execute the authorized historical semantic gap review only in its approved scope; generator/holdout authorization remains separate.',
                     'Inspect actual per-action results and resolve real quality/technical gaps before claiming all64 complete or release acceptance.'],
       'do_not_repeat':['Read40notebooks/11Goldenarchives again without a targeted need.',
                        'Request the already attached C068 ZIP again.',
                        'Ask again for the already approved historical semantic budget.',
                        'Reopen prior notebook health/NB21action48 deferral.',
                        'Treat exposed Test as untouched or model references as independent expert gold.'],
       'new_modules':['product_engine.py','regression_engine.py','context_bridge.py'],
       'context_bridge':{'pilot_max_cases':32,'split':'development','dispatch_enabled':False,
                        'context_configuration_canonical_hash':'f600583bba6646022c3eaf455e204a38a6c6f5bd3fe8aae8621be8d5d35a5835',
                        'validation':'Real Context packets/registry adapter with synthetic cohort scores; pure packer cap/budget tests.'},
       'source_module_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('notebook_build').glob('*.py')},
       'latest_reports':{p.name:json.loads(p.read_bytes()).get('status') for p in Path('deliverables').glob('*validation.json')}}
Path('inspection/NB22B_resume_state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
files=[p for p in Path('notebook_build').iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'} and 'dependencies_install' not in p.name]
files += [p for p in Path('deliverables').iterdir() if p.suffix in {'.md','.json','.ipynb'}]
for name in ['inspection/notebook_inventory.json','inspection/C068_received_validation.json','inspection/NB22B_resume_state.json','inspection/NB22B_checkpoint_identity.json','RAG_finance_action_first_consolidated_execution_protocol_fa.md']:
 p=Path(name)
 if p.is_file():files.append(p)
with zipfile.ZipFile('deliverables/NB22B_build_continuation_checkpoint.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p))
print(json.dumps({'status':'LOCAL_PROGRESS_CHECKPOINT_SAVED','stage':state['current_stage'],'code_fingerprint':state['current_code_fingerprint'],'files':len(files),'bytes':Path('deliverables/NB22B_build_continuation_checkpoint.zip').stat().st_size}))
