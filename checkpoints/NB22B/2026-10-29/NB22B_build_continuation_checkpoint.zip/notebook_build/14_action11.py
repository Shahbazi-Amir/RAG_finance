# NB22B-C014 — Action 11: actual-runtime boundary and operational measurement qualification.
def action11():
    context = source('NB22_C057'); rows = []
    product_calls_before=S['new_api_calls']
    pilot=None;pilot_gap=None
    try:pilot=prepare_development_generation_pilot()
    except EvidenceGap as error:pilot_gap=str(error)
    product=None;product_gap=None
    try:
        bound=product_contract();product=execute_product(bound)
        telemetry=product_telemetry(bound,product)
        telemetry_receipt=save_json('A11.actual_product_rpc_telemetry',telemetry)
        product={'plan':product['plan'],'plan_artifact':product['plan_artifact'],
                 'responses':product['responses'],'telemetry':telemetry_receipt,
                 'measurement_boundary':telemetry['scope']}
    except EvidenceGap as error:
        product_gap=str(error)
    judge_telemetry = gap_attempt_telemetry(S['memory'].get('gap_jobs', []))
    judge_telemetry_receipt = save_json('A11.actual_judge_telemetry', judge_telemetry)
    for name in ('cost', 'failure_rate', 'latency', 'token_usage'):
        original = frozen_metric(name)
        rows.append({'metric': name, 'status': 'MEASURED_IN_RPC_SCOPE' if product else 'BLOCKED',
                     'frozen_policy': original['frozen_policy'],
                     'existing_measurement_state': original['recorded_measurement_state'],
                     'new_live_generator_measurement': product['telemetry'] if product else None,
                     'reason': 'Actual RPC telemetry is attached; full boundary and compatible baseline are evaluated in action12.' if product else 'The explicit selected-product execution contract is not available or its prerequisite failed.'})
    protocol = {'generation_separate_from_judge_and_retrieval': True,
                'latency': {'boundary': 'REQUEST_ACCEPTED_TO_FINAL_DELIVERED_RESPONSE',
                            'statistics': ['p50', 'p95'], 'quantile': 'LINEAR',
                            'separate': ['warm', 'cold', 'hardware', 'timeouts', 'failed_attempts']},
                'failure_rate': {'units': ['eligible_query', 'unique_network_attempt'],
                                 'unknown_outcome_is_not_success': True},
                'token_usage': {'unique_provider_attempts': True,
                                'reasoning_and_cache_not_double_counted': True,
                                'missing_usage_is_not_zero': True},
                'cost': {'currency_and_tariff_required': True, 'judge_cost_is_not_generator_cost': True,
                         'estimate_is_not_invoice': True},
                'paid_dispatch': S['new_api_calls']>product_calls_before,
                'new_product_requests_this_action':S['new_api_calls']-product_calls_before,
                'new_request_count_established': product is not None,
                'reason_not_dispatched': product['plan'].get('dispatch_gate_reason') if product else product_gap}
    receipt = save_json('A11.runtime_measurement_qualification', {'metrics': rows, 'protocol': protocol})
    return {'status': 'PRODUCT_RUNTIME_AND_JUDGE_BOUNDARIES_RECORDED',
            'native_binding_readiness':native_readiness_ledger(product,pilot),
            'development_generation_pilot':pilot,'development_pilot_gap':pilot_gap,
            'product_execution': product, 'product_execution_gap': product_gap,
            'metric_qualification': rows, 'protocol': protocol, 'measurement_record': receipt, 'actual_judge_telemetry': judge_telemetry_receipt,
            'judge_telemetry_summary': {k:v for k,v in judge_telemetry.items() if k!='attempt_rows'},
            'subtasks': [subtask('11.1', 'COMPLETE_IN_SCOPE' if product else 'BLOCKED', 'Explicit profile/policy/prompt and returned model names are recorded when bound; Recovery is not silently treated as live Qwen.'),
                         subtask('11.2', 'COMPLETE_IN_SCOPE', 'Historical job telemetry retained in its judge/job boundary; not relabelled as generation measurement.'),
                         subtask('11.3', 'COMPLETE_IN_SCOPE', 'Required latency/failure boundaries and unknown outcome treatment recorded; values remain unavailable.'),
                         subtask('11.4', 'COMPLETE_IN_SCOPE', 'Unique usage/cost accounting rules preserved; missing values not replaced by zero.'),
                         subtask('11.5', 'COMPLETE_IN_SCOPE' if product and not product['plan'].get('dispatch_gate_reason') else 'BLOCKED', 'Product plan and separate dispatch gate are recorded; historical judge approval is not substituted.', [receipt])]}
A11 = run_action(11, action11)
