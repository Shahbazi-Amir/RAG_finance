import pathlib,json,os,tempfile,contextlib,io
ns={};checks=[]
def ok(name,value):
 assert value,name;checks.append({'check':name,'status':'PASS'})
root=pathlib.Path('repository_snapshot').resolve();os.environ['RAG_FINANCE_ROOT']=str(root)
exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns);ns['PINNED_INPUTS']={};ns['CHECKLIST']=[]
with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
for file in ['03_helpers.py','review_engine.py','product_engine.py','context_bridge.py']:exec(pathlib.Path('notebook_build',file).read_text(),ns)
# Actual bytes/records/joins are used; ranking/cohort scores below are synthetic adapter fixtures.
golden=ns['unique']([json.loads(line) for line in (root/'artifacts/phase2/golden_dataset_v2/golden_dataset_v2.jsonl').read_bytes().splitlines()],'candidate_id')
hybrid=ns['unique']([json.loads(line) for line in (root/'data/phase2/retrieval/hybrid_retrieval_v1/hybrid_candidates_v1.jsonl').read_bytes().splitlines()],'candidate_id')
ids=sorted(q for q in golden if hybrid[q]['split']=='development')
ns['S']['memory']['dev']={'ids':ids,'questions':{q:golden[q]['evaluation_content']['question'].strip() for q in ids},
 'baseline':{q:{'recall_at_10':0.5,'ndcg_at_10':0.5} for q in ids},'chunks':{}}
ns['S']['memory']['selection']={'selected_variant':'baseline_reranker50'}
ns['S']['memory']['selection_receipt']={'path':'fixture-only-freeze','file_bytes_sha256':'a'*64}
result=ns['prepare_development_generation_pilot']();plan=result['plan']
rows=ns['read_bound'](plan['population'],jsonl=True);requests=ns['read_bound'](plan['request_drafts'],jsonl=True)
ok('actual32_development_packet_question_and_evidence_joins',len(rows)==len(requests)==32 and all(r['split']=='development' for r in rows))
ok('no_test_candidate_or_label_in_model_request',all(hybrid[r['candidate_id']]['split']=='development' and
     set(json.loads(r['request']['messages'][1]['content']))=={'question','evidence','response_schema'} for r in requests))
ok('unchanged_rank_contexts_reused_identically',plan['changed_context_count']==0 and all(r['context_provenance']=='REUSED_IDENTICAL_HASH_BOUND_NB18_CONTEXT' for r in rows))
ok('pilot_never_consumes_historical_judge_authorization',plan['paid_execution_authorized'] is False and plan['historical_semantic_judge_budget_reused'] is False and ns['S']['new_api_calls']==0)
# Exact NB18 caps/budget skip whole chunks; no backfill beyond Top10.
chunks={str(i):{'source_id':'shared' if i<9 else 'last','member_document_ids':[f'doc{i}'],'content':'text'} for i in range(11)}
packed=ns['pack_nb18_selected_order']([str(i) for i in range(11)],chunks,lambda cid:1)
ok('native_source_cap8_and_no_rank11_backfill',len(packed['items'])==9 and all(r['selected_rank']<=10 for r in packed['items']) and packed['dropped_reason_counts']=={'source_cap':1})
for c in chunks.values():c['member_document_ids']=['shared_document']
packed=ns['pack_nb18_selected_order']([str(i) for i in range(11)],chunks,lambda cid:1)
ok('native_document_cap5',len(packed['items'])==5 and packed['dropped_reason_counts']=={'document_cap':5})
for i,c in enumerate(chunks.values()):c['member_document_ids']=[str(i)]
packed=ns['pack_nb18_selected_order']([str(i) for i in range(11)],chunks,lambda cid:4,budget=7)
ok('whole_chunk_budget_no_text_truncation',len(packed['items'])==1 and packed['tokens']==4 and packed['dropped_reason_counts']['evidence_text_budget']==9)
report={'schema_version':'NB22B_CONTEXT_GENERATION_BRIDGE_VALIDATION_V1','status':'PASS','checks':checks,
        'real_provider_requests':0,'actual_context_data_used':True,
        'actual_development_failure_scores_used':False,'qualified_runtime_or_acceptance_established':False}
pathlib.Path('deliverables/NB22B_context_bridge_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
