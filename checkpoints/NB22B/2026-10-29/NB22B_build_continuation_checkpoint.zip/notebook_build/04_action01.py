# NB22B-C004 — Action 1: scope, lineage and acceptance boundaries.
def action01():
    previous = source('NB22_C054')
    inventory = source('NB22_C058')
    git = {}
    for label, args in {'head': ['rev-parse', 'HEAD'], 'branch': ['branch', '--show-current'],
                        'changed_paths': ['diff', '--name-only'],
                        'staged_paths': ['diff', '--cached', '--name-only']}.items():
        try:
            proc = subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True,
                                  text=True, timeout=10, check=False)
            git[label] = proc.stdout.strip().splitlines() if proc.returncode == 0 else None
        except (OSError, subprocess.TimeoutExpired):
            git[label] = None
    need(previous.get('release_acceptance_granted') is False, 'PREVIOUS_RELEASE_DECISION_REQUIRES_REVIEW')
    S['memory']['prior_inventory'] = inventory
    S['memory']['git'] = git
    return {'status': 'SCOPE_AND_PRIOR_DECISION_BOUND', 'git': git,
            'prior_quality_acceptance': 'NOT_ACCEPTED', 'selection_population': 'DEVELOPMENT_ONLY',
            'independent_final_population': 'NOT_INFERRED_FROM_HISTORICAL_TEST',
            'work_packages': ['inputs_and_diagnosis', 'bounded_retrieval_experiment',
                              'semantic_evidence_qualification', 'runtime_and_final_evaluation', 'release_decision'],
            'subtasks': [subtask('1.1', 'COMPLETE_IN_SCOPE', 'Read-only Git state recorded; no tracked file overwritten.'),
                         subtask('1.2', 'COMPLETE', 'Historical candidate and new experimental candidate are separate.'),
                         subtask('1.3', 'COMPLETE', 'C054/C058 consumed; prior failures and health deferral preserved.',
                                 [PINNED_INPUTS['NB22_C054'], PINNED_INPUTS['NB22_C058']]),
                         subtask('1.4', 'COMPLETE', 'Five work packages and unchanged acceptance authority recorded.')]}
A01 = run_action(1, action01)
