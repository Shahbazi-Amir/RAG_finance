# NB22B-C006 — Action 3: exact Development pool/rank diagnostics.
def action03():
    need('data_receipts' in S['memory'], 'ACTION02_INPUT_BINDINGS_REQUIRED')
    bindings = S['memory']['data_receipts']
    chunks = unique(read_bound(bindings['chunks'], jsonl=True), 'chunk_id')
    golden = unique(read_bound(bindings['golden'], jsonl=True), 'candidate_id')
    hybrid_all = unique(read_bound(bindings['hybrid'], jsonl=True), 'candidate_id')
    reranker_all = unique(read_bound(bindings['reranker'], jsonl=True), 'candidate_id')
    need(len(chunks) == 3488 and len(golden) == 3813, 'BOUND_DATA_POPULATION_CHANGED')
    need(set(hybrid_all) == set(reranker_all) == set(golden), 'QUERY_POPULATION_PARITY_FAILED')
    locator_chunks = collections.defaultdict(set)
    locator_types = collections.defaultdict(set)
    for chunk in chunks.values():
        for member in chunk['member_locators']:
            key = canonical(member['locator'])
            locator_chunks[key].add(chunk['chunk_id']); locator_types[key].add(chunk['source_type'])
    gold = {}
    for qid, q in golden.items():
        relevant = set()
        for loc in q['evidence_locators']:
            key = canonical(loc['source_locator'])
            need(bool(locator_chunks[key]), 'GOLD_LOCATOR_UNMAPPED:' + qid)
            need(bool(locator_types[key] & set(q['source_types'])), 'GOLD_SOURCE_TYPE_CONFLICT:' + qid)
            relevant.update(locator_chunks[key])
        need(bool(relevant), 'EMPTY_GOLD_SET:' + qid)
        gold[qid] = relevant
    mapping = hashlib.sha256()
    for qid in sorted(gold):
        encoded = canonical({'candidate_id': qid, 'relevant_chunk_ids': sorted(gold[qid])})
        mapping.update(len(encoded).to_bytes(8, 'big')); mapping.update(encoded)
    need(mapping.hexdigest() == source('NB22_C056')['gold_mapping']['recomputed_sha256'], 'GOLD_LOGICAL_IDENTITY_CONFLICT')
    dev = sorted(q for q in golden if hybrid_all[q]['split'] == 'development')
    need(len(dev) == 2664, 'DEVELOPMENT_COUNT_CONFLICT')
    hybrid = {}; reranker = {}; diagnostic = []; base = {}
    for qid in dev:
        h = hybrid_all[qid]; r = reranker_all[qid]
        need(r['split'] == h['split'] == 'development', 'SPLIT_LEAKAGE')
        ho = rank_ids(h, 100); ro = rank_ids(r, 50)
        need(set(ro) == set(ho[:50]), 'UPSTREAM_SAME50_POOL_CONFLICT')
        need(set(ho).issubset(chunks), 'UNKNOWN_CHUNK_REFERENCE')
        scores = [float(x['reranker_score']) for x in r['candidates']]
        need(all(math.isfinite(x) for x in scores), 'NONFINITE_RERANKER_SCORE')
        need(all(a >= b for a, b in zip(scores, scores[1:])), 'RERANKER_SCORE_ORDER_CONFLICT')
        m = metric(ro, gold[qid]); base[qid] = m
        in50 = len(set(ro) & gold[qid]); in100 = len(set(ho) & gold[qid])
        label = ('NO_GOLD_IN_HYBRID100' if not in100 else
                 'GOLD_ONLY_AFTER_HYBRID50' if not in50 else
                 'ALL_GOLD_IN_RERANKER10' if m['recall_at_10'] == 1 else 'RANKING_OR_PARTIAL_COVERAGE')
        diagnostic.append({'candidate_id': qid, 'split': 'development', 'category': label,
                           'gold_count': len(gold[qid]), 'pool50_gold': in50, 'pool100_gold': in100,
                           'pool50_recall_ceiling': min(10, in50) / len(gold[qid]),
                           'pool100_recall_ceiling': min(10, in100) / len(gold[qid]),
                           'baseline': m, 'source_types': sorted(golden[qid]['source_types'])})
        hybrid[qid] = h; reranker[qid] = r
    baseline = means(list(base.values()))
    expected = source('NB22_C056')['computed_metrics']['development']
    need(all(abs(baseline[k] - expected[k]) <= 1e-12 for k in baseline), 'DEVELOPMENT_BASELINE_REPLAY_CONFLICT')
    # Test labels/orders are not retained in the experiment state.
    S['memory']['dev'] = {'ids': dev, 'gold': {q: gold[q] for q in dev},
        'questions': {q: golden[q]['evaluation_content']['question'].strip() for q in dev},
        'golden': {q: golden[q] for q in dev}, 'chunks': chunks, 'hybrid': hybrid,
        'reranker': reranker, 'baseline': base}
    del hybrid_all, reranker_all, golden, gold
    receipt = save_rows('A03.development_diagnostics', diagnostic)
    return {'status': 'DEVELOPMENT_DIAGNOSTICS_COMPLETE', 'query_count': len(dev), 'excluded': 0,
            'category_counts': dict(collections.Counter(x['category'] for x in diagnostic)),
            'baseline': baseline, 'diagnostics': receipt,
            'mean_pool50_ceiling': statistics.fmean(x['pool50_recall_ceiling'] for x in diagnostic),
            'mean_pool100_ceiling': statistics.fmean(x['pool100_recall_ceiling'] for x in diagnostic),
            'causes_not_inferred': ['absence_from_corpus', 'semantic_gold_error', 'index_failure'],
            'subtasks': [subtask('3.1', 'COMPLETE_IN_SCOPE', 'Read exact saved Hybrid100/Reranker50 and bound chunk/gold; unaffected components not rerun.'),
                         subtask('3.2', 'COMPLETE_IN_SCOPE', 'Pool truncation and rank effects measured; unmeasured causal labels not guessed.'),
                         subtask('3.3', 'COMPLETE', 'Development locator mapping, pool ceilings and population verified.', [receipt]),
                         subtask('3.4', 'COMPLETE', 'Full Development cohort fixed; cached fusion and pool-depth hypothesis selected without using Test outcomes.')]}
A03 = run_action(3, action03)
