import pathlib,json,contextlib,io,os,types,sys,hashlib,copy,tempfile,threading,time
root=pathlib.Path('repository_snapshot').resolve();os.environ['RAG_FINANCE_ROOT']=str(root);ns={}
exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns)
ns['PINNED_INPUTS']=json.loads(pathlib.Path('notebook_build/pins.json').read_text());ns['CHECKLIST']=json.loads(pathlib.Path('notebook_build/actions.json').read_text())
with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
exec(pathlib.Path('notebook_build/03_helpers.py').read_text(),ns);exec(pathlib.Path('notebook_build/review_engine.py').read_text(),ns)
packets=ns['unique'](ns['output_of']('NB21C_C068','complete_remaining_measurement_packets',True),'candidate_id')
subset={k:packets[k] for k in sorted(packets)[:2]};jobs,plan=ns['prepare_gap_jobs'](subset)
checks=[]
def ok(label,condition):
 assert condition,label;checks.append({'check':label,'status':'PASS'})
calls=[];guard=threading.Lock()
class Adapter:
 def __init__(self,max_retries):assert max_retries==0
class FakeSession:
 def __enter__(self):return self
 def __exit__(self,*args):return False
 def mount(self,*args):return None
 def post(self,url,data,headers,timeout,allow_redirects):
  assert url=='https://nb22b-transport.invalid/chat/completions' and allow_redirects is False and timeout==(30,300)
  assert headers['Authorization']=='apikey FAKE_NON_SECRET_TEST_VALUE'
  request=json.loads(data);payload=json.loads(request['messages'][1]['content'].rsplit('\nFinal instruction:',1)[0]);d=payload['input']
  with guard:calls.append(d['candidate_id'])
  ev={r['evidence_id']:r['text'] for r in d['evidence']}
  result={'candidate_id':d['candidate_id'],'response_document_sha256':d['response_document_sha256'],
   'requirement_coverage':[{'requirement_index':r['requirement_index'],'assessment':'COVERED','answer_quotes':[d['answer_text']],
                          'reason_fa':'Synthetic mechanical fixture.'} for r in d['reference_requirements']],
   'citation_links':[{'claim_index':r['claim_index'],'evidence_id':r['evidence_id'],'support':'SUPPORTED','intended_location':'CORRECT',
                     'evidence_quotes':[ev[r['evidence_id']][:20]],'reason_fa':'Synthetic quote match, no model executed.'} for r in d['required_citation_links']],
   'additional_factual_units':[],'attribution_assertions':[],
   'factual_extraction_review':'COMPLETE_IN_MODEL_REVIEW_SCOPE','reference_requirement_qualification':'MODEL_PROPOSAL_ONLY',
   'reason_fa':'Synthetic provider response; not a semantic ground truth.'}
  time.sleep(.02)
  body={'model':'DeepSeek-V4-Flash','choices':[{'finish_reason':'stop','message':{'content':json.dumps(result,ensure_ascii=False)}}],
        'usage':{'prompt_tokens':100,'completion_tokens':200,'total_tokens':300,
                 'prompt_tokens_details':{'cached_tokens':35},'completion_tokens_details':{'reasoning_tokens':50}}}
  return types.SimpleNamespace(status_code=200,content=json.dumps(body,ensure_ascii=False).encode(),headers={'x-request-id':'FAKE-'+d['candidate_id']})
requests=types.ModuleType('requests');requests.Session=FakeSession
adapters=types.ModuleType('requests.adapters');adapters.HTTPAdapter=Adapter
fake_dotenv=types.ModuleType('dotenv');fake_dotenv.dotenv_values=lambda *a,**k:{'ARVAN_GATEWAY_URL':'https://nb22b-transport.invalid','ARVAN_GATEWAY_API_KEY':'FAKE_NON_SECRET_TEST_VALUE'}
old={k:sys.modules.get(k) for k in ['requests','requests.adapters','dotenv']}
sys.modules.update({'requests':requests,'requests.adapters':adapters,'dotenv':fake_dotenv})
original_read=ns['read_bound'];endpoint_sha=hashlib.sha256(b'https://nb22b-transport.invalid/chat/completions').hexdigest()
def fake_read(binding,jsonl=False):
 if binding['path'].endswith('a32b6a02fb15e29702df2916cf596e0cf26ee1c11012c0099bc70ddfabf78fc7/execution_plan.json'):
  return {'endpoint_sha256':endpoint_sha}
 return original_read(binding,jsonl)
ns['read_bound']=fake_read
try:
 with tempfile.TemporaryDirectory(prefix='nb22b-synthetic-transport-') as temp:
  ns['ROOT']=pathlib.Path(temp);ns['S']['saved_code_identity_valid']=True
  ns['CONFIG']['semantic_review'].update({'enabled':True,'workers':2,'authorized_cap_toman':1650000})
  ns['S']['new_api_calls']=0
  states,decision=ns['run_gap_jobs'](jobs,plan)
  ok('synthetic_transport_2_complete_jobs',len(calls)==2 and all(r['status']=='LOCALLY_VALID_MODEL_GAP_REVIEW' for r in states.values()))
  states2,decision2=ns['run_gap_jobs'](jobs,plan)
  ok('resume_successful_jobs_without_resend',len(calls)==2 and decision2['cached_valid_reviews']==2)
  telemetry=ns['gap_attempt_telemetry'](jobs)
  ok('unique_attempt_telemetry',telemetry['unique_attempt_count']==2 and telemetry['usage_complete_attempts']==2)
  ok('reasoning_and_cached_tokens_not_double_counted',telemetry['prompt_tokens_known_sum']==200 and telemetry['completion_tokens_known_sum']==400)
  changed=[]
  for j in jobs:
   n=copy.deepcopy(j);n['request']['messages'][0]['content']+='\nFormatting-only fixture variation.'
   n['request_sha256']=ns['sha'](ns['canonical'](n['request']));n['identity']['request_sha256']=n['request_sha256'];n['key']=ns['sha'](ns['canonical'](n['identity']));changed.append(n)
  oldstates,olddecision=ns['run_gap_jobs'](changed,plan)
  ok('formatting_prompt_change_reuses_logical_task',len(calls)==2 and all(r.get('reused_previous_prompt_result') for r in oldstates.values()))
  base=ns['project_path']('artifacts/phase2/quality_improvement/NB22B.semantic_gap_review_v1/jobs')
  (base/jobs[0]['key']/'response.body').unlink()
  held,held_decision=ns['run_gap_jobs'](changed,plan)
  ok('unknown_old_logical_task_not_resent_under_new_prompt',len(calls)==2 and any(r['status']=='PREVIOUS_LOGICAL_TASK_REQUIRES_RECONCILIATION_NO_RESEND' for r in held.values()))
  partial=ns['gap_attempt_telemetry'](jobs)
  ok('unknown_outcome_retains_cost_reserve',partial['outcome_unknown_count']==1 and partial['unknown_usage_or_tariff_planning_reserve_toman']>0)
  # An approval for this task cannot be reused for another task even below the approved amount.
  changed_plan={**plan,'task_version':'UNAUTHORIZED_DIFFERENT_TASK'}
  third=copy.deepcopy(jobs[1]);third['key']='f'*64;third['logical_key']='e'*64
  try:ns['run_gap_jobs']([third],changed_plan);raised=False
  except ns['EvidenceGap'] as e:raised=str(e)=='DISPATCH_SCOPE_EXCEEDS_RECORDED_USER_APPROVAL'
  ok('approval_does_not_authorize_a_different_task',raised and len(calls)==2)
finally:
 for k,v in old.items():
  if v is None:sys.modules.pop(k,None)
  else:sys.modules[k]=v
report={'schema_version':'NB22B_SYNTHETIC_TRANSPORT_RESUME_VALIDATION_V1','status':'PASS','checks':checks,
        'real_provider_requests':0,'synthetic_post_calls':len(calls),'real_model_semantic_quality_assessed':False,
        'scope':'Synthetic transport replacement; actual request/attempt/raw/receipt/lock/cache/telemetry code exercised with no network provider.'}
pathlib.Path('deliverables/NB22B_runner_transport_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,indent=2))
