# Stable inference cache: independent of unrelated notebook/report code and rank-fusion grid edits.
def local_inference_contract():
    need(CONFIG['batch_size']==4 and CONFIG['maximum_sequence_length']==512,'UNSUPPORTED_LOCAL_INFERENCE_PREPROCESSING')
    need('reranker' in S['memory'].get('data_receipts',{}),'BOUND_BASELINE_SCORE_PRODUCER_REQUIRED_FOR_LOCAL_CACHE')
    baseline_hash=descriptor(S['memory']['data_receipts']['reranker'])[1]
    spec={'schema_version':'NB22B_LOCAL_PAIR_INFERENCE_CONTRACT_V2',
          'model_id':CONFIG['model_id'],'revision':CONFIG['model_revision'],'model_sha256':CONFIG['onnx_sha256'],
          'onnxruntime_version':CONFIG['onnxruntime_version'],'batch_size':4,'maximum_sequence_length':512,
          'execution_provider':'CPUExecutionProvider','threads':{'intra_op':4,'inter_op':1},
          'implementation_ast_sha256':LOCAL_INFERENCE_IMPLEMENTATION_SHA256,
          'baseline_reranker_file_bytes_sha256':baseline_hash}
    return {'specification':spec,'sha256':sha(canonical(spec))}


def depth100_case_identity(dev,qid,contract):
    order=rank_ids(dev['hybrid'][qid],100)
    previous={r['chunk_id'] for r in dev['reranker'][qid]['candidates']}
    missing=[cid for cid in order if cid not in previous]
    cache=S['memory'].setdefault('chunk_content_sha256',{})
    versions=[]
    for cid in missing:
        text=dev['chunks'][cid]['content']
        # Bind cached inference to text itself, rather than an unrelated changed artifact filename.
        if cid not in cache:cache[cid]=(text,sha(text.encode()))
        need(cache[cid][0]==text,'CHUNK_TEXT_CHANGED_WITHIN_ONE_RUN')
        versions.append({'chunk_id':cid,'content_sha256':cache[cid][1]})
    return {'inference_contract_sha256':contract['sha256'],'candidate_id':qid,
            'question_sha256':sha(dev['questions'][qid].encode()),'ordered_missing_chunks':versions}


def validate_local_score_record(record,identity,contract):
    need(isinstance(record,dict) and record.get('identity')==identity,'LOCAL_SCORE_CACHE_INPUT_VERSION_CONFLICT')
    scores=record.get('scores')
    need(isinstance(scores,list) and len(scores)==len(identity['ordered_missing_chunks']) and
         all(type(x) in (int,float) and math.isfinite(x) for x in scores),'LOCAL_SCORE_CACHE_VALUES_INVALID')
    need(record.get('score_values_sha256')==sha(canonical(scores)),'LOCAL_SCORE_CACHE_CHECKSUM_CONFLICT')
    guard=read_bound(record.get('runtime_validation_receipt'))
    need(guard.get('schema_version')=='NB22B_LOCAL_RUNTIME_PARITY_V2' and
         guard.get('inference_contract_sha256')==contract['sha256'] and
         guard.get('model_sha256')==contract['specification']['model_sha256'],'LOCAL_CACHE_RUNTIME_PROVENANCE_CONFLICT')
    delta=guard.get('sample_score_max_delta')
    need(type(delta) in (int,float) and math.isfinite(delta) and 0<=delta<=1e-4,'LOCAL_CACHE_SAMPLE_PARITY_NOT_ESTABLISHED')
    return record


def depth100_cache_inputs(dev,contract):
    folder=project_path('artifacts/phase2/quality_improvement/NB22B.depth100/'+contract['sha256'])
    bindings={};cached={}
    for q in dev['ids']:
        identity=depth100_case_identity(dev,q,contract);path=folder/(sha(canonical(identity))+'.json')
        bindings[q]={'identity':identity,'path':path}
        if path.is_file():
            raw,stat_key=local_cache_stable_read(path)
            bindings[q].update(file_bytes_sha256=sha(raw),stat=stat_key)
            try:record=_boot_decode(raw)
            except (ValueError,UnicodeError) as error:raise EvidenceGap('LOCAL_SCORE_CACHE_JSON_INVALID') from error
            cached[q]=validate_local_score_record(record,identity,contract)
    return folder,bindings,cached


def complete_depth100_cached_result(dev,bindings,cached,start):
    orders={};receipts=[];deltas=[]
    for q in dev['ids']:
        record=cached[q];missing=[r['chunk_id'] for r in record['identity']['ordered_missing_chunks']]
        previous={r['chunk_id']:float(r['reranker_score']) for r in dev['reranker'][q]['candidates']}
        combined={**previous,**dict(zip(missing,record['scores']))}
        need(set(combined)==set(rank_ids(dev['hybrid'][q],100)),'DEPTH100_CACHED_POOL_CONFLICT')
        orders[q]=sorted(combined,key=lambda cid:(-combined[cid],cid))
        receipts.append(local_cache_receipt(bindings[q]))
        deltas.append(read_bound(record['runtime_validation_receipt'])['sample_score_max_delta'])
    guards={r['runtime_validation_receipt']['path']:r['runtime_validation_receipt'] for r in cached.values()}
    return {'orders':orders,'held':[],'runtime_validation_receipts':list(guards.values()),'new_pairs':0,'cache_queries_reused':len(orders),
            'score_cache_receipts':receipts,'sample_score_max_delta':max(deltas),
            'complete':True,'elapsed_seconds':time.monotonic()-start,
            'model_loaded_this_call':False,'cache_reuse_before_runtime_initialization':True}


def register_local_score_assets(local,plan_receipt,stem):
    references=local['score_cache_receipts']+local.get('runtime_validation_receipts',[])
    current={r['path']:r['file_bytes_sha256'] for r in S['artifacts']}
    for ref in references:
        need(ref['path'] not in current or current[ref['path']]==ref['file_bytes_sha256'],'LOCAL_CACHE_RECEIPT_CONFLICT')
        if ref['path'] not in current:S['artifacts'].append(ref);current[ref['path']]=ref['file_bytes_sha256']
    return save_json(stem,{'inference_contract':local_inference_contract(),'current_experiment_plan':plan_receipt,
                          'files':references,'complete_population':local['complete'],
                          'cache_reused_before_model_load':local.get('cache_reuse_before_runtime_initialization',False)})


def local_cache_stable_read(path):
    before=path.stat();raw=path.read_bytes();after=path.stat()
    key=lambda s:[s.st_size,s.st_mtime_ns,s.st_ino]
    need(key(before)==key(after),'LOCAL_SCORE_CACHE_CHANGED_DURING_READ')
    return raw,key(after)


def local_cache_receipt(binding):
    path=binding['path'];st=path.stat()
    need(binding['stat']==[st.st_size,st.st_mtime_ns,st.st_ino],'LOCAL_SCORE_CACHE_CHANGED_AFTER_VALIDATION')
    return {'path':path.relative_to(ROOT).as_posix(),'file_bytes_sha256':binding['file_bytes_sha256']}
