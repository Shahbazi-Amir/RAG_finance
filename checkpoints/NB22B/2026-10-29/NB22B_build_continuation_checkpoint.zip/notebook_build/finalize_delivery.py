"""Embed verified software reports without inventing executed production outputs."""
import json,pathlib,hashlib,ast,sys
root=pathlib.Path('.');path=root/'deliverables/22b_quality_improvement_and_acceptance.ipynb'
nb=json.loads(path.read_bytes());finger=nb['metadata']['nb22b']['code_source_sha256']
reports={p.name:json.loads(p.read_bytes()) for p in (root/'deliverables').glob('NB22B_*validation.json')}
for name in ['NB22B_build_validation.json','NB22B_clean_kernel_validation.json']:
 assert reports[name]['tested_production_code_fingerprint']==finger,('STALE_VALIDATION',name)
assert all(d.get('status') in {'PASS','CHECKS_PASSED'} for d in reports.values())
checks=sum(len(d.get('checks',[])) for d in reports.values())
nb['metadata']['nb22b']['software_validation']={
 'checks_passed':checks,'fresh_process_code_cells':17,'jupyter_kernel_execution_verified':False,
 'real_mac_execution_verified':False,'real_provider_requests_during_validation':0,
 'reports':reports,'qualification':'Software fixtures do not establish real product quality or acceptance.'}
text=f'''<div dir="rtl" align="right">

## اعتبارسنجی فایل تحویلی

{checks} کنترل ساخت، داده، Resume، مسیر مولد، Context و Regression گذشت. هر۱۷سل در فرایند تازهٔ مستقل با ورودی آزمایشیِ هم‌Schema و اندازهٔ کامل به ترتیب اجرا شدند. بستهٔ واقعی C068 و Contextهای واقعی نیز جدا بررسی شدند؛ ترتیب cohort در آزمون Context مصنوعی بود و نتیجهٔ بهبود واقعی نام نمی‌گیرد. جزئیات در metadata همین فایل هستند.

**حدود تأیید:** اجرای واقعی مک و مدل Provider در محیط ساخت انجام نشد. کرنل Jupyter به علت محدودیت سوکت محیط شروع نشد؛ اجرای مستقل Python جای آن و با نام درست گزارش شد. هیچ APIواقعی برای اعتبارسنجی مصرف نشد. این تست‌ها، کیفیت محصول یا قبولی Release نیستند.

طرح تولید۳۲موردی Development تنها آماده‌سازی و برآورد است؛ مجوز۱٬۶۵۰٬۰۰۰تومانی داوری تاریخی به مولد منتقل نمی‌شود. نبود ورودی نسخه‌متصل، مرجع صلاحیت‌دار یا baseline با صفر و PASS پر نمی‌شود. وجود۱۴اقدام و۶۴ردیف به معنی تکمیل موفق همهٔ کارها نیست. تصمیم نهایی از خروجی واقعی همین اجرا خوانده شود.

</div>
'''
nb['cells']=[c for c in nb['cells'] if not(c['cell_type']=='markdown' and '## اعتبارسنجی فایل تحویلی' in ''.join(c['source']))]
nb['cells'].append({'cell_type':'markdown','id':hashlib.sha256(text.encode()).hexdigest()[:12],'metadata':{},'source':text.splitlines(keepends=True)})
can=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
sources=[''.join(c['source']) for c in nb['cells'] if c['cell_type']=='code']
assert hashlib.sha256(can(sources)).hexdigest()==finger
assert all(ast.parse(s,feature_version=(3,11)) for s in sources)
assert all('dir="rtl"' in ''.join(c['source']) for c in nb['cells'] if c['cell_type']=='markdown')
sys.path.insert(0,str((root/'notebook_build/validation_deps').resolve()))
import nbformat
nbformat.validate(nb);path.write_text(json.dumps(nb,ensure_ascii=False,indent=1)+'\n')
print(json.dumps({'path':str(path),'code_fingerprint':finger,'checks':checks,'cells':len(nb['cells']),'bytes':path.stat().st_size}))
