# NB22B-C007 — Action 4: freeze bounded experiment before candidate scores.
def action04():
    need('dev' in S['memory'], 'ACTION03_EXACT_DEVELOPMENT_INPUTS_REQUIRED')
    dev = S['memory']['dev']
    plan = {'schema_version': 'NB22B_BOUNDED_RETRIEVAL_PLAN_V1',
            'producer_code_source_sha256': SOURCE_CODE_SHA256,
            'scope': 'DEVELOPMENT_ONLY', 'cohort_sha256': sha(canonical(dev['ids'])),
            'cohort_count': len(dev['ids']), 'source_inputs': S['memory']['data_receipts'],
            'hypothesis': 'Combine cached Hybrid and reranker ranks; test whether truncation to50 loses evidence recoverable in the frozen Hybrid100 pool.',
            'producer_component': 'NB17_VERSIONED_DERIVATIVE', 'baseline': 'FROZEN_RERANKER50',
            'rrf': {'formula': 'w/(k+reranker_rank)+(1-w)/(k+hybrid_rank)',
                    'weights': CONFIG['rrf_weights'], 'constants': CONFIG['rrf_constants'],
                    'tie_break': 'CHUNK_ID_ASCENDING', 'pool': 'SAME50'},
            'local_inference_contract_sha256':local_inference_contract()['sha256'],
            'depth100': {'enabled': CONFIG['execute_local_depth100'], 'batch_size': 4,
                         'maximum_sequence_length': 512, 'reuse_first50_scores': True,
                         'only_missing_pairs_inferred': True, 'downloads': False,
                         'onnx_sha256': CONFIG['onnx_sha256'], 'revision': CONFIG['model_revision']},
            'selection_rule': 'Highest Development nDCG@10 among variants with macro Recall@10 and Hit@10 no lower than baseline; deterministic variant-id tie-break; require positive nDCG delta, otherwise retain baseline.',
            'absolute_thresholds': {'recall_at_10': 0.85, 'ndcg_at_10': 0.75},
            'no_threshold_mutation': True, 'reciprocal_rank_comparison_scope': 'COMMON_STORED_TOP50', 'inference_pair_upper_bound': 50 * len(dev['ids']),
            'local_seconds_cap': CONFIG['maximum_local_seconds'], 'fresh_paid_requests': 0,
            'stopping': ['input_identity_conflict', 'runtime_or_model_conflict', 'local_time_cap', 'inference_contract_failure'],
            'negative_result_preserved': True, 'final_acceptance_evaluation': 'SEPARATE_QUALIFIED_HOLDOUT_REQUIRED'}
    receipt = save_json('A04.frozen_experiment_plan', plan)
    S['memory']['experiment_plan'] = plan; S['memory']['plan_receipt'] = receipt
    return {'status': 'BOUNDED_DEVELOPMENT_PLAN_FROZEN', 'plan': receipt,
            'maximum_new_local_pairs': plan['inference_pair_upper_bound'], 'fresh_model_api_requests': 0,
            'runtime_duration_guaranteed': False,
            'subtasks': [subtask('4.1', 'COMPLETE', 'Versioned NB17 derivative and fixed baseline defined.'),
                         subtask('4.2', 'COMPLETE', 'Cohort, candidate grid, no-regression rule and stop limits written before execution.', [receipt]),
                         subtask('4.3', 'COMPLETE', 'Cached ranking variants need zero inference; depth100 may need at most133200 local pairs, never API.'),
                         subtask('4.4', 'COMPLETE', 'Deterministic tie-break, depths, frozen thresholds and bootstrap seed recorded.')]}
A04 = run_action(4, action04)
