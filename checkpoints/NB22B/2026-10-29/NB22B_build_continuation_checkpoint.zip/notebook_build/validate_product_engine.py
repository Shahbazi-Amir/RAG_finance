"""Synthetic native contracts test capability and failure handling; no provider or real semantic accuracy."""
import pathlib,json,os,tempfile,contextlib,io,sys,copy,types,hashlib,time,ast
checks=[]
def ok(label,test):
    assert test,label;checks.append({'check':label,'status':'PASS'})
with tempfile.TemporaryDirectory(prefix='nb22b-product-engine-') as folder:
    root=pathlib.Path(folder);os.environ['RAG_FINANCE_ROOT']=str(root)
    (root/'notebooks/phase2').mkdir(parents=True)
    marker=root/'data/Road_Maps/RAG_finance_phase2_modular_notebooks_execution_plan.md';marker.parent.mkdir(parents=True);marker.write_text('fixture')
    ns={};exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns)
    ns['PINNED_INPUTS']={};ns['CHECKLIST']=[]
    with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
    for source in ['03_helpers.py','review_engine.py','product_engine.py']:exec(pathlib.Path('notebook_build',source).read_text(),ns)
    def write(name,value,jsonl=False):
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
        raw=b''.join(ns['canonical'](r)+b'\n' for r in value) if jsonl else ns['canonical'](value)
        path.write_bytes(raw);return {'path':name,'file_bytes_sha256':ns['sha'](raw)}
    fixtures=write('fixtures/protocol.json',{'scope':'SYNTHETIC_VALIDATION_ONLY_NOT_EXPERT_GOLD'})
    context=json.load(open('notebook_build/review_context.json'))['contract'];policies=context['metric_policy']
    policy=write('fixtures/policy.json',{'schema_version':'NB22B_COMPLETE_PRODUCT_POLICY_V1','version':'SYNTHETIC',
         'coverage':['answerability','safety','confidence','citation','attribution'],'rules':['synthetic fixture rule']})
    tariff=write('fixtures/tariff.json',{'synthetic':True})
    profile={'model':'fixture-generator','response_model_aliases':['fixture-generator'],
             'auth_scheme':'Bearer','max_tokens':100,'temperature':0,
             'prompt_template_sha256':ns['sha'](ns['NB19_PRODUCT_SYSTEM'].encode()),
             'endpoint_env':'NB22B_FIXTURE_ENDPOINT','key_env':'NB22B_FIXTURE_KEY',
             'endpoint_sha256':ns['sha'](b'https://fixture.invalid/chat/completions'),
             'tariff':{'currency':'TOMAN','unit_tokens':1000000,'input_rate':1,'output_rate':2,'source_binding':tariff}}
    profile_binding=write('fixtures/profile.json',profile)
    environment=write('fixtures/environment.json',{'schema_version':'NB22B_EXECUTION_ENVIRONMENT_LOCK_V1','python_major_minor':'.'.join(sys.version.split()[0].split('.')[:2]),'packages':{'pip':__import__('importlib.metadata').metadata.version('pip')}})
    ns['SOURCE_CODE_SHA256']='a'*64
    inventory=write('fixtures/source.json',{'schema_version':'NB22B_PRODUCER_SOURCE_INVENTORY_V1','nb22b_code_source_sha256':'a'*64,'assets':[fixtures]})
    population=[{'candidate_id':f'independent{i:03d}','question':f'سؤال مصنوعی شماره{i}','source_component_id':f'component{i}',
                 'evidence':[{'evidence_id':'e1','text':'شاهد مصنوعی برای تست نرم‌افزار'}]} for i in range(64)]
    pop=write('fixtures/population.jsonl',population,True)
    inventory=write('fixtures/source.json',{'schema_version':'NB22B_PRODUCER_SOURCE_INVENTORY_V1','nb22b_code_source_sha256':'a'*64,'assets':[fixtures,pop,profile_binding,policy,environment]})
    ns['S']['memory']['selection_receipt']={'path':'fixtures/freeze.json','file_bytes_sha256':'b'*64}
    restore=write('fixtures/restore.json',{'schema_version':'NB22B_VERSION_BOUND_RESTORE_EVIDENCE_V1','status':'PASS','selection_freeze_sha256':'b'*64,'asset_inventory_sha256':inventory['file_bytes_sha256']})
    contract={'schema_version':'NB22B_PRODUCT_EXECUTION_CONTRACT_V1','selection_freeze_sha256':'b'*64,'population':pop,
              'generation_profile':profile_binding,'product_policy':policy,'environment_lock':environment,
              'producer_source_inventory':inventory,'candidate_restore_evidence':restore}
    path='artifacts/phase2/quality_improvement/NB22B.product_execution_contract.json';write(path,contract)
    bound=ns['product_contract']();jobs=ns['product_jobs'](bound)
    ok('exact_existing_nb19_prompt_hash',profile['prompt_template_sha256']=='26de93774a2f8dbc97e07b0721e31845421b9db6e04afc427f8e918582b7a62f')
    native=json.loads(pathlib.Path('repository_snapshot/notebooks/phase2/19_generation_and_citation.ipynb').read_bytes())
    original_schema=None
    for cell in native['cells']:
        if cell['cell_type']!='code':continue
        text=cell['source'] if isinstance(cell['source'],str) else ''.join(cell['source'])
        for node in ast.parse(text).body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NB19_MODEL_RESPONSE_SCHEMA' for t in node.targets):
                original_schema=ast.literal_eval(node.value);break
        if original_schema is not None:break
    ok('product_response_schema_matches_actual_nb19_producer',original_schema==ns['PRODUCT_RESPONSE_SCHEMA'])

    ok('product_request_excludes_reference_labels_and_metadata',set(json.loads(jobs[0]['request']['messages'][1]['content']))=={'question','evidence','response_schema'})
    execution=ns['execute_product'](bound)
    ok('historical_judge_approval_does_not_dispatch_product',ns['S']['new_api_calls']==0 and execution['plan']['dispatch_gate_reason']=='PRODUCT_SCOPE_NOT_AUTHORIZED_FOR_NEW_DISPATCH')
    ok('technical_closure_consumes_bound_policy_lock_source_and_restore',ns['product_technical_closure'](bound)['status']=='VERSION_BOUND_PRODUCT_TECHNICAL_CLOSURE_PASS')
    incomplete=copy.deepcopy(bound)
    incomplete['bound']['producer_source_inventory']['assets']=[fixtures]
    try:ns['product_technical_closure'](incomplete);raised=False
    except ns['EvidenceGap'] as error:raised=str(error).startswith('PRODUCT_REQUIRED_ASSET_NOT_IN_SOURCE_INVENTORY:')
    ok('technical_inventory_cannot_omit_bound_runtime_inputs',raised)
    addendum={'schema_version':'NB22B_VERSIONED_GENERATION_POLICY_ADDENDUM_V1','version':'synthetic-policy-v2',
              'parent_prompt_sha256':profile['prompt_template_sha256'],'product_policy_sha256':policy['file_bytes_sha256'],
              'policy_addendum':'قاعدهٔ مصنوعی برای آزمون اتصال نسخه'}
    additive=copy.deepcopy(profile);additive['prompt_template']=write('fixtures/prompt_addendum.json',addendum)
    additive['prompt_template_sha256']=ns['sha']((ns['NB19_PRODUCT_SYSTEM']+'\n\nVersioned product policy:\n'+addendum['policy_addendum']).encode())
    resolved=ns['resolve_versioned_product_prompt'](contract,additive)
    ok('versioned_policy_addendum_bound_without_changing_response_schema',resolved['policy_addendum_bound'] and resolved['response_schema_changed'] is False and resolved['template_sha256']==additive['prompt_template_sha256'])
    for field,label in [('parent_prompt_sha256','wrong_parent'),('product_policy_sha256','wrong_policy')]:
        invalid={**addendum,field:'0'*64};bad_profile=copy.deepcopy(additive)
        bad_profile['prompt_template']=write('fixtures/'+label+'.json',invalid)
        try:ns['resolve_versioned_product_prompt'](contract,bad_profile);raised=False
        except ns['EvidenceGap']:raised=True
        ok('prompt_addendum_rejects_'+label,raised)
    response={'answer_text':'پاسخ مصنوعی','claims':[{'claim_text':'ادعای مصنوعی','claim_type':'FACTUAL','evidence_ids':['e1']}]}
    ok('product_response_schema_validates_references',ns['product_response'](response,population[0]['evidence'])==response)
    bad=copy.deepcopy(response);bad['claims'][0]['evidence_ids']=['invented']
    try:ns['product_response'](bad,population[0]['evidence']);raised=False
    except ns['EvidenceGap']:raised=True
    ok('product_invented_evidence_id_rejected',raised)
    # Persist raw provider-like fixtures and exercise actual cached decode/hash/schema path.
    directory=root/'artifacts/phase2/quality_improvement/NB22B.product_generation_v1/jobs'/jobs[0]['key'];directory.mkdir(parents=True)
    ns['immutable_file'](directory/'attempt.json',ns['canonical']({'request_sha256':jobs[0]['request_sha256'],'dispatch_epoch':time.time()}))
    ok('product_unknown_attempt_not_resent',ns['product_cached_response'](jobs[0],directory,profile)['status']=='UNKNOWN_NO_RESEND')
    body={'model':'fixture-generator','choices':[{'finish_reason':'stop','message':{'content':json.dumps(response,ensure_ascii=False)}}],
          'usage':{'prompt_tokens':12,'completion_tokens':7,'completion_tokens_details':{'reasoning_tokens':2}}}
    raw=ns['canonical'](body);ns['immutable_file'](directory/'response.body',raw)
    ns['immutable_file'](directory/'receipt.json',ns['canonical']({'request_sha256':jobs[0]['request_sha256'],'body_sha256':ns['sha'](raw),'http_status':200,'elapsed_seconds':1.25,'provider_request_id':'fixture-request-1'}))
    cached=ns['product_cached_response'](jobs[0],directory,profile)
    ok('product_raw_receipt_valid_response_join',cached['status']=='VALID_PRODUCT_RESPONSE')
    states={p['candidate_id']:{'candidate_id':p['candidate_id'],'status':'VALID_PRODUCT_RESPONSE','response':response,
              'response_document_sha256':ns['sha'](ns['canonical'](response))} for p in population}
    states[population[0]['candidate_id']]=cached
    telemetry=ns['product_telemetry'](bound,{'jobs':jobs,'states':states})
    ok('product_usage_not_double_counting_reasoning',telemetry['known_tokens']==19 and telemetry['token_observed_queries']==1)
    # Exercise the new generator transport with an in-process fake provider only.
    tiny={**bound,'cases':{q:bound['cases'][q] for q in sorted(bound['cases'])[:2]}}
    tiny_jobs=ns['product_jobs'](tiny);plan_hash=ns['sha'](ns['canonical']([j['identity'] for j in tiny_jobs]))
    ns['S']['saved_code_identity_valid']=True
    ns['CONFIG']['product_execution'].update(enabled=True,approved_plan_sha256=plan_hash,authorized_cap_toman=100,
          maximum_requests=2,workers=2,rpm=80)
    os.environ['NB22B_FIXTURE_ENDPOINT']='https://fixture.invalid/chat/completions'
    os.environ['NB22B_FIXTURE_KEY']='synthetic-only-not-a-secret'
    calls=[]
    class FakeResponse:
        status_code=200
        content=ns['canonical'](body)
        headers={'x-request-id':'synthetic-product-new'}
    class FakeSession:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def mount(self,*args):pass
        def post(self,url,**kwargs):
            assert kwargs['allow_redirects'] is False
            assert kwargs['headers']['Authorization']=='Bearer synthetic-only-not-a-secret'
            calls.append(url);return FakeResponse()
    requests=types.ModuleType('requests');requests.Session=FakeSession
    adapters=types.ModuleType('requests.adapters');adapters.HTTPAdapter=lambda **kwargs:None
    dotenv=types.ModuleType('dotenv');dotenv.dotenv_values=lambda *args,**kwargs:{}
    saved={k:sys.modules.get(k) for k in ('requests','requests.adapters','dotenv')}
    sys.modules.update({'requests':requests,'requests.adapters':adapters,'dotenv':dotenv})
    try:
        dispatched=ns['execute_product'](tiny)
        ok('separately_approved_product_transport_exercised_without_provider',len(calls)==1 and all(r['status']=='VALID_PRODUCT_RESPONSE' for r in dispatched['states'].values()))
        again=ns['execute_product'](tiny)
        ok('product_successful_attempts_resume_without_resend',len(calls)==1 and all(r['status']=='VALID_PRODUCT_RESPONSE' for r in again['states'].values()))
        shifted=copy.deepcopy(tiny)
        shifted['contract']['generation_profile']={'path':'fixtures/repriced-profile.json','file_bytes_sha256':'c'*64}
        shifted['profile']['tariff']['input_rate']=2
        reuse=ns['execute_product'](shifted)
        ok('non_model_profile_change_reuses_identical_product_request',len(calls)==1 and all(r['status']=='VALID_PRODUCT_RESPONSE' for r in reuse['states'].values()))
    finally:
        for k,v in saved.items():
            if v is None:sys.modules.pop(k,None)
            else:sys.modules[k]=v
    # This fixture uses one cached and one newly simulated response; no remote connection exists.
    ns['CONFIG']['product_execution']['enabled']=False
    alias_job=copy.deepcopy(jobs[0]);alias_job['candidate_id']='identical-input-alias';alias_job['key']='f'*64
    alias_state={**cached,'candidate_id':'identical-input-alias','job_key':'f'*64,'reused_source_job_key':jobs[0]['key']}
    shared_telemetry=ns['product_telemetry'](bound,{'jobs':[jobs[0],alias_job],
        'states':{jobs[0]['candidate_id']:cached,'identical-input-alias':alias_state}})
    ok('shared_source_attempt_tokens_and_latency_not_counted_twice',shared_telemetry['known_tokens']==19 and shared_telemetry['latency_observation_count']==1 and shared_telemetry['shared_source_attempt_query_alias_count']==1)
    opts=ns['CONFIG']['product_execution'];opts['enabled']=True
    ns['CONFIG']['paid_model_dispatch']=False
    fresh_bound=copy.deepcopy(tiny);case=copy.deepcopy(next(iter(tiny['cases'].values())))
    case['candidate_id']='fresh-global-off';case['question']='A new synthetic request blocked by the global switch'
    fresh_bound['cases']={'fresh-global-off':case}
    before_calls=ns['S']['new_api_calls'];disabled=ns['execute_product'](fresh_bound)
    ok('global_paid_dispatch_switch_blocks_product_before_profile_or_budget',ns['S']['new_api_calls']==before_calls and disabled['plan']['dispatch_gate_reason']=='PRODUCT_SCOPE_NOT_AUTHORIZED_FOR_NEW_DISPATCH')
    ns['CONFIG']['paid_model_dispatch']=True;opts['enabled']=False
    qualification=write('fixtures/reference.json',{'schema_version':'NB22B_REFERENCE_QUALIFICATION_V1','population_sha256':pop['file_bytes_sha256'],
                    'selection_used_this_population':False,'population_exposed_for_tuning':False,'review_protocol':fixtures,'reviewer_records':fixtures})
    measurements=[]
    for i,p in enumerate(population):
        metrics={}
        for name,policy_spec in policies.items():
            m={'state':'DETERMINED','analysis_unit':policy_spec['definition']['analysis_unit'],
               'definition_sha256':ns['sha'](ns['canonical'](policy_spec['definition'])),'source_bindings':[fixtures]}
            if name in {'hit_at_k','recall_at_k','ndcg_at_k_binary'}:m['values']={'5':1.,'10':1.}
            elif name=='reciprocal_rank':m['values']={'10':1.,'100':1.,'full':1.}
            elif name=='no_answer_precision_recall_f1':m['confusion']={'TP':int(i%4==0),'FP':0,'FN':0,'TN':int(i%4!=0)}
            elif name=='latency':m.update(elapsed_seconds=1.+i/100,thermal_state='UNCLASSIFIED',hardware_identity='fixture-only')
            elif name=='failure_rate':m.update(query_failed=0,attempt_failures=0,attempt_count=1)
            elif name=='token_usage':m.update(prompt_tokens=12,completion_tokens=7)
            elif name=='cost':m.update(cost_toman=.1,basis='USAGE_WITH_BOUND_TARIFF')
            else:m.update(numerator=0 if name=='safety_violation_rate' else 1,denominator=1)
            metrics[name]=m
        measurements.append({'candidate_id':p['candidate_id'],'response_document_sha256':states[p['candidate_id']]['response_document_sha256'],
            'reference_qualification_sha256':qualification['file_bytes_sha256'],'metrics':metrics,'factual_extraction_complete':True,
            'critical_assessment':{'state':'COMPLETE','unsupported_critical_claims':0,'critical_safety_violations':0,
                'factual_claim_count':1,'unsupported_factual_claim_count':0,'unknown_factual_claim_count':0,'source_bindings':[fixtures]}})
    rows=write('fixtures/measurements.jsonl',measurements,True)
    baseline=write('fixtures/baseline.json',{'schema_version':'NB22B_QUALIFIED_PRODUCT_BASELINE_V1',
             'reference_qualification_sha256':qualification['file_bytes_sha256'],'population_sha256':pop['file_bytes_sha256'],
             'measurement_boundary':'SYNTHETIC_RUNNER_TEST_ONLY','case_measurements':rows,
             'producer_version':'SYNTHETIC_PRECHANGE','prechange_provenance':fixtures})
    evaluation=write('fixtures/evaluation.json',{'schema_version':'NB22B_QUALIFIED_PRODUCT_EVALUATION_V1','selection_freeze_sha256':'b'*64,
              'candidate_ids':sorted(states),'reference_qualification':qualification,'case_measurements':rows,
              'compatible_baseline':baseline,'measurement_boundary':'SYNTHETIC_RUNNER_TEST_ONLY'})
    bound['contract']['evaluation']=evaluation
    ns['source']=lambda role:context if role=='NB21C_C025' else None
    ns['CONFIG']['bootstrap_repetitions']=200 # Reduced only in this labelled software fixture, never production build.
    result=ns['independent_product_evaluation'](bound,states)
    ok('all16_metric_families_compute_in_full_synthetic_contract',result['all16_metrics_pass'] and len(result['metric_results'])==16)
    ok('precision_recall_f1_pooled_components',result['metric_results']['no_answer_precision_recall_f1']['components']['f1']['value']==1)
    ok('latency_separate_p50_p95',set(result['metric_results']['latency']['components'])=={'p50','p95'})
    ok('mrr10_100_full_all_required',set(result['metric_results']['reciprocal_rank']['components'])=={'10','100','full'})
    # A separate untouched evaluation subset may coexist with a larger generation population.
    subset_ids=sorted(states)[:48]
    subset_pop=write('fixtures/subset_population.jsonl',[{'candidate_id':q,
       'question_sha256':ns['sha'](bound['cases'][q]['question'].strip().encode()),
       'evidence_sha256':ns['sha'](ns['canonical'](bound['cases'][q]['evidence']))} for q in subset_ids],True)
    qdoc=json.loads((root/qualification['path']).read_bytes());qdoc['population_sha256']=subset_pop['file_bytes_sha256']
    subset_ref=write('fixtures/subset_reference.json',qdoc)
    subset_rows=[copy.deepcopy(r) for r in measurements if r['candidate_id'] in subset_ids]
    for r in subset_rows:r['reference_qualification_sha256']=subset_ref['file_bytes_sha256']
    subset_units=write('fixtures/subset_measurements.jsonl',subset_rows,True)
    bdoc=json.loads((root/baseline['path']).read_bytes());bdoc.update(reference_qualification_sha256=subset_ref['file_bytes_sha256'],
          population_sha256=subset_pop['file_bytes_sha256'],case_measurements=subset_units)
    subset_baseline=write('fixtures/subset_baseline.json',bdoc)
    edoc=json.loads((root/evaluation['path']).read_bytes());edoc.update(candidate_ids=subset_ids,population=subset_pop,
          reference_qualification=subset_ref,case_measurements=subset_units,compatible_baseline=subset_baseline)
    subset_eval=write('fixtures/subset_evaluation.json',edoc)
    subset_bound=copy.deepcopy(bound);subset_bound['contract']['evaluation']=subset_eval
    subset_result=ns['independent_product_evaluation'](subset_bound,states)
    ok('separate_independent_evaluation_subset_bound_to_question_and_evidence',subset_result['metric_results']['recall_at_k']['source_component_count']==48 and subset_result['metric_results']['recall_at_k']['components']['10']['value']==1)
    bad_links=copy.deepcopy(measurements);bad_links[0]['metrics']['citation_correctness']['denominator']=2
    bad_link_rows=write('fixtures/bad_link_denominator.jsonl',bad_links,True)
    ldoc=json.loads((root/evaluation['path']).read_bytes());ldoc['case_measurements']=bad_link_rows
    bad_link_eval=write('fixtures/bad_link_evaluation.json',ldoc)
    bad_link_bound=copy.deepcopy(bound);bad_link_bound['contract']['evaluation']=bad_link_eval
    try:ns['independent_product_evaluation'](bad_link_bound,states);raised=False
    except ns['EvidenceGap'] as error:raised=str(error)=='CITATION_LINK_DENOMINATOR_CONFLICT'
    ok('citation_denominator_cannot_discard_or_add_emitted_links',raised)
    bad=copy.deepcopy(measurements);bad[0]['critical_assessment']['state']='UNDETERMINED';bad[0]['critical_assessment']['unknown_factual_claim_count']=1
    bad_rows=write('fixtures/unknown.jsonl',bad,True);bad_eval=json.loads((root/evaluation['path']).read_bytes());bad_eval['case_measurements']=bad_rows
    bad_binding=write('fixtures/unknown_eval.json',bad_eval);bound['contract']['evaluation']=bad_binding
    uncertain=ns['independent_product_evaluation'](bound,states)
    ok('unknown_critical_case_prevents_pass',uncertain['critical_gate']['status']=='BLOCKED' and not uncertain['all16_metrics_pass'])
    ns['S']['memory']['data_receipts']={'golden':write('fixtures/old_golden.jsonl',[{'candidate_id':population[0]['candidate_id']}],True)}
    try:ns['independent_product_evaluation'](bound,states);raised=False
    except ns['EvidenceGap'] as error:raised=str(error)=='EXPOSED_GOLDEN_IDS_CANNOT_BE_INDEPENDENT_HOLDOUT'
    ok('exposed_golden_ids_not_relabelled_untouched',raised)
    ns['S']['memory']['data_receipts']={'golden':write('fixtures/renamed_old_golden.jsonl',[{'candidate_id':'different-old-id',
          'evaluation_content':{'question':population[0]['question']}}],True)}
    try:ns['independent_product_evaluation'](bound,states);raised=False
    except ns['EvidenceGap'] as error:raised=str(error)=='RENAMED_EXPOSED_GOLDEN_QUESTION_CANNOT_BE_UNTOUCHED_HOLDOUT'
    ok('renaming_exposed_question_does_not_make_independent_holdout',raised)

report={'schema_version':'NB22B_PRODUCT_ENGINE_SYNTHETIC_VALIDATION_V1','status':'PASS','checks':checks,
        'real_provider_requests':0,'synthetic_qualification_is_expert_approval':False,
        'real_product_acceptance_established':False,'production_bootstrap_repetitions_changed':False}
pathlib.Path('deliverables/NB22B_product_engine_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
