# Native NB21C-C072 specification adapters; never execute arbitrary assertion strings.
def regression_spec_index(value):
    found={};stack=[value]
    while stack:
        node=stack.pop()
        if isinstance(node,dict):
            key=node.get('regression_spec_id')
            if isinstance(key,str):
                need(key not in found or canonical(found[key])==canonical(node),'CONFLICTING_REGRESSION_SPEC_ID')
                found[key]=node
            else:stack.extend(node.values())
        elif isinstance(node,list):stack.extend(node)
    return found


def execute_regression_suite():
    need('regression_specs' in S['memory'],'BOUND_REGRESSION_SPECIFICATIONS_REQUIRED')
    specs=regression_spec_index(S['memory']['regression_specs'])
    need(len(specs)==322,'NATIVE_REGRESSION_SPEC_COUNT_CONFLICT')
    comparison=S['memory'].get('historical_selected_evaluation',{})
    retrieval={}
    if comparison.get('per_query_results'):
        retrieval=unique(read_bound(comparison['per_query_results'],jsonl=True),'candidate_id')
    packets=semantic_packets();states=S['memory'].get('gap_review_states',{})
    reviews={r['candidate_id']:r['result'] for r in states.values() if r['status']=='LOCALLY_VALID_MODEL_GAP_REVIEW'}
    results=[]
    for key,spec in sorted(specs.items()):
        cid=spec.get('candidate_id');kind=spec.get('kind');packet=packets.get(cid)
        row={'regression_spec_id':key,'candidate_id':cid,'kind':kind,'status':'BLOCKED',
             'historical_specification_modified':False,'semantic_fix_claimed':False}
        if packet is None:
            row['reason']='CASE_NOT_AVAILABLE_IN_BOUND_HISTORICAL_POPULATION'
        elif spec.get('frozen_response_document_sha256')!=packet['response_document_sha256']:
            row['reason']='FROZEN_RESPONSE_SCOPE_DIFFERS_NO_AUTOMATIC_REBINDING'
        elif kind=='FIXED_QUERY_RETRIEVAL_REGRESSION':
            measured=retrieval.get(cid)
            if measured:
                hit=measured['variant']['hit_at_10'];target=spec.get('repair_target_hit_at_10')
                need(target==1,'NATIVE_RETRIEVAL_REPAIR_TARGET_CHANGED')
                row.update(status='PASS_IN_RETRIEVAL_CASE_SCOPE' if hit>=target else 'FAIL',
                           observed_hit_at_10=hit,target_hit_at_10=target,
                           selected_retrieval_variant=comparison['selected_variant'],
                           reason='ACTUAL_FROZEN_SELECTED_RETRIEVAL_REPLAY',
                           full_population_quality_acceptance_claimed=False)
            else:row['reason']='FROZEN_RETRIEVAL_CASE_MEASUREMENT_NOT_AVAILABLE'
        elif kind in {'EVALUATION_ACCOUNTING_REGRESSION','UNDETERMINED_DECISION_PRESERVATION','DISPUTE_PRESERVATION_AND_REVIEW'}:
            # Preservation is testable offline; it is not a qualified resolving judgment.
            row.update(status='PASS_ACCOUNTING_ONLY',reason='ORIGINAL_RESPONSE_AND_UNRESOLVED_REVIEW_PRESERVED',
                       resolving_judgment_established=False)
        elif kind=='SOURCE_BOUND_ANSWER_DECISION_REGRESSION':
            row.update(reason='QUALIFIED_POSTCHANGE_DECISION_FOR_SAME_QUESTION_EVIDENCE_SCOPE_REQUIRED',
                       historical_expected_behavior=spec.get('expected_behavior'),
                       historical_observed_behavior=spec.get('historical_observed_behavior'))
        elif kind=='CITATION_WITNESS_RECORDING_REGRESSION':
            current=reviews.get(cid)
            if current:
                undetermined=sum(r['support']=='UNDETERMINED' or r['intended_location']=='UNDETERMINED' for r in current['citation_links'])
                row.update(status='PASS_MODEL_SCOPE_RECORDING_ONLY',
                           reason='DISTINCT_LINK_VERDICTS_AND_EXACT_WITNESSES_OR_EXPLICIT_UNDETERMINED_RECORDED',
                           undetermined_link_count=undetermined,independent_semantic_fix_claimed=False)
            else:row['reason']='LINK_LEVEL_QUALIFIED_WITNESS_OR_EXPLICIT_NEW_VERDICT_REQUIRED'
        else:row['reason']='UNSUPPORTED_NATIVE_SPEC_KIND_REQUIRES_EXPLICIT_ADAPTER'
        results.append(row)
    receipt=save_rows('A12.actual_scoped_regression_suite',results)
    summary={'status':'REGRESSION_SPECIFICATIONS_ACCOUNTED_WITH_ACTUAL_SCOPED_REPLAY',
             'specification_count':len(specs),'status_counts':dict(collections.Counter(r['status'] for r in results)),
             'results':receipt,'all322_semantic_product_tests_passed':False,
             'accounting_or_recording_pass_is_not_semantic_fix':True,
             'test_cases_used_for_parameter_tuning':False}
    S['memory']['regression_suite']=summary
    return summary
