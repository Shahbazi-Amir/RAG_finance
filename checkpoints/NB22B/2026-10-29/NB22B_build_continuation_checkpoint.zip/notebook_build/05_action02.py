# NB22B-C005 — Action 2: versioned inputs, caches and test boundary.
def action02():
    verified = source('NB22_C056')
    context = source('NB22_C057')
    need(verified.get('independent_recomputation_complete') is True and
         verified.get('all_recorded_metric_comparisons_match') is True, 'C056_VERIFICATION_REQUIRED')
    need(context.get('blocked_metric_count') == 12, 'FROZEN_METRIC_SET_CHANGED')
    S['memory']['policy'] = context['contract']
    contract = source('NB21C_C025')
    need(context['contract']['configuration'] == contract['configuration'], 'C025_C057_CONFIGURATION_CONFLICT')
    need(context['contract']['metric_policy'] == contract['metric_policy'], 'C025_C057_POLICY_CONFLICT')
    need(context['contract']['coverage_policy'] == contract['coverage_policy'], 'C025_C057_COVERAGE_POLICY_CONFLICT')
    S['memory']['regression_policy'] = contract.get('regression_policy', {'allowed_deterioration': contract['configuration']['regression_allowed_deterioration']})
    receipts = verified['input_file_receipts']
    need(isinstance(receipts, dict) and {'chunks', 'golden', 'hybrid', 'reranker'}.issubset(receipts),
         'C056_INPUT_RECEIPT_SCHEMA_REQUIRES_REVIEW')
    S['memory']['data_receipts'] = receipts
    assets = []
    for role, r in receipts.items():
        p = project_path(r['path'])
        assets.append({'role': role, 'path': r['path'], 'exists': p.is_file(),
                       'declared_file_bytes_sha256': r['file_bytes_sha256'],
                       'prior_verification': 'C056', 'fresh_hash_not_claimed': True})
    S['memory']['test_plan'] = {'selection': 'DEVELOPMENT',
        'historical_test': 'EXPOSED_NOT_FOR_PARAMETER_SELECTION',
        'new_independent_holdout': 'NOT_ESTABLISHED_BY_THE_REVIEWED_HANDOFF',
        'old_calibration_holdout_602_is_not_general_answer_correctness_holdout': True}
    return {'status': 'INPUTS_AND_EVALUATION_BOUNDARY_RECORDED', 'assets': assets,
            'cache_policy': {'downloads': False, 'regenerate_embeddings': False,
                             'unknown_model_attempt_resend': False},
            'test_plan': S['memory']['test_plan'],
            'subtasks': [subtask('2.1', 'COMPLETE_IN_SCOPE', 'Four exact data bindings and frozen contract attached; full producer/policy closure remains action13.'),
                         subtask('2.2', 'COMPLETE', 'C056 verification reused without repeating its historical metric computation.'),
                         subtask('2.3', 'COMPLETE_IN_SCOPE', 'Cache-only local runtime; absent files block their consumer instead of triggering downloads.'),
                         subtask('2.4', 'COMPLETE_IN_SCOPE', 'Development selection and independent-test prerequisite recorded; new holdout not invented.')]}
A02 = run_action(2, action02)
