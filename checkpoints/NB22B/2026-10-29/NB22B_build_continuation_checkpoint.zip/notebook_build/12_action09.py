# NB22B-C012 — Action 9: exact existing no-answer evidence, without Test policy tuning.
def action09():
    packets=semantic_packets();policy=frozen_metric('no_answer_precision_recall_f1')
    metric_table=output_of('NB21C_C068','metric_table')
    prior=next((r['value'] for r in metric_table if r['metric']=='no_answer_precision_recall_f1'),None)
    need(isinstance(prior,dict),'BOUND_NATIVE_ABSTENTION_RESULT_REQUIRED')
    allowed_expected={'ANSWER_SUPPORTED','BOUNDED_ANSWER_SUPPORTED','CLARIFICATION_REQUIRED','ABSTENTION_REQUIRED'}
    allowed_observed={'SUBSTANTIVE_RESPONSE','CLARIFICATION_ONLY','ABSTENTION_ONLY'}
    matrix=collections.Counter({'TP':0,'FP':0,'FN':0,'TN':0});included=[];excluded=[]
    action_matrix=collections.defaultdict(collections.Counter)
    for cid,p in sorted(packets.items()):
        review=p.get('previous_action26_output')
        if not isinstance(review,dict) or 'expected_behavior' not in review or 'observed_behavior' not in review:
            excluded.append({'candidate_id':cid,'reason':'NO_VALID_STORED_JUDGMENT'});continue
        need(review.get('candidate_id')==cid,'ABSTENTION_REVIEW_CASE_IDENTITY_CONFLICT')
        expected,observed=review['expected_behavior'],review['observed_behavior']
        action_matrix[expected][observed]+=1
        if expected not in allowed_expected or observed not in allowed_observed:
            excluded.append({'candidate_id':cid,'expected_behavior':expected,'observed_behavior':observed,
                             'reason':'REFERENCE_OR_BEHAVIOR_OUTSIDE_BINARY_SCOPE'});continue
        truth=expected=='ABSTENTION_REQUIRED';prediction=observed=='ABSTENTION_ONLY'
        key='TP' if truth and prediction else 'FN' if truth else 'FP' if prediction else 'TN'
        matrix[key]+=1;included.append(cid)
    tp,fp,fn=matrix['TP'],matrix['FP'],matrix['FN']
    precision=tp/(tp+fp) if tp+fp else None;recall=tp/(tp+fn) if tp+fn else None
    f1=2*tp/(2*tp+fp+fn) if tp+fn>0 else None
    need(set(included)==set(prior['included_candidate_ids']),'ABSTENTION_ELIGIBLE_ID_SET_CONFLICT')
    need(dict(matrix)==prior['confusion_matrix'] and len(included)==prior['evaluated_case_count'],
         'HISTORICAL_ABSTENTION_RECOMPUTATION_CONFLICT')
    need(all(a is b if a is None or b is None else abs(a-b)<=1e-12
             for a,b in [(precision,prior['precision']),(recall,prior['recall']),(f1,prior['f1'])]),
         'HISTORICAL_ABSTENTION_RATE_CONFLICT')
    result={'scope':'CONDITIONAL_ON_EVALUABLE_MODEL_REFERENCE','confusion_matrix':dict(matrix),
            'evaluated_case_count':len(included),'excluded_count':len(excluded),'excluded_cases':excluded,
            'precision':precision,'recall':recall,'f1':f1,
            'action_confusion_matrix':{k:dict(v) for k,v in action_matrix.items()},
            'scoped_absolute_f1_check':'PASS' if f1 is not None and f1>=.85 else 'FAIL' if f1 is not None else 'BLOCKED',
            'formal_release_reference_qualification':'NOT_ESTABLISHED_FOR_NEW_SELECTED_PRODUCT',
            'historical_test_used_for_tuning':False,'new_api_calls':0}
    receipt=save_json('A09.verified_historical_abstention',result)
    S['memory']['abstention_measurement']=result
    return {'status':('HISTORICAL_ABSTENTION_REFERENCE_POSITIVE_CLASS_ABSENT' if f1 is None else 'HISTORICAL_ABSTENTION_REPRODUCED_SCOPED_F1_BELOW_TARGET' if f1<.85 else 'HISTORICAL_ABSTENTION_REPRODUCED_SCOPED_F1_MEETS_THRESHOLD'),
            'historical_measurement':result,'measurement_output':receipt,'frozen_policy':policy,
            'threshold_modified':False,
            'remaining_work':['Bind qualified Development reference and explicit product action policy before changing behavior.',
                              'Do not fix the sixteen historical Test false positives by memorizing their IDs.'],
            'subtasks':[subtask('9.1','COMPLETE','Exact historical confusion matrix and conditional1131 denominator reproduced from C068; no rejudgment.',[receipt]),
                        subtask('9.2','BLOCKED','New product reference and compatible action policy are not established by historical model labels.'),
                        subtask('9.3','COMPLETE','Eligibility/exclusions fixed by the producer rule; clarification and safety routes remain separate.'),
                        subtask('9.4','COMPLETE_IN_SCOPE','All existing labels reused; invalid/undetermined records explicitly preserved.'),
                        subtask('9.5','BLOCKED','No policy retuning on exposed Test; a qualified Development policy experiment remains necessary.')]}
A09=run_action(9,action09)
