# NB22B-C011 — Action 8: link, locator, coverage and attribution accounting.
def action08():
    packets = semantic_packets(); links = []; span_count = 0; unresolved_attribution = []
    for cid, p in sorted(packets.items()):
        response = p['decoded_response']; support = p['historical_support']
        evidence = {e['evidence_id']: e['text'] for e in p['original_evidence']}
        prior = {r['claim_index']: r for r in support['claim_results']}
        for i, claim in enumerate(response['claims']):
            j = prior[i]; spans = collections.defaultdict(list)
            for span in j.get('supporting_spans', []):
                eid = span['evidence_id']; a = span['start']; b = span['end']
                need(eid in evidence and type(a) is int and type(b) is int and
                     0 <= a < b <= len(evidence[eid]), 'SPAN_BOUNDARY_CONFLICT:' + cid)
                need(evidence[eid][a:b] == span['quote'], 'EXACT_SPAN_TEXT_CONFLICT:' + cid)
                spans[eid].append({'start': a, 'end': b, 'quote_sha256': sha(span['quote'].encode())})
                span_count += 1
            refs = claim['evidence_ids']
            need(len(refs) == len(set(refs)) and set(refs).issubset(evidence), 'LINK_REFERENCE_CONFLICT:' + cid)
            for eid in refs:
                links.append({'candidate_id': cid, 'claim_index': i, 'evidence_id': eid,
                              'response_document_sha256': p['response_document_sha256'],
                              'claim_sha256': sha(canonical(claim)), 'exact_recorded_spans': spans[eid],
                              'historical_claim_outcome': j['outcome'],
                              'individual_link_semantic_verdict': None,
                              'intended_location_semantic_verdict': None,
                              'new_api_dispatch': False})
        unresolved_attribution.append({'candidate_id': cid,
                                      'response_document_sha256': p['response_document_sha256'],
                                      'status': 'EXPLICIT_ASSERTION_EXTRACTION_AND_QUALIFIED_ROLE_VERDICTS_NOT_ESTABLISHED'})
    receipt = save_rows('A08.claim_citation_links', links)
    roles = save_rows('A08.attribution_qualification', unresolved_attribution)
    measured = aggregate_gap_measurements(packets, S['memory'].get('gap_review_states', {}))
    measured_receipt = save_json('A08.model_scope_gap_measurements', measured)
    S['memory']['gap_measurements'] = measured
    names = ('citation_correctness', 'citation_locator_accuracy', 'claim_citation_coverage', 'attribution_correctness')
    gaps = {name: {'status': 'BLOCKED', 'policy': frozen_metric(name)['frozen_policy'],
                   'historical_measurement_state': frozen_metric(name)['recorded_measurement_state'],
                   'current_model_scope_measurement': measured.get(name),
                   'reason': 'Current model-scope results are reported separately; product identity, qualified reference scope and compatible baseline still require binding.'} for name in names}
    return {'status': 'LINK_LOCATOR_AND_CURRENT_MODEL_SCOPE_MEASUREMENTS_RECORDED',
            'distinct_link_count': len(links), 'exact_spans_checked': span_count,
            'links_with_exact_spans': sum(bool(x['exact_recorded_spans']) for x in links),
            'artifacts': [receipt, roles, measured_receipt], 'model_scope_measurements': measured, 'metric_qualification': gaps,
            'subtasks': [subtask('8.1', 'COMPLETE', 'Distinct claim-evidence links bound to exact historical response and claim.', [receipt]),
                         subtask('8.2', 'COMPLETE_IN_SCOPE', 'Exact source spans checked; semantic support of each link not inferred.'),
                         subtask('8.3', 'BLOCKED', 'Current extraction/coverage saved; formal product denominator and qualified references remain open.'),
                         subtask('8.4', 'BLOCKED', 'Explicit attribution assertions and new verdicts reported when reviewed; independent authority and product baseline remain open.', [roles]),
                         subtask('8.5', 'COMPLETE_IN_SCOPE', 'Scoped span evidence reused with exact denominators; compatible baseline remains a stated gate prerequisite.')]}
A08 = run_action(8, action08)
