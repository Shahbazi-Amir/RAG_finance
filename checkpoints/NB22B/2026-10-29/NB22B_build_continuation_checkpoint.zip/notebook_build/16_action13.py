# NB22B-C016 — Action 13: producer/source identity, environment and publication scope.
def action13():
    notebook = project_path('notebooks/phase2/22b_quality_improvement_and_acceptance.ipynb')
    need(notebook.is_file(), 'CURRENT_NOTEBOOK_MUST_BE_PLACED_AT_DECLARED_PATH')
    doc = _boot_decode(notebook.read_bytes())
    sources = [c['source'] if isinstance(c['source'], str) else ''.join(c['source'])
               for c in doc['cells'] if c['cell_type'] == 'code']
    fingerprint = sha(canonical(sources))
    expected = doc.get('metadata', {}).get('nb22b', {}).get('code_source_sha256')
    need(fingerprint == expected, 'SAVED_NOTEBOOK_CODE_SOURCE_DIFFERS_FROM_REVIEWED_BUILD')
    package_versions = {}
    for package in ('numpy', 'onnxruntime', 'transformers', 'tokenizers', 'qdrant-client'):
        try: package_versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: package_versions[package] = None
    environment = {'python_version': platform.python_version(), 'implementation': platform.python_implementation(),
                   'system': platform.system(), 'machine': platform.machine(), 'package_versions': package_versions,
                   'historical_producer_environment_claimed': False, 'full_reproducible_lock_proven': False}
    environment_receipt = save_json('A13.observed_execution_environment', environment)
    # This scan applies only to current generated JSON/JSONL/code; not the old226-file checkpoint or models.
    personal = re.compile(r'/(?:Users|home)/[^/\s"\x27<>]+/')
    findings = []
    for receipt in S['artifacts']:
        path = project_path(receipt['path'])
        if path.suffix in {'.json', '.jsonl', '.md'}:
            value = path.read_text(encoding='utf-8')
            count = len(personal.findall(value))
            if count: findings.append({'path': receipt['path'], 'personal_path_pattern_count': count})
    source_count = sum(len(personal.findall(s)) for s in sources)
    if source_count: findings.append({'path': notebook.relative_to(ROOT).as_posix(), 'personal_path_pattern_count': source_count})
    closure=None;closure_gap=None
    if 'product_bound' in S['memory']:
        try:closure=product_technical_closure(S['memory']['product_bound'])
        except EvidenceGap as error:closure_gap=str(error)
    else:closure_gap='PRODUCT_TECHNICAL_CONTRACT_NOT_BOUND'
    S['memory']['product_technical_closure']=closure
    prior = source('NB22_C047')
    manifest = {'schema_version': 'NB22B_DERIVATIVE_TECHNICAL_MANIFEST_V1',
                'producer': {'notebook': notebook.relative_to(ROOT).as_posix(),
                             'code_source_sha256': fingerprint, 'hash_definition': 'SHA256_CANONICAL_JSON_ORDERED_CODE_CELL_SOURCES'},
                'experimental_selection': S['memory'].get('selection_receipt'),
                'historical_parent_checkpoint': prior['checkpoint_manifest'],
                'current_derivative_assets': list(S['artifacts']), 'environment': environment_receipt,
                'publication_scope': 'LOCAL_EXPERIMENTAL_DERIVATIVES_ONLY',
                'privacy_scan_scope': 'CURRENT_DERIVATIVE_PERSONAL_PATH_PATTERN_ONLY',
                'privacy_findings': findings, 'full_secret_or_data_disclosure_clearance_claimed': False,
                'complete_product_policy_and_dependency_closure': closure is not None,
                'product_technical_closure':closure,'product_technical_closure_gap':closure_gap,
                'historical_restore_scope_not_extended': True,
                'health_checks_of_prior_notebooks': CONFIG['health_deferral']}
    receipt = save_json('A13.derivative_technical_manifest', manifest)
    S['memory']['technical_manifest'] = receipt
    return {'status': 'VERSION_BOUND_PRODUCT_TECHNICAL_CLOSURE_RECORDED' if closure else 'DERIVATIVE_PRODUCER_BOUND_FULL_PRODUCT_CLOSURE_OPEN',
            'manifest': receipt, 'environment': environment_receipt, 'privacy_findings': findings,
            'subtasks': [subtask('13.1', 'COMPLETE_IN_SCOPE', 'New notebook code-source identity bound; current Git HEAD not substituted for historical producer.', [receipt]),
                         subtask('13.2', 'COMPLETE' if closure else 'BLOCKED', 'Complete product policy/provenance validated when provided; otherwise the exact lineage gap is retained.'),
                         subtask('13.3', 'COMPLETE' if closure else 'BLOCKED', 'Versioned environment/source/restore evidence validated when provided; observed environment alone does not prove full closure.'),
                         subtask('13.4', 'COMPLETE_IN_SCOPE', 'Local derivative scope and scoped path scan recorded; whole checkpoint public clearance not claimed.'),
                         subtask('13.5', 'COMPLETE_IN_SCOPE', 'Only changed derivative assets checked; prior deferred health/clean runs not reopened.')]}
A13 = run_action(13, action13)
