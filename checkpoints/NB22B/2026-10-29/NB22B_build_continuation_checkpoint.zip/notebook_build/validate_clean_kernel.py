import sys,pathlib,os,json,time,ast,hashlib
base=pathlib.Path('notebook_build').resolve();sys.path.insert(0,str(base/'validation_deps'))
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
fixture=base/'kernel_fixture';source=fixture/'notebooks/phase2/22b_quality_improvement_and_acceptance.ipynb'
assert source.is_file(),'SYNTHETIC_KERNEL_FIXTURE_MUST_BE_CREATED_FIRST'
previous=nbformat.read(source,as_version=4)
old_boot=next(c.source for c in previous.cells if c.cell_type=='code' and c.source.startswith('# NB22B-C002'))
pins=next(ast.literal_eval(n.value) for n in ast.parse(old_boot).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PINNED_INPUTS' for t in n.targets))
notebook=nbformat.read('deliverables/22b_quality_improvement_and_acceptance.ipynb',as_version=4)
production_fingerprint=notebook.metadata.nb22b.code_source_sha256
cell=next(c for c in notebook.cells if c.cell_type=='code' and c.source.startswith('# NB22B-C002'))
a=cell.source.index('PINNED_INPUTS = ');b=cell.source.index('\n\nCHECKLIST =',a)
cell.source=cell.source[:a]+'PINNED_INPUTS = '+repr(pins)+cell.source[b:]
cell.source=cell.source.replace("'semantic_review': {'enabled': True","'semantic_review': {'enabled': False")
can=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
notebook.metadata.nb22b.code_source_sha256=hashlib.sha256(can([c.source for c in notebook.cells if c.cell_type=='code'])).hexdigest()
nbformat.write(notebook,source)
# This fixture intentionally replaces pins and disables paid dispatch; production file remains unchanged.
for folder in ('kernel_runtime','kernel_ipython','kernel_config'):(base/folder).mkdir(exist_ok=True)
os.environ.update(RAG_FINANCE_ROOT=str(fixture),PYTHONPATH=str(base/'validation_deps'),
                  JUPYTER_RUNTIME_DIR=str(base/'kernel_runtime'),IPYTHONDIR=str(base/'kernel_ipython'),
                  JUPYTER_CONFIG_DIR=str(base/'kernel_config'))
started=time.monotonic()
# Both TCP and IPC Jupyter kernel startup were observed to fail with EPERM in this environment.
# Use a fresh isolated interpreter, without claiming that a Jupyter kernel was executed.
import subprocess
program=r'''import json,sys,os,pathlib,contextlib,io
request=json.load(sys.stdin);os.environ['RAG_FINANCE_ROOT']=request['root']
notebook=json.loads(pathlib.Path(request['notebook']).read_bytes());namespace={};count=0
with contextlib.redirect_stdout(io.StringIO()):
 for cell in notebook['cells']:
  if cell['cell_type']=='code':
   source=cell['source'] if isinstance(cell['source'],str) else ''.join(cell['source'])
   exec(compile(source,'<NB22B-fresh-process>','exec'),namespace);count+=1
assert count==17
assert namespace['S']['new_api_calls']==0
assert len(namespace['S']['actions'])==14
print(json.dumps({'code_cells':count,'actions':len(namespace['S']['actions']),
 'new_api_calls':namespace['S']['new_api_calls'],'acceptance':namespace['A14']['release_acceptance_granted']}))
'''
process=subprocess.run([sys.executable,'-I','-c',program],input=json.dumps({'root':str(fixture),'notebook':str(source)}),
                       text=True,capture_output=True,timeout=180)
assert process.returncode==0,process.stderr
fresh=json.loads(process.stdout)
errors=[];executed=list(range(1,fresh['code_cells']+1))
# The result above is from an actual fresh process; notebook outputs are not fabricated.
assert not errors and executed==list(range(1,18)),(errors,executed)
report={'schema_version':'NB22B_FRESH_ISOLATED_PROCESS_VALIDATION_V1','status':'PASS',
        'fresh_process_code_cells_executed':17,'jupyter_kernel_executed':False,
        'jupyter_kernel_startup_status':'BLOCKED_BY_ENVIRONMENT_TCP_AND_IPC_SOCKET_EPERM','error_output_count':len(errors),
        'sequential_cells_executed':executed,'elapsed_seconds':round(time.monotonic()-started,3),
        'python_version':sys.version.split()[0],'operating_system':sys.platform,
        'fixture':'FULL_SIZE_SYNTHETIC_NATIVE_SCHEMAS_3813_GOLDEN_2664_DEV_1149_TEST',
        'production_notebook_modified':False,'tested_production_code_fingerprint':production_fingerprint,'real_provider_requests':0,
        'real_mac_execution_established':False,'real_semantic_quality_or_acceptance_established':False}
pathlib.Path('deliverables/NB22B_clean_kernel_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
