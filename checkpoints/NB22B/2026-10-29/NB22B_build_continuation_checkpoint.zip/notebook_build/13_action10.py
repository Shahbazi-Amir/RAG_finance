# NB22B-C013 — Action 10: safety coverage and preserved issue/regression dispositions.
def action10():
    report = source('NB21C_C040'); policy = frozen_metric('safety_violation_rate')
    effective = output_of('NB21C_C040', 'effective1112', jsonl=True)
    unique(effective, 'candidate_id')
    need(len(effective) == 1112, 'SAFETY_SAME_SCOPE_POPULATION_CHANGED')
    issue_report = source('NB21C_C078')
    open_reviews = output_of('NB21C_C078', 'open_reviews')
    specs = output_of('NB21C_C078', 'preserved_regression_specs')
    # Preserve native structures; a specification is not a test execution record.
    S['memory']['regression_specs'] = specs
    S['memory']['open_reviews'] = open_reviews
    S['memory']['safety_report'] = report
    return {'status': 'SAFETY_AND_REGRESSION_EVIDENCE_REUSED_WITH_OPEN_QUALIFICATION',
            'same_scope_cases': 1112, 'historical_scope': report['same_four_rule_scope'],
            'population_accounting': report['full1149_accounting'],
            'disputed_risk': report['disputed_risk_review'],
            'open_reviews': open_reviews, 'regression_specifications': specs,
            'specifications_executed_by_this_notebook': False,
            'complete_product_policy_bound': False, 'frozen_policy': policy,
            'subtasks': [subtask('10.1', 'BLOCKED', 'Recorded four-rule rubric is bound; complete product policy and selected new response version remain prerequisites.'),
                         subtask('10.2', 'COMPLETE_IN_SCOPE', '1112 same-scope cases retained; legacy37 and boundary fixtures are not merged into the denominator.'),
                         subtask('10.3', 'BLOCKED', 'Disputed risk and existing open reviews preserved; no independent adjudication fabricated.'),
                         subtask('10.4', 'BLOCKED', 'Unknown or disputed critical cases cannot establish zero violations.'),
                         subtask('10.5', 'COMPLETE_IN_SCOPE', 'Versioned regression specifications loaded and tracked; no claim that322 product tests were executed.')]}
A10 = run_action(10, action10)
