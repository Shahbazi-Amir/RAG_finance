# NB22B-C010 — Action 7: reuse exact response/claim/requirement evidence.
def semantic_packets():
    if 'semantic_packets' not in S['memory']:
        rows = output_of('NB21C_C068', 'complete_remaining_measurement_packets', jsonl=True)
        packets = unique(rows, 'candidate_id')
        need(len(packets) == 1149, 'SEMANTIC_PACKET_POPULATION_CONFLICT')
        for cid, p in packets.items():
            need(sha(p['response_document'].encode('utf-8')) == p['response_document_sha256'], 'RESPONSE_DOCUMENT_VERSION_CONFLICT:' + cid)
            response = _boot_decode(p['response_document'])
            need(response == p['decoded_response'], 'DECODED_RESPONSE_CONFLICT:' + cid)
            support = p['historical_support']
            need(support['candidate_id'] == cid and support['response_sha256'] == p['response_document_sha256'],
                 'HISTORICAL_SUPPORT_VERSION_CONFLICT:' + cid)
        S['memory']['semantic_packets'] = packets
    return S['memory']['semantic_packets']


def frozen_metric(name):
    context = source('NB22_C057')
    matches = [r['record'] for r in context['blocked_metric_entries'] if r['record']['metric'] == name]
    need(len(matches) == 1, 'EXACT_FROZEN_METRIC_REQUIRED:' + name)
    return matches[0]


def action07():
    packets = semantic_packets(); units = []; requirements = []; outcomes = collections.Counter()
    for cid, p in sorted(packets.items()):
        response = p['decoded_response']; support = p['historical_support']
        prior = {r['claim_index']: r for r in support['claim_results']}
        need(len(prior) == len(response['claims']), 'CLAIM_JUDGMENT_POPULATION_CONFLICT:' + cid)
        for i, claim in enumerate(response['claims']):
            j = prior[i]
            need(j['claim_text'] == claim['claim_text'] and j['claim_sha256'] == sha(canonical(claim)),
                 'CLAIM_IDENTITY_CONFLICT:' + cid)
            need(j['evidence_ids'] == claim['evidence_ids'], 'CLAIM_EVIDENCE_BINDING_CONFLICT:' + cid)
            outcomes[j['outcome']] += 1
            units.append({'candidate_id': cid, 'claim_index': i,
                          'response_document_sha256': p['response_document_sha256'],
                          'claim_sha256': j['claim_sha256'], 'historical_outcome': j['outcome'],
                          'historical_review_reused': True, 'independent_reference_qualification': False,
                          'all_answer_text_claim_extraction_proven': False})
        for i, requirement in enumerate(p.get('recorded_requirements_from_action26') or []):
            requirements.append({'candidate_id': cid, 'requirement_index': i,
                                 'response_document_sha256': p['response_document_sha256'],
                                 'recorded_requirement': requirement,
                                 'per_requirement_coverage_verdict': None,
                                 'status': 'QUALIFIED_COVERAGE_VERDICT_NOT_BOUND_BY_THIS_ADAPTER'})
    claim_receipt = save_rows('A07.reused_claim_units', units)
    requirement_receipt = save_rows('A07.reference_requirement_units', requirements)
    S['memory']['semantic_unit_receipts'] = [claim_receipt, requirement_receipt]
    policies = {name: frozen_metric(name) for name in ('groundedness', 'answer_completeness')}
    jobs, plan = prepare_gap_jobs(packets)
    try:
        review_states, dispatch = run_gap_jobs(jobs, plan)
    except EvidenceGap as error:
        review_states = {j['key']: parse_gap_body(j, project_path(
            'artifacts/phase2/quality_improvement/NB22B.semantic_gap_review_v1/jobs/'+j['key'])) for j in jobs}
        dispatch = {**plan, 'dispatch_status':'GATED_NO_NEW_DISPATCH', 'reason':str(error)}
    S['memory']['gap_jobs'] = jobs
    S['memory']['gap_review_states'] = review_states
    S['memory']['gap_review_plan'] = plan
    plan_receipt = save_json('A07.semantic_gap_review_plan', dispatch)
    result_receipt = save_rows('A07.semantic_gap_review_results', list(review_states.values()))
    S['memory']['gap_review_receipts'] = [plan_receipt, result_receipt]

    valid_review_count = sum(r['status']=='LOCALLY_VALID_MODEL_GAP_REVIEW' for r in review_states.values())
    run_summary = {'dispatch_status':dispatch.get('dispatch_status'), 'dispatch_gate_reason':dispatch.get('reason'),
                   'stop_reasons':dispatch.get('stop_reasons',[]), 'valid_model_gap_reviews':valid_review_count,
                   'required_case_count':len(packets),
                   'review_status_counts':dict(collections.Counter(r['status'] for r in review_states.values()))}
    # These are historical recorded-unit counts, never full text semantic accuracy.
    return {'status': ('SEMANTIC_GAP_REVIEWS_COMPLETE_IN_MODEL_SCOPE' if valid_review_count==len(packets) else 'SEMANTIC_GAP_REVIEW_PARTIAL_OR_GATED_WITH_PRIOR_SUPPORT_REUSED'),
            'run_summary':run_summary,
            'response_count': len(packets), 'recorded_claim_units': len(units),
            'historical_claim_outcome_counts': dict(outcomes), 'recorded_requirement_units': len(requirements),
            'artifacts': [claim_receipt, requirement_receipt], 'frozen_policies': policies,
            'semantic_review_dispatch': dispatch, 'semantic_review_result_status_counts': dict(collections.Counter(r['status'] for r in review_states.values())),
            'semantic_review_artifacts': [plan_receipt,result_receipt],
            'new_semantic_judgments': min(dispatch.get('new_calls',0),max(0,valid_review_count-dispatch.get('cached_valid_reviews',valid_review_count))),
            'valid_model_gap_reviews_total':valid_review_count,
            'complete_factual_extraction_established': False,
            'current_candidate_response_binding': 'HISTORICAL_RESPONSES_ONLY_NOT_AUTOMATICALLY_REGENERATED_FOR_SELECTED_RETRIEVAL',
            'subtasks': [subtask('7.1', 'COMPLETE_IN_SCOPE', 'Historical response, recorded claims and reference requirements joined by exact response hash.', [claim_receipt, requirement_receipt]),
                         subtask('7.2', 'COMPLETE_IN_SCOPE', 'Prior support reused; extraction exhaustiveness and reference qualification remain unestablished.'),
                         subtask('7.3', 'COMPLETE', 'Recorded-claim micro counts kept separate from query macro completeness and qualified reference units.'),
                         subtask('7.4', 'COMPLETE_IN_SCOPE', 'Unbound per-requirement verdicts explicitly enumerated; sufficient historical support not queued for repeat.'),
                         subtask('7.5', 'BLOCKED', 'Compatible prechange semantic baseline and complete qualified claim/reference coverage are not established by these artifacts.')]}
A07 = run_action(7, action07)
