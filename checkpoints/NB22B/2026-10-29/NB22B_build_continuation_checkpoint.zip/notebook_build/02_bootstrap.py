# NB22B-C002 — Read-only explicit inputs and run configuration.
# PINNED_INPUTS and CHECKLIST are embedded from the reviewed repository snapshot below.

CONFIG = {
    'schema_version': 'NB22B_EXECUTION_CONFIG_V1',
    'development_experiment': 'NB17_CACHED_RRF_AND_LOCAL_DEPTH100_V1',
    'execute_local_depth100': True,
    'maximum_local_seconds': 21600,
    'rrf_weights': [0.25, 0.5, 0.75, 1.0],
    'rrf_constants': [10, 30, 60],
    'batch_size': 4,
    'maximum_sequence_length': 512,
    'onnxruntime_version': '1.16.3',
    'onnx_sha256': '6c2513767fb63d008a4377bef7a7a3555433d9436342bb53e35a3a72ffc52d4b',
    'model_id': 'cross-encoder/mmarco-mMiniLMv2-L12-H384-v1',
    'model_revision': '1427fd652930e4ba29e8149678df786c240d8825',
    'minimum_source_components': 30,
    'bootstrap_repetitions': 10000,
    'bootstrap_seed': 210063,
    'confidence_level': 0.95,
    'paid_model_dispatch': True,
    'semantic_review': {'enabled': True, 'workers': 18, 'rpm': 80,
                        'maximum_new_requests': 1149, 'authorized_cap_toman': 1650000,
                        'approval_over_500k_recorded': True,
                        'approval': {'source': 'CURRENT_CHAT_USER_APPROVAL_2026_10_29',
                                     'task_version': 'NB22B_HISTORICAL_SEMANTIC_GAPS_V1',
                                     'approved_planning_cap_toman': 1650000,
                                     'maximum_requests': 1149}},
    'development_generation_pilot_cases': 32,
    'product_execution': {'enabled': False, 'approved_plan_sha256': None, 'authorized_cap_toman': 0,
                          'maximum_requests': 0, 'approval_over_500k_recorded': False, 'workers': 1, 'rpm': 20},
    'new_network_calls': 0,
    'historical_test_retuning': False,
    'release_distribution_scope': 'LOCAL_ONLY',
    'health_deferral': 'DEFERRED_BY_USER_TO_OPTIMIZATION',
}

# No absolute personal path is embedded. This optional variable is only a root override.
_override = os.environ.get('RAG_FINANCE_ROOT')
_start = Path(_override).expanduser().resolve() if _override else Path.cwd().resolve()
ROOT = next((p for p in [_start, *_start.parents]
             if (p / 'notebooks/phase2').is_dir()
             and (p / 'data/Road_Maps/RAG_finance_phase2_modular_notebooks_execution_plan.md').is_file()), None)
SOURCE_CODE_SHA256 = None
SAVED_CODE_IDENTITY_VALID = False
if ROOT is not None:
    _self = ROOT / 'notebooks/phase2/22b_quality_improvement_and_acceptance.ipynb'
    if _self.is_file():
        _nb = json.loads(_self.read_bytes())
        _codes = [c['source'] if isinstance(c['source'], str) else ''.join(c['source'])
                  for c in _nb['cells'] if c['cell_type'] == 'code']
        SOURCE_CODE_SHA256 = hashlib.sha256(json.dumps(_codes, ensure_ascii=False, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()
        SAVED_CODE_IDENTITY_VALID = SOURCE_CODE_SHA256 == _nb.get('metadata', {}).get('nb22b', {}).get('code_source_sha256')
S = {'root': ROOT, 'config': CONFIG, 'inputs': {}, 'receipts': {}, 'issues': [],
     'actions': {}, 'artifacts': [], 'source_reads': {}, 'memory': {}, 'new_api_calls': 0, 'saved_code_identity_valid': SAVED_CODE_IDENTITY_VALID}

def _boot_pairs(items):
    d = {}
    for k, v in items:
        if k in d:
            raise ValueError('DUPLICATE_JSON_KEY')
        d[k] = v
    return d

def _boot_decode(raw):
    def reject(x):
        raise ValueError('NONFINITE_JSON_VALUE')
    return json.loads(raw, object_pairs_hook=_boot_pairs, parse_constant=reject)

# C002 never creates files and never loads a model.
if ROOT is None:
    S['issues'].append({'role': 'project_root', 'status': 'ROOT_NOT_RESOLVED',
                        'reason_fa': 'نوت‌بوک باید در مخزن اجرا شود یا RAG_FINANCE_ROOT تنظیم شود.'})
else:
    for role, binding in PINNED_INPUTS.items():
        if role == 'NB21C_PRIMARY':
            continue  # Load its larger body only when the semantic work consumes it.
        relative = Path(binding['path'])
        path = (ROOT / relative).resolve()
        if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(ROOT):
            S['issues'].append({'role': role, 'status': 'INVALID_BINDING_PATH'})
            continue
        if not path.is_file():
            S['issues'].append({'role': role, 'status': 'NOT_AVAILABLE_AT_PINNED_LOCAL_PATH',
                                'path': binding['path'], 'absence_projectwide_claimed': False})
            continue
        before = path.stat()
        raw = path.read_bytes()
        after = path.stat()
        actual = hashlib.sha256(raw).hexdigest()
        if actual != binding['file_bytes_sha256'] or (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            S['issues'].append({'role': role, 'status': 'INPUT_IDENTITY_CONFLICT', 'path': binding['path']})
            continue
        try:
            value = _boot_decode(raw)
        except (ValueError, UnicodeError):
            S['issues'].append({'role': role, 'status': 'PINNED_JSON_INVALID', 'path': binding['path']})
            continue
        S['inputs'][role] = value
        receipt = {'path': binding['path'], 'file_bytes_sha256': actual, 'bytes': len(raw),
                   'stat': [after.st_size, after.st_mtime_ns, after.st_ino], 'validation': 'PASS'}
        S['receipts'][role] = receipt
        S['source_reads'][binding['path']] = {'receipt': receipt, 'value': value}
print(json.dumps({'status': 'READ_ONLY_PREFLIGHT_COMPLETE', 'root_resolved': ROOT is not None,
                  'verified_pinned_inputs': len(S['inputs']), 'input_issues': S['issues'],
                  'api_calls': 0, 'files_written': 0}, ensure_ascii=False, indent=2))
