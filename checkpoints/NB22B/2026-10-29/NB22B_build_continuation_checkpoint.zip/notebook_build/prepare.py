import pathlib,json,re,hashlib
base=pathlib.Path('repository_snapshot');notebook_cache={};objs=json.loads(pathlib.Path('inspection/saved_output_objects.json').read_text());pins={};summaries={}
for r in objs:
 v=r['value'];name=r['notebook'].split('/')[-1]
 if name.startswith('21c'):
  tag=f'NB21C_C{(r["cell"]+1)//2:03d}'
  # Actual cell labels are taken from source, not inferred from physical position.
  n=notebook_cache.get(r['notebook'])
  if n is None:
   n=json.loads((base/r['notebook']).read_text());notebook_cache[r['notebook']]=n
  src=''.join(n['cells'][r['cell']]['source']);m=re.search(r'\bC(\d{3})\b',src[:500]);tag='NB21C_C'+m.group(1) if m else tag
  if isinstance(v.get('report'),dict) and 'file_bytes_sha256' in v['report']:
   pins[tag]=v['report'];summaries[tag]={'status':v.get('status'),'outputs':v.get('outputs',{}),'source_notebook':r['notebook'],'physical_cell_index':r['cell']}
 if name.startswith('22_'):
  n=notebook_cache.get(r['notebook'])
  if n is None:
   n=json.loads((base/r['notebook']).read_text());notebook_cache[r['notebook']]=n
  src=''.join(n['cells'][r['cell']]['source']);m=re.search(r'NB22-C(\d{3})',src[:500]);tag='NB22_C'+m.group(1) if m else ''
  if tag and isinstance(v.get('output'),dict):pins[tag]=v['output'];summaries[tag]={'status':v.get('status'),'source_notebook':r['notebook'],'physical_cell_index':r['cell']}
# only directly required historical reports; no recursive broad scan
wanted=['NB22_C046','NB22_C047','NB22_C054','NB22_C056','NB22_C057','NB22_C058','NB21C_C018','NB21C_C040','NB21C_C063','NB21C_C068','NB21C_C069','NB21C_C070','NB21C_C078','NB21C_C081','NB21C_C082','NB21C_C085']
sel={k:pins[k] for k in wanted if k in pins}
# C018 finalizer prints a summary without report descriptor; recover its exact literal pin from later producer source only when needed.
print('selected pins',list(sel))
# Contract pin appears explicitly in verified C081 producer.
sel['NB21C_C025']={'path':'reports/phase2/evaluation/NB21C.C025.action12_contract/C025.execution_contract.edc54bb349c632e3424aceb8da881d124d681786bf0f384be0dffdfca0ae2a6b.json','file_bytes_sha256':'edc54bb349c632e3424aceb8da881d124d681786bf0f384be0dffdfca0ae2a6b'}
sel['NB21C_PRIMARY']={'path':'reports/phase2/evaluation/NB21C.C032.offline_safety_readiness/C032.primary_inputs.33df71c9c361ab6a2772fd074f3346bb63e8fcb14a7d6627fa653aaa4f6c6e6a.jsonl','file_bytes_sha256':'33df71c9c361ab6a2772fd074f3346bb63e8fcb14a7d6627fa653aaa4f6c6e6a'}
for record in objs:
 value=record['value']
 if value.get('status')=='QUALITY_EVIDENCE_RECONCILED_PRIOR_NONACCEPTANCE_PRESERVED':
  sel['NB22_C054']=value['supplement'];sel['NB22_C054_HANDOFF']=value['supplemented_handoff']
pathlib.Path('notebook_build/pins.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2))
# The full checklist is the specification; embed every action and subtask verbatim.
md=pathlib.Path('deliverables/NB22B_quality_improvement_checklist_fa.md').read_text();actions=[]
for m in re.finditer(r'### ☐ اقدام (\d+) — (.+?)\n(.*?)(?=\n### ☐ اقدام |\n## بسته|\n## معیارها|\Z)',md,re.S):
 num,title,body=m.groups();subs=[]
 for s in re.finditer(r'^- \[ \] (\d+\.\d+)\. (.+)$',body,re.M):subs.append({'id':s.group(1),'text':s.group(2)})
 actions.append({'number':int(num),'title':title,'markdown':body.strip(),'subtasks':subs})
assert len(actions)==14 and sum(len(a['subtasks']) for a in actions)==64
pathlib.Path('notebook_build/actions.json').write_text(json.dumps(actions,ensure_ascii=False,indent=2))
# Embed the frozen context in documentation only, never substitute it for hash-verified disk input.
ctx=next(r['value'] for r in objs if r['notebook'].endswith('22_release_and_reproducibility.ipynb') and r['value'].get('status')=='EXACT_BLOCKED_DECISIONS_AND_CONTRACT_CONNECTED')
pathlib.Path('notebook_build/review_context.json').write_text(json.dumps({k:ctx[k] for k in ['blocked_metric_entries','contract','recorded_gate_status_counts']},ensure_ascii=False,indent=2))
