# NB22B-C009 — Action 6: paired Development selection and source-component uncertainty.
def source_components(dev):
    parent = {q: q for q in dev['ids']}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x
    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[max(a, b)] = min(a, b)
    seen = {}
    for qid in dev['ids']:
        # Exact C070 graph: queries sharing any reference chunk source_id are connected.
        keys = set()
        for cid in dev['gold'][qid]:
            source_id = dev['chunks'][cid].get('source_id')
            need(isinstance(source_id,str) and bool(source_id.strip()), 'REFERENCE_SOURCE_ID_REQUIRED')
            keys.add(source_id)
        need(bool(keys), 'REFERENCE_PROVENANCE_COMPONENT_UNRESOLVED')
        for key in keys:
            if key in seen: union(qid, seen[key])
            else: seen[key] = qid
    return {q: find(q) for q in dev['ids']}


def paired_uncertainty(dev, candidate, scope='DEVELOPMENT_SELECTION_EXPLORATORY_NOT_INDEPENDENT_FINAL_EVIDENCE'):
    groups = collections.defaultdict(list)
    for q, component in source_components(dev).items():
        groups[component].append(q)
    if len(groups) < CONFIG['minimum_source_components']:
        return {'status': 'NOT_ESTIMATED_INSUFFICIENT_SOURCE_COMPONENTS', 'component_count': len(groups),
                'required_components': CONFIG['minimum_source_components'], 'intervals': None}
    try:
        import numpy as np
    except ImportError:
        return {'status': 'NOT_ESTIMATED_NUMPY_UNAVAILABLE', 'component_count': len(groups), 'intervals': None}
    names = sorted(next(iter(dev['baseline'].values())))
    ordered = [groups[k] for k in sorted(groups)]
    sizes = np.asarray([len(qs) for qs in ordered], dtype=np.float64)
    sums = np.asarray([[math.fsum(candidate[q][name] - dev['baseline'][q][name] for q in qs)
                        for name in names] for qs in ordered], dtype=np.float64)
    rng = np.random.default_rng(CONFIG['bootstrap_seed'])
    values = np.empty((CONFIG['bootstrap_repetitions'], len(names)), dtype=np.float64)
    for start in range(0, len(values), 128):
        stop = min(start + 128, len(values))
        chosen = rng.integers(0, len(ordered), size=(stop - start, len(ordered)))
        values[start:stop] = sums[chosen].sum(axis=1) / sizes[chosen].sum(axis=1)[:, None]
    limits = np.quantile(values, [0.025, 0.975], axis=0, method='linear')
    return {'status': 'PAIRED_SOURCE_COMPONENT_BOOTSTRAP_COMPUTED', 'component_count': len(groups),
            'repetitions': len(values), 'seed': CONFIG['bootstrap_seed'], 'confidence': 0.95,
            'scope': scope,
            'familywise_significance_claimed': False,
            'intervals': {name: {'lower': float(limits[0, i]), 'upper': float(limits[1, i])}
                          for i, name in enumerate(names)}}


def action06():
    need('variant_metrics' in S['memory'], 'ACTION05_COMPLETED_VARIANTS_REQUIRED')
    dev = S['memory']['dev']; base = means(list(dev['baseline'].values())); comparisons = []
    for name, values in S['memory']['variant_metrics'].items():
        observed = means(list(values.values()))
        delta = {k: observed[k] - base[k] for k in base}
        eligible = delta['recall_at_10'] >= -1e-12 and delta['hit_at_10'] >= -1e-12
        comparisons.append({'variant': name, 'metrics': observed, 'delta': delta, 'query_count': len(values),
                            'excluded_queries': 0, 'eligible_by_frozen_point_selection_rule': eligible})
    eligible = [r for r in comparisons if r['eligible_by_frozen_point_selection_rule']
                and r['delta']['ndcg_at_10'] > 1e-12]
    best = sorted(eligible, key=lambda r: (-r['metrics']['ndcg_at_10'], r['variant']))[0] if eligible else None
    name = best['variant'] if best else 'baseline_reranker50'
    scores = S['memory']['variant_metrics'][name] if best else dev['baseline']
    uncertainty = paired_uncertainty(dev, scores)
    freeze = {'schema_version': 'NB22B_DEVELOPMENT_SELECTION_FREEZE_V1', 'selected_variant': name,
              'selection_scope': 'DEVELOPMENT_ONLY', 'plan': S['memory']['plan_receipt'],
              'candidate_artifact': S['memory']['variant_receipt'],
              'selected_development_metrics': means(list(scores.values())),
              'baseline_metrics': base, 'uncertainty': uncertainty,
              'independent_quality_acceptance': False,
              'downstream_context_answers_and_policy_not_automatically_rebound': True}
    receipt = save_json('A06.selected_candidate_freeze', freeze)
    S['memory']['selection'] = freeze; S['memory']['selection_receipt'] = receipt
    return {'status': 'DEVELOPMENT_HYPOTHESIS_SELECTED' if best else 'NO_IMPROVING_VARIANT_BASELINE_RETAINED',
            'comparisons': comparisons, 'selected': freeze, 'freeze': receipt,
            'subtasks': [subtask('6.1', 'COMPLETE', 'Paired same-query, same-Gold comparison; no dropped questions.'),
                         subtask('6.2', 'COMPLETE_IN_SCOPE', 'Ranking quality and pool coverage reported; local reranking time is not generator latency.'),
                         subtask('6.3', 'COMPLETE_IN_SCOPE', 'Source-component uncertainty qualification applied; selection intervals are exploratory.'),
                         subtask('6.4', 'COMPLETE', 'One bounded experiment closed with selection or a preserved negative result.', [receipt])]}
A06 = run_action(6, action06)
