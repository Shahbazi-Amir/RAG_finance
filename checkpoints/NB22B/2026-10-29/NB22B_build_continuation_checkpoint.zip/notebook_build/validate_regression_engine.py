import pathlib,json,os,tempfile,contextlib,io
checks=[]
def ok(label,value):
 assert value,label;checks.append({'check':label,'status':'PASS'})
with tempfile.TemporaryDirectory(prefix='nb22b-regression-') as tmp:
 root=pathlib.Path(tmp);os.environ['RAG_FINANCE_ROOT']=str(root)
 (root/'notebooks/phase2').mkdir(parents=True)
 p=root/'data/Road_Maps/RAG_finance_phase2_modular_notebooks_execution_plan.md';p.parent.mkdir(parents=True);p.write_text('fixture')
 ns={};exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns);ns['PINNED_INPUTS']={};ns['CHECKLIST']=[]
 with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
 exec(pathlib.Path('notebook_build/03_helpers.py').read_text(),ns);exec(pathlib.Path('notebook_build/regression_engine.py').read_text(),ns)
 kinds=['FIXED_QUERY_RETRIEVAL_REGRESSION','EVALUATION_ACCOUNTING_REGRESSION','UNDETERMINED_DECISION_PRESERVATION',
        'DISPUTE_PRESERVATION_AND_REVIEW','SOURCE_BOUND_ANSWER_DECISION_REGRESSION','CITATION_WITNESS_RECORDING_REGRESSION']
 packets={};specs=[];retrieval=[];states={}
 for i in range(322):
  q=f'q{i:03d}';kind=kinds[i%len(kinds)];packets[q]={'response_document_sha256':'a'*64}
  specs.append({'regression_spec_id':f'REG_{i:03d}','candidate_id':q,'kind':kind,
                'frozen_response_document_sha256':'a'*64,'repair_target_hit_at_10':1})
  retrieval.append({'candidate_id':q,'variant':{'hit_at_10':i%2}})
  states[q]={'candidate_id':q,'status':'LOCALLY_VALID_MODEL_GAP_REVIEW','result':{
             'citation_links':[{'support':'UNDETERMINED','intended_location':'UNDETERMINED'}]}}
 ns['semantic_packets']=lambda:packets
 receipt=ns['save_rows']('fixture_retrieval',retrieval)
 ns['S']['memory'].update(regression_specs=specs,gap_review_states=states,
         historical_selected_evaluation={'per_query_results':receipt,'selected_variant':'FIXTURE_FROZEN'})
 result=ns['execute_regression_suite']();rows=ns['read_bound'](result['results'],jsonl=True)
 ok('all322_native_specifications_mapped',len(rows)==322 and len({r['regression_spec_id'] for r in rows})==322)
 ok('retrieval_assertion_actually_executed',any(r['status']=='FAIL' and r['kind']==kinds[0] for r in rows))
 ok('accounting_pass_not_semantic_fix',all(not r['semantic_fix_claimed'] for r in rows))
 ok('undetermined_link_recording_not_semantic_pass',any(r['status']=='PASS_MODEL_SCOPE_RECORDING_ONLY' and r['undetermined_link_count']==1 for r in rows))
 ok('no_false_all322_product_pass',result['all322_semantic_product_tests_passed'] is False)
 specs[0]['frozen_response_document_sha256']='b'*64
 mismatch=ns['execute_regression_suite']();altered=ns['read_bound'](mismatch['results'],jsonl=True)[0]
 ok('response_scope_mismatch_not_rebound',altered['status']=='BLOCKED' and altered['reason']=='FROZEN_RESPONSE_SCOPE_DIFFERS_NO_AUTOMATIC_REBINDING')
report={'status':'PASS','schema_version':'NB22B_NATIVE_REGRESSION_ADAPTER_SYNTHETIC_VALIDATION_V1','checks':checks,
        'actual_project322_specifications_rerun_here':False,'real_provider_requests':0}
pathlib.Path('deliverables/NB22B_regression_engine_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report))
