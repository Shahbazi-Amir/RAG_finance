# NB18 -> NB19 bridge for a bounded Development pilot, never a new Test/holdout.
CONTEXT_PACKET_BINDING={'path':'data/phase2/context/context_builder_v1/context_packets_v1.jsonl',
 'file_bytes_sha256':'7789bdb8907d0de803b32a274c996cf04bc68be8414bbadce5ef6989d2dc7edc'}
CONTEXT_REGISTRY_BINDING={'path':'data/phase2/context/context_builder_v1/context_evidence_registry_v1.jsonl',
 'file_bytes_sha256':'730aad40c0dac5c94d702f0a22aa3a891045f458a445abd087f34303bebe9fe2'}
CONTEXT_CONFIGURATION_CANONICAL_SHA256='f600583bba6646022c3eaf455e204a38a6c6f5bd3fe8aae8621be8d5d35a5835'


def nb18_configuration():
    relative='artifacts/phase2/context_builder/context_builder_configuration_v1.json'
    path=project_path(relative);need(path.is_file(),'NB18_CANONICAL_CONFIGURATION_NOT_AT_DECLARED_PATH')
    raw=path.read_bytes()
    try:value=_boot_decode(raw)
    except (ValueError,UnicodeError) as error:raise EvidenceGap('NB18_CONFIGURATION_JSON_INVALID') from error
    need(sha(canonical(value))==CONTEXT_CONFIGURATION_CANONICAL_SHA256,'NB18_CONFIGURATION_CANONICAL_HASH_CONFLICT')
    policy=value['selection_policy']
    need(policy['selection_order']=='reranker_order' and policy['source_cap_per_source_id']==8
         and policy['document_cap_per_member_document_id']==5 and value['token_budget']['tokens']==7371,
         'NB18_CONTEXT_SELECTION_CONTRACT_CHANGED')
    return value,{'path':relative,'file_bytes_sha256':sha(raw),'producer_canonical_json_sha256':CONTEXT_CONFIGURATION_CANONICAL_SHA256,
                  'file_byte_hash_equated_with_canonical_hash':False}


def pinned_context_token_counter(configuration,registry,chunks):
    known={}
    for eid,row in registry.items():
        need(eid==row['chunk_id'],'NB18_REGISTRY_EVIDENCE_CHUNK_ID_CONFLICT')
        need(row['content_sha256']==sha(row['content'].encode()),'NB18_REGISTRY_CONTENT_HASH_CONFLICT')
        n=row.get('token_count');need(type(n) is int and n>=0,'NB18_REGISTRY_TOKEN_COUNT_INVALID')
        known[eid]=(row['content_sha256'],n)
    loaded=[]
    def count(cid):
        content=chunks[cid]['content'];digest=sha(content.encode())
        if cid in known:
            need(known[cid][0]==digest,'NB18_REUSED_TOKEN_COUNT_TEXT_VERSION_CONFLICT')
            return known[cid][1]
        if not loaded:
            spec=configuration['token_budget']['tokenizer'];model_id=spec['repository']
            cache=Path(os.environ.get('HF_HUB_CACHE') or str(Path(os.environ.get('HF_HOME',str(Path.home()/'.cache/huggingface')))/'hub'))
            folder=cache/('models--'+model_id.replace('/','--'))/'snapshots'
            need(folder.is_dir(),'NB18_TOKENIZER_LOCAL_CACHE_NOT_AVAILABLE')
            try:from transformers import AutoTokenizer
            except ImportError as error:raise EvidenceGap('NB18_TOKENIZER_DEPENDENCY_UNAVAILABLE') from error
            failures=[]
            for snapshot in sorted(folder.iterdir()):
                if not snapshot.is_dir():continue
                try:
                    tokenizer=AutoTokenizer.from_pretrained(str(snapshot),local_files_only=True,trust_remote_code=False,use_fast=True)
                    if sha(tokenizer.backend_tokenizer.to_str().encode())!=spec['backend_sha256']:continue
                    if sha(canonical(tokenizer.special_tokens_map))!=spec['special_tokens_sha256']:continue
                    loaded.append(tokenizer);break
                except Exception as error:failures.append(type(error).__name__)
            need(bool(loaded),'NO_LOCALLY_CACHED_TOKENIZER_MATCHES_NB18_CONTENT_FINGERPRINT')
        value=len(loaded[0].encode(content,add_special_tokens=False));known[cid]=(digest,value)
        return value
    return count


def pack_nb18_selected_order(order,chunks,count_tokens,source_cap=8,document_cap=5,budget=7371):
    # Exact final NB18 contract: consider Top10 first; skipped items are not backfilled from rank11+.
    selected=[];used=0;sources=collections.Counter();documents=collections.Counter();dropped=collections.Counter()
    need(len(order)==len(set(order)),'DUPLICATE_CONTEXT_RANKED_CHUNK')
    for rank,cid in enumerate(order[:10],1):
        need(cid in chunks,'SELECTED_CONTEXT_CHUNK_MISSING')
        chunk=chunks[cid];source=chunk.get('source_id');members=list(chunk.get('member_document_ids') or [])
        need(isinstance(source,str) and source and len(members)==len(set(members)),'CONTEXT_SOURCE_OR_DOCUMENT_MEMBERSHIP')
        if sources[source]>=source_cap:dropped['source_cap']+=1;continue
        if any(documents[d]>=document_cap for d in members):dropped['document_cap']+=1;continue
        n=count_tokens(cid);need(type(n) is int and n>=0,'CONTEXT_TOKEN_COUNTER_RESULT')
        if used+n>budget:dropped['evidence_text_budget']+=1;continue
        selected.append({'evidence_id':cid,'text':chunk['content'],'selected_rank':rank,'token_count':n})
        used+=n;sources[source]+=1
        for d in members:documents[d]+=1
    need(bool(selected),'EMPTY_SELECTED_CONTEXT_PRESERVED_AS_BLOCKER')
    need(used<=budget,'SELECTED_CONTEXT_BUDGET_VIOLATION')
    return {'items':selected,'tokens':used,'dropped_reason_counts':dict(dropped)}


def prepare_development_generation_pilot():
    need('dev' in S['memory'] and 'selection' in S['memory'],'FROZEN_DEVELOPMENT_SELECTION_REQUIRED_FOR_CONTEXT_BRIDGE')
    dev=S['memory']['dev'];selection=S['memory']['selection'];variant=selection['selected_variant']
    packets=unique(read_bound(CONTEXT_PACKET_BINDING,jsonl=True),'candidate_id')
    registry=unique(read_bound(CONTEXT_REGISTRY_BINDING,jsonl=True),'evidence_id')
    limit=CONFIG['development_generation_pilot_cases']
    need(type(limit) is int and 1<=limit<=64,'BOUNDED_DEVELOPMENT_PILOT_SIZE_REQUIRED')
    ids=sorted(dev['ids'],key=lambda q:(dev['baseline'][q]['recall_at_10'],dev['baseline'][q]['ndcg_at_10'],q))[:limit]
    need(all(q in packets and packets[q]['split']=='development' for q in ids),'DEV_PILOT_MUST_NOT_CONSUME_TEST_PACKETS')
    configuration=configuration_receipt=None;counter=None
    if variant!='baseline_reranker50':
        configuration,configuration_receipt=nb18_configuration()
        counter=pinned_context_token_counter(configuration,registry,dev['chunks'])
    rows=[];requests=[];changed=0
    for q in ids:
        old=packets[q]
        need(old['configuration_sha256']==CONTEXT_CONFIGURATION_CANONICAL_SHA256,'NB18_PACKET_CONFIGURATION_CONFLICT')
        refs=[r['evidence_id'] for r in old['evidence_refs']]
        need(len(refs)==len(set(refs)) and all(e in registry for e in refs),'NB18_PACKET_REFERENCE_INTEGRITY')
        if variant=='baseline_reranker50':
            evidence=[{'evidence_id':eid,'text':registry[eid]['content']} for eid in refs]
            provenance='REUSED_IDENTICAL_HASH_BOUND_NB18_CONTEXT'
        else:
            order=S['memory']['variants'][variant][q]
            packed=pack_nb18_selected_order(order,dev['chunks'],counter)
            evidence=[{'evidence_id':r['evidence_id'],'text':r['text']} for r in packed['items']]
            provenance='NB18_POLICY_REPLAY_ON_FROZEN_SELECTED_RANK_ORDER'
        need(all(sha(e['text'].encode())==registry[e['evidence_id']]['content_sha256']
                 for e in evidence if e['evidence_id'] in registry),'SELECTED_CONTEXT_TEXT_VERSION_CONFLICT')
        changed+=([e['evidence_id'] for e in evidence]!=refs)
        payload={'question':dev['questions'][q],'evidence':evidence,'response_schema':PRODUCT_RESPONSE_SCHEMA}
        request={'model':'Qwen3-30B-A3B','max_tokens':3072,
                 'messages':[{'role':'system','content':NB19_PRODUCT_SYSTEM},{'role':'user','content':canonical(payload).decode()}]}
        requests.append({'candidate_id':q,'request':request,'request_sha256':sha(canonical(request))})
        rows.append({'candidate_id':q,'split':'development','question':dev['questions'][q],
                     'evidence':evidence,'selected_retrieval_variant':variant,'context_provenance':provenance,
                     'model_response_or_reference_labels_included':False})
    population=save_rows('A11.development_generation_pilot_inputs',rows)
    request_receipt=save_rows('A11.development_generation_pilot_request_drafts',requests)
    byte_count=sum(len(canonical(r['request'])) for r in requests)
    plan={'schema_version':'NB22B_DEVELOPMENT_GENERATION_PILOT_PLAN_V1','case_count':len(ids),
          'population':population,'request_drafts':request_receipt,'selection_freeze':S['memory']['selection_receipt'],
          'context_packets_binding':CONTEXT_PACKET_BINDING,'context_registry_binding':CONTEXT_REGISTRY_BINDING,
          'nb18_configuration_receipt':configuration_receipt,'changed_context_count':changed,
          'cohort_selection':'LOWEST_DEVELOPMENT_BASELINE_RECALL_THEN_NDCG_THEN_ID','test_used_for_selection':False,
          'prompt_template_sha256':sha(NB19_PRODUCT_SYSTEM.encode()),'proposed_model_from_nb19':'Qwen3-30B-A3B',
          'input_request_bytes':byte_count,'output_cap_per_request':3072,
          'historical_tariff_planning_reserve_toman':byte_count*61250/1e6+len(ids)*3072*183750/1e6,
          'historical_tariff_source':'NB19_C217_USER_CONFIRMED_PRIOR_PROVIDER_PANEL_RATE_NEW_GATEWAY_UNVERIFIED',
          'current_tariff_or_invoice_verified':False,'live_route_identity_verified':False,
          'paid_execution_authorized':False,'historical_semantic_judge_budget_reused':False,
          'unbound_requirements':['Verify the current generator profile/route and tariff.',
                                  'Bind the product policy and a compatible response baseline.',
                                  'Approve the exact generation plan and its separate budget before dispatch.'],
          'new_api_calls':0,'independent_product_holdout_claimed':False}
    receipt=save_json('A11.development_generation_pilot_plan',plan)
    S['memory']['development_generation_pilot_plan']=plan
    return {'plan':plan,'plan_receipt':receipt}
