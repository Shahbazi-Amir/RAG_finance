# NB22B-C017 — Action 14: independently reload generated evidence and record actual acceptance.
def independent_reload(receipts):
    request = {'root': str(ROOT), 'files': [{'path': r['path'], 'file_bytes_sha256': r['file_bytes_sha256']}
                                         for r in receipts]}
    program = r'''
import sys,json,pathlib,hashlib,socket
req=json.load(sys.stdin); root=pathlib.Path(req['root']).resolve(); seen=set(); verified=0
# Defense in depth: child validation has no permitted network work.
def blocked(*args, **kwargs): raise RuntimeError('NETWORK_NOT_PERMITTED_IN_RELOAD')
socket.create_connection=blocked
for r in req['files']:
 rel=pathlib.Path(r['path']); p=(root/rel).resolve()
 if rel.is_absolute() or '..' in rel.parts or not p.is_relative_to(root) or str(rel) in seen:
  raise RuntimeError('INVALID_RELOAD_INVENTORY')
 seen.add(str(rel)); h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
 if h.hexdigest()!=r['file_bytes_sha256']: raise RuntimeError('RELOAD_HASH_CONFLICT')
 verified+=1
print(json.dumps({'status':'INDEPENDENT_DERIVATIVE_RELOAD_PASS','files_verified':verified,
                  'network_calls':0,'models_or_notebooks_executed':False}))
'''
    process = subprocess.run([sys.executable, '-I', '-c', program], input=json.dumps(request),
                             text=True, capture_output=True, timeout=300, check=False)
    need(process.returncode == 0, 'INDEPENDENT_DERIVATIVE_RELOAD_FAILED')
    return _boot_decode(process.stdout)


def action14():
    # The final decision must remain available even when an earlier consumer had a prerequisite gap.
    policy = S['memory'].get('policy')
    context = S['inputs'].get('NB22_C057')
    names = sorted(context['contract']['metric_policy']) if context else []
    comparison = S['memory'].get('historical_selected_evaluation', {})
    semantic = S['memory'].get('gap_measurements', {})
    abstention = S['memory'].get('abstention_measurement', {})
    scoped_checks = []
    for key, check in comparison.get('absolute_threshold_checks', {}).items():
        scoped_checks.append({'metric': key, 'scope': 'FROZEN_SELECTED_RETRIEVAL_HISTORICAL_TEST',
                              'status': check['absolute_status'], **check})
    for key in ('citation_correctness', 'citation_locator_accuracy'):
        bound = semantic.get(key, {})
        lower, upper = bound.get('lower_bound'), bound.get('upper_bound')
        status = ('PASS' if lower is not None and lower >= .95 else
                  'FAIL' if upper is not None and upper < .95 else 'BLOCKED')
        scoped_checks.append({'metric': key, 'scope': 'HISTORICAL_RESPONSE_MODEL_GAP_REVIEW',
                              'status': status, 'threshold': .95, 'measurement': bound,
                              'independent_product_acceptance_claimed': False})
    f1 = abstention.get('f1')
    scoped_checks.append({'metric': 'no_answer_precision_recall_f1',
                          'scope': 'HISTORICAL_CONDITIONAL_MODEL_REFERENCE',
                          'status': 'PASS' if f1 is not None and f1 >= .85 else 'FAIL' if f1 is not None else 'BLOCKED',
                          'value': f1, 'threshold': .85,
                          'evaluated_cases': abstention.get('evaluated_case_count')})
    gates = []
    historical_checks = {x['metric']: x for x in scoped_checks}
    for name in names:
        key = {'recall_at_k': 'recall_at_10', 'ndcg_at_k_binary': 'ndcg_at_10'}.get(name, name)
        observed = historical_checks.get(key)
        status = 'FAIL' if observed and observed['status'] == 'FAIL' else 'BLOCKED'
        family_keys = {'recall_at_k': ['recall_at_5','recall_at_10'],
                       'ndcg_at_k_binary': ['ndcg_at_5','ndcg_at_10'],
                       'hit_at_k': ['hit_at_5','hit_at_10']}.get(name)
        nonregression = comparison.get('paired_nonregression_checks', {})
        relevant = [nonregression.get(k, {'status':'BLOCKED'}) for k in family_keys] if family_keys else []
        if relevant:
            if status == 'FAIL' or any(r['status']=='FAIL' for r in relevant):status='FAIL'
            elif all(r['status']=='PASS' for r in relevant) and (observed is None or observed['status']=='PASS'):status='PASS'
        gates.append({'metric': name, 'candidate_scope': 'FROZEN_SELECTED_RETRIEVAL_HISTORICAL_TEST' if family_keys else 'NEW_SELECTED_PRODUCT_CANDIDATE',
                      'status': status, 'available_scoped_check': observed,
                      'paired_family_nonregression_checks': relevant,
                      'reason': ('Recorded scoped absolute failure; selected product qualification also remains open.'
                                 if status == 'FAIL' else 'Retrieval family absolute and paired non-regression conditions met in the stated historical scope.' if status == 'PASS' else
                                 'Complete product response binding, qualified reference scope and compatible baseline are not established.'),
                      'historical_gate_rewritten': False})
    qualified=S['memory'].get('qualified_product_evaluation')
    closure=S['memory'].get('product_technical_closure')
    if qualified:
        gates=[{'metric':name,'candidate_scope':'VERSION_BOUND_QUALIFIED_PRODUCT_EVALUATION',
                'status':row['status'],'measurement':row,'historical_gate_rewritten':False}
               for name,row in sorted(qualified['metric_results'].items())]
    technical = S['actions'].get('13', {}).get('result', {})
    reload = independent_reload(list(S['artifacts'])) if ROOT is not None else {'status': 'ROOT_NOT_RESOLVED'}
    aggregate_status = ('FAIL' if any(g['status'] == 'FAIL' for g in gates) else
                        'PASS' if len(gates) == 16 and all(g['status'] == 'PASS' for g in gates) else 'BLOCKED')
    gate_conditions = [
        {'gate': 'all16_new_candidate_quality_metrics', 'status': aggregate_status},
        {'gate': 'independent_final_evaluation', 'status': 'PASS' if qualified else 'BLOCKED',
         'reason': 'Qualified, explicitly bound independent product evaluation consumed.' if qualified else 'Independent holdout and selected product response population not established.'},
        {'gate': 'complete_product_technical_closure', 'status': 'PASS' if closure else 'BLOCKED',
         'reason': 'Version-bound policy, source inventory, lock and restore evidence validated.' if closure else 'Producer/policy/environment/dependency requirements remain open.'},
        {'gate': 'current_derivative_integrity',
         'status': 'PASS' if reload.get('status') == 'INDEPENDENT_DERIVATIVE_RELOAD_PASS' else 'BLOCKED'},
    ]
    gate_conditions.append({'gate':'critical_product_cases', 'status':qualified['critical_gate']['status'] if qualified else 'BLOCKED'})
    if CONFIG['release_distribution_scope'] == 'PUBLIC':
        gate_conditions.append({'gate': 'whole_product_public_distribution', 'status': 'NOT_CLEARED'})
    accepted = all(g['status'] == 'PASS' for g in gate_conditions)
    prior = S['inputs'].get('NB22_C047')
    ledger = []
    for spec in CHECKLIST:
        if spec['number'] == 14: continue
        action = S['actions'].get(str(spec['number']))
        if action:
            for item in action['result']['subtasks']:
                ledger.append({**item, 'action': spec['number'], 'action_output': action['output']})
        else:
            ledger.extend({**subtask(x['id'], 'BLOCKED', 'ACTION_NOT_EXECUTED_IN_THIS_RUN'), 'action': spec['number']}
                          for x in spec['subtasks'])
    subtasks = [subtask('14.1', 'COMPLETE_IN_SCOPE', 'Technical, quality and independence conditions consolidated; deferrals remain visible.'),
                subtask('14.2', 'COMPLETE', 'Historical FAIL/BLOCKED and unresolved reasons preserved; thresholds unchanged.'),
                subtask('14.3', 'COMPLETE', 'Accepted/not-accepted computed from actual gates; local checkpoint distinct from public distribution.'),
                subtask('14.4', 'COMPLETE_IN_SCOPE', 'Versioned derivative manifest, independent reload, limitations and handoff saved; old decisions untouched.'),
                subtask('14.5', 'COMPLETE', 'NB23 formal input condition stated; no automatic NB23 implementation.')]
    ledger.extend({**item, 'action': 14} for item in subtasks)
    need(len(ledger) == 64 and len({x['id'] for x in ledger}) == 64, 'FINAL64_SUBTASK_ACCOUNTING_CONFLICT')
    counts = dict(collections.Counter(x['status'] for x in ledger))
    handoff = {'schema_version': 'NB22B_NB23_INPUT_DISPOSITION_V1',
               'release_acceptance_granted': accepted,
               'handoff_mode': 'ACCEPTED_RELEASE' if accepted else 'DRAFT_ONLY_UNACCEPTED_INPUT',
               'selected_development_candidate': S['memory'].get('selection_receipt'),
               'technical_manifest': S['memory'].get('technical_manifest'),
               'historical_parent_handoff': PINNED_INPUTS.get('NB22_C054_HANDOFF'),
               'gate_conditions': gate_conditions, 'prior_health_deferral': CONFIG['health_deferral'],
               'NB23_implementation_performed': False}
    handoff_receipt = save_json('A14.NB23_input_disposition', handoff)
    ledger_receipt = save_json('A14.all64_subtask_statuses', ledger)
    # The evidence index excludes itself and the final report, preventing recursive self-hashes.
    index = save_json('A14.evidence_index', {'schema_version': 'NB22B_EVIDENCE_INDEX_V1',
                        'files': list(S['artifacts']), 'source_inputs': PINNED_INPUTS,
                        'self_reference': False, 'independent_reload': reload})
    lines = ['<div dir="rtl" align="right">', '', '# گزارش اجرای NB22B', '',
             f'- پذیرش Release: {accepted}', f'- شمارش وضعیت۶۴زیرکار: {json.dumps(counts, ensure_ascii=False)}',
             '- گزارش‌گیری کامل به معنی تکمیل همهٔ کارهای پذیرش نیست.',
             f'- آزمایش Development از ارزیابی مستقل محصول جداست؛ Attempt تازهٔ API این اجرا: {S["new_api_calls"]}.',
             '- هلث‌چک‌های قدیمی طبق تصمیم کاربر موکول مانده‌اند.']
    lines.extend(['', '## نتیجهٔ کیفیت در دامنهٔ اندازه‌گیری', '',
                  '| معیار | دامنه | وضعیت | مقدار یا کران |', '| --- | --- | --- | --- |'])
    for check in scoped_checks:
        measured_value=check.get('value',check.get('measurement',{}))
        lines.append(f"| {check['metric']} | {check['scope']} | {check['status']} | {json.dumps(measured_value,ensure_ascii=False).replace('|','/')} |")
    if qualified:
        lines.extend(['', '### ارزیابی مستقلِ متصل به نسخهٔ محصول', '',
                      '| خانوادهٔ معیار | وضعیت | زیرمعیارها |', '| --- | --- | --- |'])
        for name,row in qualified['metric_results'].items():
            values={key:part['value'] for key,part in row['components'].items()}
            lines.append(f"| {name} | {row['status']} | {json.dumps(values,ensure_ascii=False).replace('|','/')} |")
    lines.extend(['', '## دفتر زیرکارها', '', '| زیرکار | وضعیت واقعی | شرح |', '| --- | --- | --- |'])
    for row in ledger:
        lines.append(f"| {row['id']} | {row['status']} | {row['detail'].replace('|', '/')} |")
    lines.extend(['', '## گام بعد', '',
        'خروجی مقایسهٔ اقدام۶ را بررسی کنید. برای پذیرش، اتصال نسخهٔ پاسخ/Policy، مرجع معنایی معتبر، '
        'Runtime و Holdout مستقل باید واقعاً تکمیل و اجرا شوند. این نوت‌بوک این شواهد را جعل نمی‌کند. '
        'وجود وضعیت BLOCKED حکم نبود کار در تمام پروژه نیست؛ فقط دامنهٔ ورودی‌های متصل این اجرا را بیان می‌کند.',
        '', '</div>', ''])
    markdown = atomic_bytes('reports/phase2/quality_improvement/NB22B.v1', 'A14.run_report_fa',
                            '\n'.join(lines).encode('utf-8'), 'md')
    return {'status': 'ACCEPTED' if accepted else 'EXPERIMENT_AND_EVIDENCE_REPORT_COMPLETE_ACCEPTANCE_NOT_ESTABLISHED',
            'release_acceptance_granted': accepted, 'phase2_completion_claimed': False,
            'all_checklist_work_completed': counts.get('COMPLETE', 0) == 64,
            'subtask_status_counts': counts, 'total_model_dispatch_attempts': S['new_api_calls'], 'metric_gates_for_new_candidate': gates,
            'scoped_measured_checks': scoped_checks, 'distribution_scope': CONFIG['release_distribution_scope'],
            'gate_conditions': gate_conditions,
            'historical_gate_status_counts_preserved': context.get('recorded_gate_status_counts') if context else None,
            'independent_reload': reload, 'handoff': handoff_receipt,
            'ledger': ledger_receipt, 'evidence_index': index, 'markdown_report': markdown,
            'subtasks': subtasks}
A14 = run_action(14, action14)
