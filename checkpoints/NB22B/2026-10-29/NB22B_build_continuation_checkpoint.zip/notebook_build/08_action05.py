# NB22B-C008 — Action 5: cached rank fusion and cache-only local depth expansion.
def local_depth100(dev, plan_receipt, maximum_seconds=None):
    call_start=time.monotonic();contract=local_inference_contract()
    folder,cache_bindings,cached=depth100_cache_inputs(dev,contract)
    if len(cached)==len(dev['ids']):
        return complete_depth100_cached_result(dev,cache_bindings,cached,call_start)
    try:
        import numpy as np
        import onnxruntime as ort
        from transformers import AutoTokenizer
    except ImportError as error:
        raise EvidenceGap('LOCAL_RUNTIME_PACKAGE_UNAVAILABLE:' + error.name) from error
    need(ort.__version__ == CONFIG['onnxruntime_version'], 'ONNX_RUNTIME_VERSION_DIFFERS_FROM_PIN')
    cache_root = Path(os.environ.get('HF_HUB_CACHE') or
                      str(Path(os.environ.get('HF_HOME', str(Path.home() / '.cache/huggingface'))) / 'hub'))
    snapshot = cache_root / ('models--' + CONFIG['model_id'].replace('/', '--')) / 'snapshots' / CONFIG['model_revision']
    model = snapshot / 'onnx/model_quint8_avx2.onnx'
    need(model.is_file(), 'PINNED_ONNX_NOT_AVAILABLE_IN_LOCAL_CACHE')
    need(sha(model.read_bytes()) == CONFIG['onnx_sha256'], 'ONNX_MODEL_BYTE_IDENTITY_CONFLICT')
    try:
        tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True, trust_remote_code=False)
        opts = ort.SessionOptions(); opts.intra_op_num_threads = 4; opts.inter_op_num_threads = 1
        opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        session = ort.InferenceSession(str(model), sess_options=opts, providers=['CPUExecutionProvider'])
    except Exception as error:
        # This boundary contains only local third-party cache/runtime initialization.
        raise EvidenceGap('PINNED_LOCAL_RUNTIME_INITIALIZATION_FAILED:'+type(error).__name__) from error
    names = {x.name for x in session.get_inputs()}
    need({'input_ids', 'attention_mask'}.issubset(names), 'ONNX_INPUT_CONTRACT_CHANGED')

    def predict(question, chunk_ids):
        scores = []
        for start in range(0, len(chunk_ids), 4):
            batch = chunk_ids[start:start + 4]
            encoded = tokenizer([question] * len(batch), [dev['chunks'][c]['content'] for c in batch],
                                padding=True, truncation=True, max_length=512, return_tensors='np')
            feed = {name: np.asarray(encoded[name], dtype=np.int64) for name in names if name in encoded}
            need(set(feed) == names, 'TOKENIZER_ONNX_INPUT_MISMATCH')
            values = np.asarray(session.run(None, feed)[0], dtype=np.float64).reshape(-1)
            need(values.shape == (len(batch),) and bool(np.isfinite(values).all()), 'INVALID_LOCAL_ONNX_SCORES')
            scores.extend(float(v) for v in values)
        return scores

    # Verify compatibility on deterministic reused pairs; do not silently mix runtimes.
    sample_id = dev['ids'][0]
    sample_map = {x['chunk_id']: x for x in dev['reranker'][sample_id]['candidates']}
    sample = [sample_map[x['chunk_id']] for x in dev['hybrid'][sample_id]['candidates'][:4]]
    observed = predict(dev['questions'][sample_id], [x['chunk_id'] for x in sample])
    delta = max(abs(a - float(b['reranker_score'])) for a, b in zip(observed, sample))
    need(delta <= 1e-4, 'LOCAL_RUNTIME_SCORE_PARITY_NOT_ESTABLISHED')
    plan_id = plan_receipt['file_bytes_sha256']
    guard_value={'schema_version':'NB22B_LOCAL_RUNTIME_PARITY_V2',
        'inference_contract_sha256':contract['sha256'],'model_sha256':CONFIG['onnx_sha256'],
        'sample_candidate_id':sample_id,'sample_score_max_delta':delta,'sample_pair_count':len(sample),
        'comparison_scope':'DETERMINISTIC_FIRST4_HYBRID_PAIRS_ONLY_NOT_FULL_MODEL_INTEGRITY',
        'environment':{'python':platform.python_version(),'system':platform.system(),'machine':platform.machine()},
        'producer_code_source_sha256':SOURCE_CODE_SHA256,'onnxruntime_version':ort.__version__}
    guard=atomic_bytes(folder.relative_to(ROOT).as_posix(),'runtime_validation',canonical(guard_value),'json')
    folder.mkdir(parents=True, exist_ok=True)
    orders = {}; receipts = []; held = []; new_pairs = 0; reused = 0
    limit_seconds = CONFIG['maximum_local_seconds'] if maximum_seconds is None else maximum_seconds
    need(type(limit_seconds) in (int,float) and 0<limit_seconds<=CONFIG['maximum_local_seconds'],'LOCAL_COMPUTE_TIME_BUDGET_NOT_AVAILABLE')
    start = call_start; last_progress = time.monotonic()
    # Local deterministic inference may be resumed. This is not a paid request/attempt ledger.
    for qid in dev['ids']:
        ho = rank_ids(dev['hybrid'][qid], 100)
        old_scores = {x['chunk_id']: float(x['reranker_score']) for x in dev['reranker'][qid]['candidates']}
        missing = [cid for cid in ho if cid not in old_scores]
        identity=cache_bindings[qid]['identity'];path=cache_bindings[qid]['path']
        if qid in cached:
            record=cached[qid];scores=record['scores'];reused+=1
        else:
            if time.monotonic()-start>=limit_seconds:
                held.extend({'candidate_id':q,'reason':'LOCAL_TIME_CAP_NOT_SCORED'} for q in dev['ids'] if q not in orders)
                break
            scores=predict(dev['questions'][qid],missing)
            record={'identity':identity,'scores':scores,'score_values_sha256':sha(canonical(scores)),
                    'runtime_validation_receipt':guard,'origin_experiment_plan_sha256':plan_id,
                    'score_origin':'LOCAL_ONNX_CPU_ONLY','paid_api_calls':0}
            raw=canonical(record)
            fd,name=tempfile.mkstemp(dir=str(folder),prefix='.local-score-')
            try:
                with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
                try:os.link(name,path)
                except FileExistsError:
                    other=validate_local_score_record(_boot_decode(path.read_bytes()),identity,contract)
                    need(other['scores']==scores,'LOCAL_SCORE_CONCURRENT_CONFLICT');record=other
            finally:Path(name).unlink(missing_ok=True)
            saved,stat_key=local_cache_stable_read(path)
            need(_boot_decode(saved)==record,'LOCAL_SCORE_RELOAD_FAILED')
            cache_bindings[qid].update(file_bytes_sha256=sha(saved),stat=stat_key)
            new_pairs+=len(missing)
        combined = {**old_scores, **dict(zip(missing, scores))}
        need(set(combined) == set(ho), 'DEPTH100_SCORE_POPULATION_CONFLICT')
        orders[qid] = sorted(ho, key=lambda c: (-combined[c], c))
        receipts.append(local_cache_receipt(cache_bindings[qid]))
        if time.monotonic() - last_progress >= 20 or len(orders) == len(dev['ids']):
            print(json.dumps({'stage': 'LOCAL_DEPTH100_PROGRESS', 'completed': len(orders),
                              'total': len(dev['ids']), 'new_pairs': new_pairs,
                              'cache_queries_reused': reused, 'elapsed_minutes': round((time.monotonic()-start)/60, 2),
                              'model_api_calls': 0}), flush=True)
            last_progress = time.monotonic()
    guards={r['runtime_validation_receipt']['path']:r['runtime_validation_receipt'] for r in cached.values()}
    guards[guard['path']]=guard
    return {'orders': orders, 'held': held, 'runtime_validation_receipts':list(guards.values()), 'new_pairs': new_pairs, 'cache_queries_reused': reused,
            'score_cache_receipts': receipts, 'sample_score_max_delta': delta,
            'complete': len(orders) == len(dev['ids']), 'elapsed_seconds': time.monotonic() - start,
            'model_loaded_this_call':True,'cache_reuse_before_runtime_initialization':False}


def action05():
    need('experiment_plan' in S['memory'] and 'dev' in S['memory'], 'FROZEN_PLAN_AND_INPUTS_REQUIRED')
    dev = S['memory']['dev']; variants = {}; execution = []
    for k in CONFIG['rrf_constants']:
        for weight in CONFIG['rrf_weights']:
            name = f'cached_rrf_k{k}_w{weight:.2f}'
            orders = {}
            for qid in dev['ids']:
                row = dev['reranker'][qid]
                hr = {c['chunk_id']: c['rank'] for c in dev['hybrid'][qid]['candidates']}
                rr = {c['chunk_id']: c['rank'] for c in row['candidates']}
                orders[qid] = sorted(rr, key=lambda cid: (-(weight/(k+rr[cid]) + (1-weight)/(k+hr[cid])), cid))
            variants[name] = orders
    local = None
    if CONFIG['execute_local_depth100']:
        try:
            local = local_depth100(dev, S['memory']['plan_receipt'])
            if local['complete']:
                variants['local_onnx_depth100'] = local['orders']
            execution.append({'variant': 'local_onnx_depth100', 'status': 'COMPLETE' if local['complete'] else 'PARTIAL_NOT_ELIGIBLE_FOR_SELECTION',
                              'new_local_pairs': local['new_pairs'], 'reused_cache_queries': local['cache_queries_reused'],
                              'held_queries': len(local['held']), 'sample_score_max_delta': local['sample_score_max_delta']})
        except Exception as error:
            # A missing or incompatible local runtime does not invalidate cached-rank experiments.
            execution.append({'variant': 'local_onnx_depth100', 'status': 'BLOCKED_LOCAL_RUNTIME',
                              'reason': str(error) if isinstance(error, EvidenceGap) else type(error).__name__,
                              'runtime_error_is_not_a_pass': True})
    else:
        execution.append({'variant': 'local_onnx_depth100', 'status': 'DISABLED_IN_EXPLICIT_RUN_CONFIG'})
    cache_inventory=register_local_score_assets(local,S['memory']['plan_receipt'],'A05.local_score_cache_inventory') if local is not None else None
    metrics = {}; rows = []
    for name, orders in variants.items():
        need(set(orders) == set(dev['ids']), 'VARIANT_QUERY_POPULATION_MISMATCH')
        metrics[name] = {}
        for qid in dev['ids']:
            allowed = set(rank_ids(dev['hybrid'][qid], 100))
            need(set(orders[qid]).issubset(allowed), 'VARIANT_OUTSIDE_FROZEN_POOL')
            values = metric(orders[qid][:50], dev['gold'][qid]); metrics[name][qid] = values
            rows.append({'variant': name, 'candidate_id': qid, 'split': 'development',
                         'ranked_chunk_ids': orders[qid], 'metrics': values})
    receipt = save_rows('A05.development_variants', rows)
    S['memory']['variants'] = variants; S['memory']['variant_metrics'] = metrics
    S['memory']['local_development_elapsed_seconds'] = local['elapsed_seconds'] if local is not None else 0
    S['memory']['variant_receipt'] = receipt
    local_complete = local is not None and local['complete']
    return {'status': 'CACHED_EXPERIMENTS_EXECUTED_WITH_EXPLICIT_LOCAL_RUNTIME_STATUS',
            'variant_count': len(variants), 'development_query_count_per_variant': len(dev['ids']),
            'results': receipt, 'local_execution': execution,'local_score_cache_inventory':cache_inventory,
            'reciprocal_rank_metric_scope': 'COMMON_STORED_TOP50', 'same_baseline_files_preserved': True, 'new_paid_requests': 0,
            'subtasks': [subtask('5.1', 'COMPLETE_IN_SCOPE', 'All cached-score variants executed; successful local score cache reused when available.'),
                         subtask('5.2', 'COMPLETE_IN_SCOPE' if local_complete else 'BLOCKED',
                                 'NB17 derivative is versioned; depth100 complete.' if local_complete else
                                 'Cached NB17 rank derivatives exist; optional depth100 branch has the explicit runtime status above.'),
                         subtask('5.3', 'COMPLETE_IN_SCOPE', 'Local checkpoints and held runtime branches preserved; no paid dispatch occurred.'),
                         subtask('5.4', 'COMPLETE', 'Query population, allowed pool, split and derived ranks checked; original score files unchanged.', [receipt])]}
A05 = run_action(5, action05)
