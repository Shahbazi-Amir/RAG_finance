import json,pathlib,hashlib,ast
base=pathlib.Path('notebook_build'); actions=json.loads((base/'actions.json').read_text());pins=json.loads((base/'pins.json').read_text())
can=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
cells=[]
def md(s):cells.append({'cell_type':'markdown','id':hashlib.sha256(s.encode()).hexdigest()[:12],'metadata':{},'source':s.splitlines(keepends=True)})
def code(s):
 ast.parse(s)
 cells.append({'cell_type':'code','id':hashlib.sha256(s.encode()).hexdigest()[:12],'execution_count':None,'metadata':{},'outputs':[],'source':s.splitlines(keepends=True)})
intro='''<div dir="rtl" align="right">

# NB22B — آزمایش بهبود بازیابی و تعیین وضعیت پذیرش

**پروژه:** RAG_finance؛ **نسخهٔ برنامه:** ۱٫۰؛ **تاریخ:** ۲۹ اکتبر۲۰۲۶.

فایل را در `notebooks/phase2/22b_quality_improvement_and_acceptance.ipynb` بگذارید و از کرنل مستقل اجرا کنید.

**دامنهٔ واقعی این نسخه:** اجرای آزمایش محدود Development از کش، گسترش محلی Pool در صورت وجود مدل و دادهٔ پین‌شده، مصرف دقیق شواهد معنایی موجود و ثبت وضعیت۱۴اقدام و۶۴زیرکار. اجرای مولد و ارزیابی مستقل نسخهٔ منتخب نیز پیاده شده‌اند و فقط قرارداد صریح و هش‌متصل خودشان را مصرف می‌کنند. این نسخه مرجع متخصص یا Holdout دست‌نخورده را از خودش تولید یا اعلام نمی‌کند و اتصال Runtime را حدس نمی‌زند. زیرکار وابسته به این ورودی‌ها با دلیل و شاهد `BLOCKED` باقی می‌ماند. بنابراین این فایل به‌تنهایی تحقق تمام کارهای پذیرش یا قبولی Release را تضمین نمی‌کند.

### اجرای Run All و هزینه

- سل اول فقط Imports؛ سل دوم فقط دریافت ورودی صریح؛ اجرای نوت‌بوک قبلی یا نیاز به globals قبلی وجود ندارد.
- بستهٔ داوری شکاف‌های معنایی با تأیید کاربر فعال است: حداکثر۱۱۴۹درخواست،۱۸اجرای همزمان،۸۰درخواست در دقیقه و سقف برنامه‌ریزی۱٬۶۵۰٬۰۰۰تومان. این مجوز فقط همین بسته است؛ مولد محصول و Holdout تازه را پوشش نمی‌دهد. بدون پروفایل هش‌متصل و کلید محلی ارسال متوقف می‌شود؛ کلید چاپ یا ذخیره نمی‌شود. دانلود و نصب خودکار وجود ندارد.
- آزمایش کشی۱۲ترکیب رتبه روی Development اجرا می‌شود؛ داده و آستانهٔ تاریخی تغییر نمی‌کند.
- گسترش محلی Reranker از۵۰به۱۰۰، فقط با فایل مدل موجود و Runtime پین‌شده اجرا می‌شود. حداکثر۱۳۳۲۰۰زوج Development و در صورت انتخاب این نسخه،۵۷۴۵۰زوج Test؛ سقف مشترک۶ساعت محاسبهٔ محلی دارد؛ ممکن است چندساعت طول بکشد. کش هر سؤال برای Resume محفوظ می‌ماند. نبود مدل/بسته، شاخهٔ محلی را متوقف و آزمایش‌های مستقل کشی را حفظ می‌کند.
- فایل Chunk مبنای NB11 و گزارش‌های محلی C054–C058 باید در مخزن محلی موجود باشند. نبود آن‌ها در clone ناقص، با بازسازی یا دانلود حدسی جبران نمی‌شود.
- Test تاریخی برای انتخاب پارامتر استفاده نمی‌شود. موفقیت Development دقت محصول یا پذیرش مستقل نیست.
- تعویق هلث‌چک نوت‌بوک‌های قبلی حفظ می‌شود؛ بررسی کد همین فایل برای مصرف نسخهٔ جدید، اجرای پاک نوت‌بوک‌های قدیمی نیست.
- Run All با ورودی ناکافی گزارش مانع می‌نویسد؛ نبود exception معادل انجام موفق همهٔ کارها نیست. گزارش پایانی شمارش واقعی۶۴زیرکار و وضعیت Gate را نشان می‌دهد.

### معیار ثابت

Recall@10≥۰٫۸۵، nDCG@10≥۰٫۷۵، F1 نبودپاسخ≥۰٫۸۵ و قیود استناد/پوشش/ایمنی مطابق C025/C057. تعریف واحد، مخرج، عدم‌افت و صلاحیت مرجع نیز لازم‌اند. هیچ هدفی برای گرفتن PASS کاهش نمی‌یابد.

</div>
'''
md(intro)
md('''<div dir="rtl" align="right">

## ورودیِ اجرای محصول و مرز مجوز

مسیر اختیاری قرارداد محصول: `artifacts/phase2/quality_improvement/NB22B.product_execution_contract.json`.
قرارداد تازه با Schema `NB22B_PRODUCT_EXECUTION_CONTRACT_V1` به Freeze اقدام۶ و فایل‌های جمعیت، پروفایل مولد، Policy کامل، Lock محیط، موجودی Source و شاهد Restore با مسیر نسبی و SHA256 بایت متصل می‌شود. قرارداد مستقل از تنظیمات داور است و بودجهٔ داور را مصرف نمی‌کند. اگر این اتصال در نسخهٔ محلی موجود نباشد، اقدام۱۱ دلیل دقیق را ثبت می‌کند؛ این وضعیت به معنی نبود کار قبلی در تمام پروژه نیست.

برای ارزیابی نهایی، قرارداد `evaluation` باید به جمعیت ثابت، پاسخ‌های دقیق نسخهٔ منتخب، صلاحیت مرجع و پروتکل/سابقهٔ بازبین و baseline سازگار متصل باشد. Test/Golden دیده‌شده، حتی با تغییر نام، Holdout مستقل نام نمی‌گیرد. هر۱۶خانوادهٔ معیار باید وضعیت داشته باشد؛ نبود داده با صفر یا PASS جایگزین نمی‌شود. معیارهای چندبخشی مانند MRR و p50/p95 جدا بررسی می‌شوند. جزئیات Schema و فرمول‌ها در توابع همین فایل هستند و در خطاهای ورودی دقیق گزارش می‌شوند.

اگر شرط ورودی یا مجوز برقرار نباشد، Run All بقیهٔ کارهای مستقل را انجام می‌دهد و مانع را گزارش می‌کند؛ ادعای اجرای زنده یا پذیرش ایجاد نمی‌شود. شمارش ردیف‌های چک‌لیست، درصد تکمیل محصول نیست.

</div>''')
md('<div dir="rtl" align="right">\n\n### NB22B-C001 — Imports\n\nفقط کتابخانه‌های استاندارد؛ بدون فایل، مدل یا شبکه.\n\n</div>\n')
code((base/'01_imports.py').read_text())
md('<div dir="rtl" align="right">\n\n### NB22B-C002 — ورودی‌های صریح و پیش‌بررسی فقط‌خواندنی\n\nگزارش‌های پین‌شده با هش بایت کنترل می‌شوند. متن چک‌لیست همراه کد قرار دارد. این سل چیزی نمی‌نویسد و مدل بارگذاری نمی‌کند.\n\n</div>\n')
local_tree=ast.parse((base/'08_action05.py').read_text())
local_function=next(n for n in local_tree.body if isinstance(n,ast.FunctionDef) and n.name=='local_depth100')
local_prefix=[];inference_started=False
for node in local_function.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='plan_id' for t in node.targets):break
 if isinstance(node,ast.Try) and any(isinstance(n,ast.Import) and any(a.name=='numpy' for a in n.names) for n in ast.walk(node)):
  inference_started=True
 if inference_started:local_prefix.append(node)
assert inference_started and local_prefix
inference_ast_hash=hashlib.sha256(ast.dump(ast.Module(body=local_prefix,type_ignores=[]),include_attributes=False).encode()).hexdigest()
bootstrap="LOCAL_INFERENCE_IMPLEMENTATION_SHA256 = "+repr(inference_ast_hash)+"\n\nPINNED_INPUTS = "+repr(pins)+"\n\nCHECKLIST = "+repr(actions)+"\n\n"+(base/'02_bootstrap.py').read_text()
# Preserve the identifying header as first line, before embedded constants.
header,body=bootstrap.split('\n',1) if False else ('# NB22B-C002 — Explicit pinned inputs and complete checklist.','\n'+bootstrap)
code(header+body)
md('<div dir="rtl" align="right">\n\n### NB22B-C003 — مکانیک مشترک\n\nتعریف خواندن هش‌متصل، ذخیرهٔ Atomic و Reload، سنجه‌ها و ثبت وضعیت. مانع ورودی از خطای برنامه جداست؛ خطای برنامه پنهان نمی‌شود.\n\n</div>\n')
code((base/'03_helpers.py').read_text()+'\n\n'+(base/'review_engine.py').read_text()+'\n\n'+(base/'product_engine.py').read_text()+'\n\n'+(base/'regression_engine.py').read_text()+'\n\n'+(base/'context_bridge.py').read_text()+'\n\n'+(base/'local_cache.py').read_text())
for a in actions:
 num=a['number']; md(f'<div dir="rtl" align="right">\n\n### NB22B-C{num+3:03d} — اقدام {num}: {a["title"]}\n\n'+a['markdown']+'\n\n**بستهٔ اجرایی:** یک سل تجمیعی؛ همهٔ زیرکارهای همین اقدام ثبت می‌شوند. `COMPLETE_IN_SCOPE` فقط دامنهٔ توضیح‌داده‌شده را می‌بندد؛ `BLOCKED` به معنی رفع مانع نیست. نتیجهٔ واقعی پس از اجرا در خروجی و گزارش پایانی نوشته می‌شود.\n\n</div>\n')
 matches=list(base.glob(f'{num+3:02d}_action{num:02d}.py'));assert len(matches)==1,(num,matches)
 code(matches[0].read_text())
md('''<div dir="rtl" align="right">

## خواندن نتیجهٔ پایانی

مرجع نتیجه، آخرین خروجی اقدام۱۴ و فایل `A14.run_report_fa` همان اجراست. دفتر۶۴زیرکار مشخص می‌کند چه چیزی اجرا شده، چه چیزی فقط در دامنهٔ شواهد قبلی بسته شده و چه چیزی هنوز مانع دارد. در وضعیت عدم پذیرش، ورودی NB23 فقط پیش‌نویس است.

این فایل Runner داوری شکاف‌های معنایی را دارد، با سقف۱٬۶۵۰٬۰۰۰تومانِ تأییدشده برای همین بسته به‌صورت پیش‌فرض فعال است. این سقف برآورد برنامه‌ریزی بر پایهٔ تعرفهٔ تاریخی است و تضمین صورتحساب سرویس‌دهنده نیست؛ Reserve محافظه‌کارانه پیش از ارسال کنترل می‌شود. مولد نسخه‌دار، سنجش۱۶خانوادهٔ معیار با تمام زیرمعیارها و کنترل Policy/محیط/Source/Restore در کد وجود دارند. اجرای تازهٔ مولد به مجوز و بودجهٔ جدا نیاز دارد. مرجع متخصص، جمعیت مستقل و شواهد حل اختلاف باید واقعاً موجود و متصل باشند؛ کد آن‌ها را جعل نمی‌کند. برای بستن آن کارها، بستهٔ اجرایی نسخه‌دار و ورودی معتبر لازم است. این محدودیت باید هنگام تصمیم به اجرای نوت‌بوک دیده شود؛ گزارش مانع جای انجام آن کارها نیست.

</div>
''')
sources=[''.join(c['source']) for c in cells if c['cell_type']=='code'];finger=hashlib.sha256(can(sources)).hexdigest()
nb={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
 'language_info':{'name':'python','version':'3.11'},'nb22b':{'schema_version':'NB22B_NOTEBOOK_BUILD_V1','code_source_sha256':finger,
 'scope':'BOUNDED_EXECUTABLE_EXPERIMENT_AND_EVIDENCE_QUALIFICATION_WITH_EXPLICIT_ACCEPTANCE_PREREQUISITES',
 'reviewed_repository_tree_sha':'ec35ae711e649445db5d55fd642065e1308ba43d','checklist_actions':14,'checklist_subtasks':64,
 'all_acceptance_work_implemented':False,'paid_api_dispatch_implemented':True,'versioned_product_execution_and_evaluation_implemented':True,'paid_api_dispatch_enabled_by_default':True}},'nbformat':4,'nbformat_minor':5}
p=pathlib.Path('deliverables/22b_quality_improvement_and_acceptance.ipynb');p.write_text(json.dumps(nb,ensure_ascii=False,indent=1)+'\n')
print({'path':str(p),'bytes':p.stat().st_size,'cells':len(cells),'code_cells':len(sources),'code_source_sha256':finger})
