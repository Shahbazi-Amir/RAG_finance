import pathlib,json,os,tempfile,contextlib,io,copy,builtins,time
checks=[]
def ok(label,value):
 assert value,label;checks.append({'check':label,'status':'PASS'})
with tempfile.TemporaryDirectory(prefix='nb22b-local-cache-') as tmp:
 root=pathlib.Path(tmp);os.environ['RAG_FINANCE_ROOT']=str(root)
 (root/'notebooks/phase2').mkdir(parents=True)
 marker=root/'data/Road_Maps/RAG_finance_phase2_modular_notebooks_execution_plan.md';marker.parent.mkdir(parents=True);marker.write_text('fixture')
 ns={};exec(pathlib.Path('notebook_build/01_imports.py').read_text(),ns);ns['PINNED_INPUTS']={};ns['CHECKLIST']=[]
 with contextlib.redirect_stdout(io.StringIO()):exec(pathlib.Path('notebook_build/02_bootstrap.py').read_text(),ns)
 for file in ['03_helpers.py','review_engine.py','local_cache.py']:exec(pathlib.Path('notebook_build',file).read_text(),ns)
 text=pathlib.Path('notebook_build/08_action05.py').read_text();exec(text[:text.rfind('\nA05 =')],ns)
 ns['LOCAL_INFERENCE_IMPLEMENTATION_SHA256']='a'*64;ns['SOURCE_CODE_SHA256']='b'*64
 ns['S']['memory']['data_receipts']={'reranker':{'path':'fixtures/reranker.jsonl','file_bytes_sha256':'f'*64}}
 ids=[f'c{i:03d}' for i in range(100)]
 dev={'ids':['q1'],'questions':{'q1':'fixture question'},'chunks':{c:{'content':'fixture '+c} for c in ids},
      'hybrid':{'q1':{'candidates':[{'chunk_id':c,'rank':i+1} for i,c in enumerate(ids)]}},
      'reranker':{'q1':{'candidates':[{'chunk_id':c,'rank':i+1,'reranker_score':0.0} for i,c in enumerate(ids[:50])]}}}
 contract=ns['local_inference_contract']();identity=ns['depth100_case_identity'](dev,'q1',contract)
 guard=ns['atomic_bytes']('fixtures','runtime_guard',ns['canonical']({'schema_version':'NB22B_LOCAL_RUNTIME_PARITY_V2',
       'inference_contract_sha256':contract['sha256'],'model_sha256':ns['CONFIG']['onnx_sha256'],
       'sample_score_max_delta':0.00001,'synthetic_software_fixture_not_real_model_proof':True}),'json')
 scores=[1.0]*50
 record={'identity':identity,'scores':scores,'score_values_sha256':ns['sha'](ns['canonical'](scores)),
         'runtime_validation_receipt':guard,'origin_experiment_plan_sha256':'c'*64}
 folder=ns['project_path']('artifacts/phase2/quality_improvement/NB22B.depth100/'+contract['sha256'])
 path=folder/(ns['sha'](ns['canonical'](identity))+'.json');ns['immutable_file'](path,ns['canonical'](record))
 original_import=builtins.__import__
 def no_model_import(name,*args,**kwargs):
  if name in {'onnxruntime','transformers'}:raise AssertionError('MODEL_RUNTIME_SHOULD_NOT_BE_IMPORTED_FOR_COMPLETE_VALID_CACHE')
  return original_import(name,*args,**kwargs)
 builtins.__import__=no_model_import
 try:result=ns['local_depth100'](dev,{'file_bytes_sha256':'d'*64})
 finally:builtins.__import__=original_import
 ok('complete_score_cache_reused_without_model_runtime_import',result['complete'] and not result['model_loaded_this_call'] and result['new_pairs']==0)
 ok('all100_scores_and_pool_restored',len(result['orders']['q1'])==100 and set(result['orders']['q1'])==set(ids))
 inventory=ns['register_local_score_assets'](result,{'path':'fixtures/plan.json','file_bytes_sha256':'c'*64},'fixture.local_cache_inventory')
 ok('score_and_guard_receipts_registered_for_final_independent_reload',any(r['path']==path.relative_to(root).as_posix() for r in ns['S']['artifacts']) and any(r['path']==guard['path'] for r in ns['S']['artifacts']))

 ns['SOURCE_CODE_SHA256']='e'*64;ns['CONFIG']['rrf_weights']=[.33,.66]
 ok('unrelated_notebook_code_and_fusion_grid_do_not_change_inference_cache_identity',ns['local_inference_contract']()['sha256']==contract['sha256'])
 bad=copy.deepcopy(record);bad['scores'][0]=2.
 try:ns['validate_local_score_record'](bad,identity,contract);raised=False
 except ns['EvidenceGap'] as error:raised=str(error)=='LOCAL_SCORE_CACHE_CHECKSUM_CONFLICT'
 ok('changed_score_without_checksum_rejected',raised)
 modified=copy.deepcopy(dev);modified['questions']['q1']='different question'
 ok('changed_question_gets_different_case_identity',ns['depth100_case_identity'](modified,'q1',contract)!=identity)
 ns['S']['memory']['chunk_content_sha256']={}
 modified=copy.deepcopy(dev);modified['chunks'][ids[-1]]['content']='changed chunk text'
 ok('changed_missing_chunk_text_gets_different_cache_identity',ns['depth100_case_identity'](modified,'q1',contract)!=identity)
 ok('existing_cache_record_keeps_original_plan_lineage',json.loads(path.read_bytes())['origin_experiment_plan_sha256']=='c'*64)
 ns['CONFIG']['model_revision']='changed-revision'
 ok('changed_model_revision_invalidates_inference_contract',ns['local_inference_contract']()['sha256']!=contract['sha256'])
 original,stat_key=ns['local_cache_stable_read'](path)
 binding={'path':path,'stat':stat_key,'file_bytes_sha256':ns['sha'](original)}
 path.write_bytes(original+b'\n')
 try:ns['local_cache_receipt'](binding);raised=False
 except ns['EvidenceGap'] as error:raised=str(error)=='LOCAL_SCORE_CACHE_CHANGED_AFTER_VALIDATION'
 ok('changed_cache_cannot_receive_a_receipt_for_old_used_scores',raised)

report={'schema_version':'NB22B_STABLE_LOCAL_SCORE_CACHE_VALIDATION_V1','status':'PASS','checks':checks,
        'actual_onnx_model_executed':False,'real_provider_requests':0,
        'runtime_guard_is_explicitly_synthetic_fixture':True}
pathlib.Path('deliverables/NB22B_local_cache_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
