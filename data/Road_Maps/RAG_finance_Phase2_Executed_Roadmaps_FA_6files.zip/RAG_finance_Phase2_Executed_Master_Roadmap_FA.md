<div dir="rtl" align="right">

# نقشهٔ کلانِ مسیر واقعی اجرای فاز دوم

**شناسهٔ نسخه:** `PHASE2-EXECUTED-MASTER-V1`  
**تاریخ ثبت:** ۳۱ اکتبر ۲۰۲۶  
**زیرعنوان:** از Baseline تا موتور RAG سه‌منبعی، ارزیابی و آماده‌سازی قرارداد تحویل  
**وضعیت انتشار:** سند اجرای واقعی / قابل ارائه برای اطلاع‌رسانی، نه صورت‌جلسهٔ پذیرش Release

این سند، نقشهٔ جدید و مستقلِ آن چیزی است که در فاز دوم واقعاً ساخته، آزموده، اصلاح یا ثبت شده است. ترتیب فصل‌ها بر پایهٔ جریان واقعی دارایی‌ها و تصمیم‌های فنی بازطراحی شده؛ لازم نیست خواننده دو نقشهٔ برنامه‌ریزی قدیمی را کنار آن بگذارد.

مرز اعتبار: «انجام کار مهندسی» با «تأیید همهٔ Gateهای کیفیت» یکی نیست. بخش‌های اجرایی فاز دوم طبق گزارش مالک پروژه عملاً پیاده‌سازی شده‌اند؛ پذیرش سراسری Release و تحویل رسمی فاز سوم هنوز بازند. [S1، S2، S4، S7، S8]


## ۱. نتیجهٔ اجرایی در یک نگاه


<table dir="rtl" style="direction:rtl;text-align:right">
<thead><tr><th align="right">حوزهٔ کار واقعی</th><th align="right">خروجی یا شاهد ثبت‌شده</th><th align="right">برداشت درست</th></tr></thead>
<tbody>
<tr><td align="right">پوشش ساختاری</td><td align="right">۲۴ از ۲۴ نوت‌بوک اصلی + ۲۴ نوت‌بوک تکمیلی مرتبط</td><td align="right">۱۰۰٪ شناسایی فایل‌های اصلی؛ نه ۱۰۰٪ پذیرش</td></tr>
<tr><td align="right">پیکرهٔ دانش سه‌منبعی</td><td align="right">۱۹٬۴۵۶ رکورد؛ سایت ۵۲۹، کتاب ۲٬۷۰۱، Transcript ۱۶٬۲۲۶</td><td align="right">جمعیت Corpus ثبت‌شده در مرجع تاریخی</td></tr>
<tr><td align="right">Golden و Claim</td><td align="right">۳٬۸۱۳ سؤال؛ Development ۲٬۶۶۴ و Test ۱٬۱۴۹؛ ۴٬۰۰۶ Claim کانونی</td><td align="right">نسخه‌های داده و Splitها باید ثابت بمانند</td></tr>
<tr><td align="right">مقایسه و اصلاح Retrieval</td><td align="right">Dense، Sparse، Hybrid و Reranker؛ مقایسه‌های NB16/17 و آزمایش‌های 22b تا 22f</td><td align="right">پیشرفت در سنجش؛ پذیرش نهایی جدا</td></tr>
<tr><td align="right">ارزیابی و کنترل پاسخ</td><td align="right">NB19، NB20/20b/20c و NB21/21b/21c؛ ۴۹ اقدام ثبت وضعیت شده</td><td align="right">اتمام اقدام با PASS کیفیت یکسان نیست</td></tr>
<tr><td align="right">قرارداد فاز سوم</td><td align="right">۱۰ اقدام Draft، ۵۴ آزمون Readiness در C012 با نتیجهٔ PASS در محدودهٔ Draft</td><td align="right">Runtime/Producer و Release نهایی هنوز پذیرفته نشده</td></tr>
</tbody></table>

**توضیح:** شمارش‌ها متعلق به جمعیت‌ها و نسخه‌های متفاوت‌اند؛ به یک درصد تکمیل کلی تبدیل نشده‌اند. [S1، S2، S4، S7، S9]


**ترکیب پیکرهٔ پذیرفته‌شدهٔ تاریخی**

- وب‌سایت: **2.7٪**  █  (529 از 19,456)
- کتاب: **13.9٪**  ███  (2,701 از 19,456)
- رونوشت صوت و تصویر: **83.4٪**  █████████████████  (16,226 از 19,456)

این درصدها «ترکیب داده» هستند، نه درصد پیشرفت فاز دوم. [S1]


## ۲. نقشهٔ جدید جریان کارِ طی‌شده

1. فاز ۱ به‌عنوان مرجع پایه ثبت شد: Demo کوچکِ ۷۶ Document و ۱۶۸ Chunk و محدودیت‌های Dense-only و ارزیابی ده‌سؤالی مبنای مقایسه قرار گرفت؛ فاز دوم از توسعهٔ همان Demo جدا شد. [S5، S6]

2. برای سه خانواده منبع، مسیرهای مستقل دریافت، استخراج و کنترل تعریف/پیاده‌سازی شدند؛ Provenance و حقوق نشر از ابتدا از انتساب نویسندگی جدا نگه داشته شد. [S1، S6، S7]

3. منابع سایت، کتاب و Transcript به دادهٔ کانونی با شناسه و Lineage مشترک متصل شدند؛ پیکرهٔ ثبت‌شده به ۱۹٬۴۵۶ رکورد رسید. [S1، S2]

4. نرمال‌سازی فارسی، حذف تکرار، سیاست Authority چهارسطحی و Taxonomy هفت‌موضوعی پیش از بازیابی تثبیت شدند. [S1، S2]

5. گونه‌های مختلف Chunking آزمایش و سپس Golden نسل‌های مختلف بازسازی شد؛ Claim Registry و ۳٬۸۱۳ سؤال فریز‌شدهٔ Development/Test شکل گرفت. [S1، S2، S3]

6. مدل Embedding، Indexهای Dense/Sparse، پنج بازوی Retrieval و Reranker مقایسه شدند؛ سیاست Context با محدودیت تنوع منبع/سند تعیین شد. [S2، S3]

7. زنجیرهٔ پاسخ، Claim/Citation، Answerability، Safety و Confidence توسعه و با بازبینی‌های NB20b/c غنی شد. [S2، S3]

8. ارزیابی جمعیتی، Ablationها، تحلیل شکست، هزینه/Latency و رجیستری شواهد در NB21 و ادامه‌ها گردآوری شد؛ ۴۹ اقدام در دفتر نهایی حسابرسی شدند. [S2، S3، S9]

9. Quality Improvement در خانوادهٔ NB22b/c/d/e/f دنبال شد؛ Validationهای موفق در برخی پیکربندی‌ها ثبت شد، اما Gate فریز‌شدهٔ Test/Release باز ماند. [S7، S8]

10. قرارداد مصرف‌کنندهٔ فاز سوم در NB23 با Schema، Fixture، Error/Outcome، Trace نسخه و Readiness Draft ساخته و آزموده شد. [S4]


## ۳. معماری‌ای که در عمل ساخته شد

جریان واقعی دانش: منبع خام و مجوز/انتساب ← استخراج اختصاصی Website/Book/Transcript ← Common Schema و Stable ID/Hash ← Dedup، Normalization و Authority ← Chunk/Golden/Claim ← Embedding و Dense/Sparse Index ← Hybrid/Reranker/Context ← Generation و Citation/Safety ← Evaluation و Release Candidate ← Handoff Draft.

این «جریان داده و قابلیت» است، نه ادعای یکپارچه‌بودن اجرای Production یا در دسترس بودن سایت و API زنده. قابلیت‌های پلتفرم چندکاربره، Auth، دیتابیس کاربران و مانیتورینگ Production در مرز فاز سوم قرار دارند. [S1، S4، S5، S6]


## ۴. نتایج عددی واقعی در مسیر پیشرفت بازیابی


<table dir="rtl" style="direction:rtl;text-align:right">
<thead><tr><th align="right">مرحلهٔ آزمایش</th><th align="right">Recall@10</th><th align="right">nDCG@10</th><th align="right">جمعیت و مرز تفسیر</th></tr></thead>
<tbody>
<tr><td align="right">Dense پایهٔ NB16</td><td align="right">۴۷٫۳۵٪</td><td align="right">۳۷٫۴۰٪</td><td align="right">Benchmark تاریخی همان قرارداد</td></tr>
<tr><td align="right">Weighted Hybrid در NB16</td><td align="right">۶۲٫۱۲٪</td><td align="right">۵۳٫۸۲٪</td><td align="right">مقایسه با Dense روی قرارداد همان گزارش</td></tr>
<tr><td align="right">پس از Reranker در NB17</td><td align="right">۶۶٫۷۷٪</td><td align="right">۵۹٫۸۸٪</td><td align="right">Development، ۲٬۶۶۴ سؤال، Pool ۵۰</td></tr>
<tr><td align="right">Test تاریخی NB22-C056</td><td align="right">۶۳٫۴۳٪</td><td align="right">۵۷٫۳۵٪</td><td align="right">Test تاریخی؛ هدف ۸۵٪ و ۷۵٪</td></tr>
<tr><td align="right">Validation / Anchored Pairwise در NB22e-C034</td><td align="right">۸۵٫۵۸٪</td><td align="right">۷۸٫۲۴٪</td><td align="right">Validation آزمایشی، نه Release پذیرفته‌شده</td></tr>
<tr><td align="right">Validation / Weighted Ridge در NB22e-C034</td><td align="right">۸۵٫۵۸٪</td><td align="right">۷۹٫۳۹٪</td><td align="right">Validation آزمایشی، نه Test قطعی</td></tr>
</tbody></table>

**توضیح:** سه ردیف نخست در مقایسهٔ تاریخی Development ثبت شده‌اند؛ Test و Validation جدید جمعیت یکسانی ندارند و نباید در یک نمودار به‌عنوان رشد خطی یکسان تفسیر شوند. [S3، S7، S8]


**روند مقایسهٔ هم‌قرارداد Development در NB16/17**

- Dense Recall@10: **47.4٪**  █████████  (0 از 1)
- Weighted Hybrid Recall@10: **62.1٪**  ████████████  (1 از 1)
- Reranker Recall@10: **66.8٪**  █████████████  (1 از 1)

تنها Recall@10 در مراحل قابل مقایسهٔ گزارش‌شده در خانوادهٔ NB16/17 نمایش داده شده است؛ این نمودار، Test یا Production نیست. [S3]


## ۵. دستاوردهای مهندسی که در جدول قدیمی دیده نمی‌شدند

- **پیکره و مالکیت:** تفکیک Author، Curator، Rights Holder و Knowledge Authority؛ رعایت تفاوت مقالهٔ مستقیم/تحت سردبیری، کتاب‌های Editionدار و زمان/گویندهٔ Transcript. چهار لایهٔ Authority نیز ثبت شده‌اند: ۱۴٬۷۰۵ Core، ۴۵۳ Supervised، ۱٬۹۴۴ Contextual، ۲٬۳۵۴ Unresolved. [S1]

- **بازسازی Golden:** خانوادهٔ 12a تا 12j از نمونهٔ اولیه تا بازبینی، بازسازی ثبت‌محور و نسخهٔ v2 پیش رفته است؛ Raw Claim برابر ۶٬۲۳۷، Validated Claim برابر ۴٬۰۳۹ و Canonical Claim برابر ۴٬۰۰۶ گزارش شده است. [S2، S3، S7]

- **آزمایش‌های مهندسی:** در NB11 پنج اندازهٔ ثبت‌شدهٔ Candidate Chunk وجود دارد (۳٬۴۸۸ / ۲٬۵۲۶ / ۱٬۷۹۹ / ۲٬۷۲۱ / ۱٬۴۴۷). این‌ها پنج آزمایش/گزینه‌اند، نه پنج Corpus Production. [S2]

- **مقایسهٔ Reranker:** روی ۲٬۶۶۴ Development، افزایش Recall و nDCG ثبت شده و برای ΔnDCG نمونه‌گیری Bootstrap با ۵٬۰۰۰ تکرار و CI ۹۵٪ موجود است. [S3]

- **کنترل Context:** سیاست برگزیدهٔ source=8/document=5 و بررسی ۲٬۶۶۴ بسته، با ۲۶٬۶۱۶ آیتم انتخابی و ۲۴ حذف ثبت شده است؛ این ارقام کیفیت نهایی پاسخ نیستند. [S3]

- **پوشش پاسخ:** در NB19 خروجی Development برای ۲٬۲۲۴ eligible و ۴۴۰ blocked، با ۵٬۶۴۰ Claim و ۱۰٬۵۳۲ Citation ثبت شده است؛ صحت معنایی همهٔ Citationها از این اعداد اثبات نمی‌شود. [S2]

- **آزمون قرارداد:** NB23 دارای ۴۱ Fixture ساختاری (۱۵ مثبت، ۲۶ منفی)، ۱۲ گفت‌وگو و ۱۳ Turn نمونه و ۵۴/۵۴ کنترل نهایی در دامنهٔ Draft است. [S4]


## ۶. زمان‌بندی واقعیِ مستند، نه ساعت‌سازی


<table dir="rtl" style="direction:rtl;text-align:right">
<thead><tr><th align="right">نقطهٔ زمانی قابل اتکا</th><th align="right">چه چیزی مستند شده</th><th align="right">مرز ادعا</th></tr></thead>
<tbody>
<tr><td align="right">۲۱ اوت ۲۰۲۶</td><td align="right">نسخهٔ ثبت‌شدهٔ نقشه‌های کلان و عملیاتی</td><td align="right">تاریخ برنامه؛ تاریخ شروع تک‌تک فعالیت‌ها نیست</td></tr>
<tr><td align="right">۲۳ اکتبر ۲۰۲۶</td><td align="right">بستهٔ مرجع و دفتر شواهد NB21 و ماتریس بازاستفاده</td><td align="right">Snapshot گزارش؛ تاریخ پایان همهٔ فعالیت‌ها نیست</td></tr>
<tr><td align="right">۲۶–۲۹ اکتبر ۲۰۲۶</td><td align="right">جمع‌بندی NB21 و کار روی بهبود کیفیت NB22 (بر اساس سوابق پروژه)</td><td align="right">بازهٔ فعالیت ثبت‌شده، نه Time Sheet</td></tr>
<tr><td align="right">۳۱ اکتبر ۲۰۲۶</td><td align="right">ممیزی As-Built C015–C024 و گزارش حاضر</td><td align="right">تاریخ تجمیع و بازطراحی نقشه</td></tr>
</tbody></table>

**توضیح:** مدت تقویمی میان نسخهٔ نقشهٔ ۲۱ اوت و بازطراحی ۳۱ اکتبر ۷۱ روز است؛ این عدد «۷۱ روز کار اجرایی» یا ساعت مهندسی نیست. Time Sheet قابل استناد ارائه نشده است. [S1، S2، S6، S7، S9]


## ۷. تفکیک وضعیت انجام کار و پذیرش کیفیت


<table dir="rtl" style="direction:rtl;text-align:right">
<thead><tr><th align="right">محور</th><th align="right">آنچه می‌توان گفت</th><th align="right">آنچه هنوز نمی‌توان گفت</th></tr></thead>
<tbody>
<tr><td align="right">پیاده‌سازی و شواهد</td><td align="right">۲۴ نوت‌بوک اصلی حاضرند؛ دارایی‌های مهم و تکرارهای آزمایشی ثبت شده‌اند</td><td align="right">تأیید مستقل تمام سل‌ها/الزامات و Run All کلی</td></tr>
<tr><td align="right">ارزیابی تاریخی</td><td align="right">۲ PASS، ۲ FAIL، ۱۲ BLOCKED برای ۱۶ Gate تاریخی</td><td align="right">تبدیل ۲ PASS به درصد پیشرفت مهندسی</td></tr>
<tr><td align="right">Retrieval جدید</td><td align="right">Validation برخی تنظیم‌ها به Recall ۸۵٪ و nDCG ۷۵٪ رسیده</td><td align="right">پایداری/Generalization روی Test و Release</td></tr>
<tr><td align="right">NB23</td><td align="right">۱۰ اقدام Draft و آزمون ساختاری در محدودهٔ مشخص تمام شده</td><td align="right">Producer Runtime، قفل ۷ گروه نسخه، Formal Handoff</td></tr>
</tbody></table>

**توضیح:** برای وضعیت پروژه درصد واحد معتبر وجود ندارد؛ هر نسبت فقط با مخرج و شرط پذیرش خودش ارائه شده است. [S4، S7، S8]


## ۸. تصمیم‌های باقیمانده در انتهای این مسیر

1. قرارداد نهایی Citation Coverage باید از تعارض معیار ۹۰٪ Claim Citation Coverage در نقشهٔ ماژولار با معیار اولیهٔ ۹۵٪ برای factual Claims در نقشهٔ عملیاتی تعیین تکلیف شود؛ تاریخچهٔ Gate تغییر نکند.

2. بهترین پیکربندی Retrieval با Split، Gold، تنظیمات و هش واحد روی جمعیت مجاز نهایی شود؛ گزارش NB22-C035 انتخاب baseline را در دامنهٔ دیگری ثبت کرده و نباید با موفقیت C034 خلط شود.

3. بستهٔ نسخه‌دار Release، سنجش Regression، شاهد Reproducibility و تصمیم Quality Gate پذیرفته شوند؛ ارجاع‌های ساختاری بدون پذیرش معنایی کافی نیستند.

4. NB23 فقط پس از Release پذیرفته‌شده، اتصال Producer واقعی، Smoke/Safety و Authoritative Version Lock تحویل رسمی فاز سوم را دریافت کند.

5. موارد Deferred یا خارج از Scope، به‌ویژه Health و قابلیت‌های فاز ۳/۴، بدون تصمیم رسمی در شمار شکست یا تکمیل کار فاز دوم قرار نگیرند.


## ۹. سند همراه و دسترسی به جزئیات

سند همراه «نقشهٔ عملیاتی بازطراحی‌شدهٔ اجرای فاز دوم» شرح ریز هر ۲۴ نوت‌بوک، مرحله‌های بازکاری، جمعیت‌ها، نتایج و محدودیت هر دستاورد را دارد. هر دو سند به‌تنهایی خواندنی‌اند؛ منابع زیر برای حسابرسی و بازیابی Artifact دقیق درج شده‌اند، نه برای فهم اصل داستان.


## ۱۰. دفتر منشأ شواهد

- S1: 01_RAG_finance_roadmap_and_contract_fa.md — ترتیب نوت‌بوک‌ها، Corpus، Authority و قرارداد سنجش

- S2: 02_RAG_finance_evidence_and_notebook_status_fa.md — موجودی دارایی‌ها، شش Ablation و وضعیت محاسبات

- S3: NB21_phase2_reuse_audit_fa.md — ممیزی مستقل NB12/NB16/NB17/NB18 و جلوگیری از دوباره‌کاری

- S4: NB23_phase3_handoff_checklist_fa_UPDATED.md — ۱۰ اقدام Draft و نتایج آزمون‌های قرارداد

- S5: RAG_finance_master_roadmap(2).md — مرز فازهای محصول

- S6: RAG_finance_phase2_operational_roadmap(2).md — معماری اولیهٔ ۱۴ بسته

- S7: P2AUD-C015 تا C024 — خروجی‌های خوانده‌شده در همین گفتگو؛ صورت‌جلسهٔ ممیزی و ساخت As-Built

- S8: گزارش‌های نسخه‌دار NB22.C054/C056/C057/C058 و NB22E.C034/C035، خوانده‌شده در C017–C020

- S9: گزارش نهایی NB21-C085 — دفتر ۴۹ اقدام، ۲۲ گزارش پایانی، ۳۸ سند قبلی، ۱۰ مسئلهٔ باز (طبق گفتگوهای همین پروژه)


</div>
